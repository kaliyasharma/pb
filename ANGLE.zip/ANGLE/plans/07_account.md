# Step 07 — Account Info (Balance, P&L, Bet History)

## Goal
Show the user their balance in the toolbar and allow them to review past bets.

## Questions to answer

### 1. Balance endpoint
- [ ] URL (e.g. `GET /api/account/balance`)
- [ ] Response shape:
```json
{
  "available": 100.00,
  "exposure": 5.00,
  "currency": "GBP"
}
```

### 2. Bet history endpoint
- [ ] URL (e.g. `GET /api/bets/history`)
- [ ] Filters: date range, sport, settled/unsettled?
- [ ] Response shape (bet_id, market, runner, side, price, size, result, pnl)
- [ ] Pagination?

### 3. Settlement — how does pb77 notify a bet result?
- [ ] Does the WebSocket push a settlement message?
- [ ] Or do we poll the bet history endpoint after market goes CLOSED?

---

## Plan

```python
class PB77Account:
    async def get_balance(self) -> dict: ...
    async def get_bet_history(self, from_date: date, to_date: date) -> list[dict]: ...
```

Balance shown in MainWindow toolbar, refreshed every 30s.

## Status
- [ ] Balance endpoint found
- [ ] History endpoint found
- [ ] Settlement notification method confirmed
- [ ] Implementation ready to start
