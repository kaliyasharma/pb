# Step 03 — Market / Event Search

## Confirmed: 3-level hierarchy

```
Sport  ──→  GET /customer/api/competition/sport/{sport_id}   → list of competitions
  │
Competition ──→  GET /customer/api/competition/{competition_id}  → list of events
  │
Event  ──→  GET /customer/api/event/{event_id}  (TBD — paste next)  → list of markets
```

All calls go to: `https://ex.pb77.co`
Auth: `BIAB_CUSTOMER` cookie (set during exchange handshake — sent automatically by cookie jar)

---

## Level 1 — List Competitions for a Sport

```
GET https://ex.pb77.co/customer/api/competition/sport/{sport_id}
X-Device: DESKTOP
Accept: application/json, text/plain, */*
```

### Sport IDs (match Betfair numbering)
| ID | Sport |
|----|-------|
| `4` | Cricket |
| `1` | Football (assumed — confirm) |
| `2` | Tennis (assumed — confirm) |

### Response shape:
```json
{
  "topCompetitions": [
    {
      "id": "12674617",
      "name": "ICC Women's T20 World Cup",
      "type": "COMPETITION",
      "eventTypeId": "4",
      "identifier": "12674617",
      "translations": { "premium|en": "ICC Women's T20 World Cup" }
    }
  ],
  "moreCompetitions": [
    {
      "id": "12809363",
      "name": "Bengal Pro T20 League",
      "type": "COMPETITION",
      "eventTypeId": "4"
    }
  ],
  "availableTimeFilters": ["IN_PLAY", "ALL", "FUTURE", "TODAY", "TOMORROW"],
  "parents": [
    { "id": "4", "name": "Cricket", "type": "EVENT_TYPE" }
  ]
}
```

- `topCompetitions` = featured/highlighted ones (shown at top)
- `moreCompetitions` = full list
- Combine both for the full competition list

---

## Level 2 — List Events for a Competition

```
GET https://ex.pb77.co/customer/api/competition/{competition_id}
X-Device: DESKTOP
Accept: application/json, text/plain, */*
```

Example: `GET /customer/api/competition/12809363`

### Response shape:
```json
{
  "id": "12809363",
  "name": "Bengal Pro T20 League",
  "type": "COMPETITION",
  "eventTypeId": "4",
  "children": [
    {
      "id": "#date_Sat 20 Jun",
      "name": "Sat 20 Jun",
      "type": null
    },
    {
      "id": "35737930",
      "name": "Servotech Siliguri Strik v Sobisco Smashers Malda",
      "type": "EVENT",
      "startTime": 1781962200000,
      "countryCode": "GB",
      "eventTypeId": "4"
    },
    {
      "id": "35737913",
      "name": "Shrachi Rarh Tigers v Novus Royals Purulia",
      "type": "EVENT",
      "startTime": 1781940600000
    }
  ],
  "competitions": [ ... ]
}
```

- `children` is a mixed array — filter by `type == "EVENT"` to get actual events
- Items with `type == null` are date separator labels (skip them)
- `startTime` is **epoch milliseconds** → `datetime.fromtimestamp(ms / 1000)`

---

## Level 3 — List Markets for an Event (CONFIRMED)

```
GET https://ex.pb77.co/customer/api/event/details/{event_id}
X-Device: DESKTOP
```

Example: `GET /customer/api/event/details/35737913`

### Response shape:
```json
{
  "startDate": 1781940600000,
  "eventInfo": { "id": "35737913", "name": "Shrachi Rarh Tigers v Novus Royals Purulia", "eventTypeId": "4" },
  "marketCatalogues": [
    {
      "marketId": "1.259307107",
      "marketName": "Match Odds",
      "marketStartTime": 1781940600000,
      "totalMatched": 0.0,
      "commission": 2.00,
      "description": { "marketType": "MATCH_ODDS", "bettingType": "ODDS", "turnInPlayEnabled": true },
      "runners": [
        { "selectionId": 84707686, "runnerName": "Shrachi Rarh Tigers", "handicap": 0.0, "sortPriority": 1 },
        { "selectionId": 99247473, "runnerName": "Novus Royals Purulia", "handicap": 0.0, "sortPriority": 2 }
      ]
    },
    { "marketId": "1.259307109", "marketName": "Tied Match", ... }
  ]
}
```

- `marketCatalogues` = the list of markets for this event
- Each market has `marketId` (format `1.xxxxxxxxx` — Betfair-style), `runners` with `selectionId`

## Level 4 — Single Market Detail (CONFIRMED)

```
GET https://ex.pb77.co/customer/api/market/{market_id}
```

Example: `GET /customer/api/market/1.259307107`

Returns the same market shape as a catalogue entry PLUS:
- `parents` — breadcrumb chain (sport → competition → event)
- `dropdownMarkets` — sibling markets for quick switching
- `priceLadderDescription.type` = `"CLASSIC"` (standard Betfair price increments — our ladder logic applies)

> NOTE: This is metadata only — **no prices yet**. Live back/lay prices come from a
> separate endpoint/stream (Step 04 / 05) — still to capture.

---

## Required headers on ex.pb77.co (confirmed)

| Header | Value |
|--------|-------|
| `X-Device` | `DESKTOP` |
| `Accept` | `application/json, text/plain, */*` |
| `BIAB_CUSTOMER` | JWT cookie (auto via cookie jar) |
| `BIAB_LANGUAGE` | `en` cookie |
| `BIAB_TZ` | `-330` cookie (IST = UTC+5:30) |
| `CSRF-TOKEN` | cookie (set on first visit to ex.pb77.co — need to capture) |

---

## Implementation Plan

```python
from datetime import datetime

EX_BASE = "https://ex.pb77.co"

EX_HEADERS = {
    "X-Device": "DESKTOP",
    "Accept": "application/json, text/plain, */*",
    "User-Agent": "Mozilla/5.0 ...",
    "Origin": "https://www.pb77.co",
    "Referer": "https://ex.pb77.co/",
}

class PB77Markets:
    def __init__(self, http: httpx.Client):
        self._http = http   # same client that has BIAB_CUSTOMER cookie

    def list_competitions(self, sport_id: str) -> list[dict]:
        resp = self._http.get(
            f"{EX_BASE}/customer/api/competition/sport/{sport_id}",
            headers=EX_HEADERS,
        )
        body = resp.json()
        return body.get("topCompetitions", []) + body.get("moreCompetitions", [])

    def list_events(self, competition_id: str) -> list[dict]:
        resp = self._http.get(
            f"{EX_BASE}/customer/api/competition/{competition_id}",
            headers=EX_HEADERS,
        )
        children = resp.json().get("children", [])
        return [c for c in children if c.get("type") == "EVENT"]

    def list_markets(self, event_id: str) -> list[dict]:
        # TODO: fill in after next paste
        ...

    @staticmethod
    def parse_start_time(epoch_ms: int) -> datetime:
        return datetime.fromtimestamp(epoch_ms / 1000)
```

## Known Sport IDs
| ID | Sport | Confirmed? |
|----|-------|-----------|
| `4` | Cricket | YES |
| `1` | Football | Not yet |
| `2` | Tennis | Not yet |

## Status
- [x] Level 1 (competitions by sport) — endpoint + shape confirmed
- [x] Level 2 (events by competition) — endpoint + shape confirmed
- [ ] Level 3 (markets by event) — awaiting paste
- [ ] CSRF-TOKEN origin — how/when is it set?
- [ ] Implementation — ready once Level 3 confirmed
