# Step 04 — Price Data (Odds / Order Book)

## Goal
Get the current back/lay prices and available volume for each runner in a market.
This is what populates the ladder columns.

## Questions to answer (open a market on pb77, watch Network)

### 1. Snapshot endpoint — initial load
- [ ] URL (e.g. `/api/markets/{market_id}/book`)
- [ ] Response shape — does it include:
  - Runner names + selection IDs?
  - Best 3 back prices + sizes?
  - Best 3 lay prices + sizes?
  - Traded volume per price?
  - Last price traded?
  - Total matched?

Expected shape (fill in after inspection):
```json
{
  "marketId": "...",
  "status": "OPEN",
  "inPlay": false,
  "totalMatched": 12345.67,
  "runners": [
    {
      "selectionId": 123,
      "runnerName": "Horse A",
      "availableToBack": [
        { "price": 3.5, "size": 200.0 }
      ],
      "availableToLay": [
        { "price": 3.55, "size": 150.0 }
      ],
      "lastPriceTraded": 3.5
    }
  ]
}
```

### 2. Does pb77 use a price increment ladder like Betfair?
- [ ] Betfair uses specific increments (1.01–2.00 in 0.01 steps, etc.)
- [ ] Does pb77 use decimal odds with the same increments?
- [ ] Or fractional / American odds? (need to convert)
- [ ] Or free-form prices?

### 3. Are runner names / selection IDs stable?
- [ ] Do selection IDs persist across sessions? (important for automation rules)

---

## Plan

```python
class PB77PriceData:
    async def get_market_book(self, market_id: str) -> MarketBook:
        # Single REST call for initial snapshot
        ...

    def parse_runner(self, raw: dict) -> Runner:
        # Map pb77 field names → our internal Runner model
        ...
```

## Status
- [ ] Snapshot endpoint found
- [ ] Response shape fully mapped
- [ ] Odds format confirmed (decimal / Betfair-increment compatible?)
- [ ] Runner ID stability confirmed
- [ ] Implementation ready to start
