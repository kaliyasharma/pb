# Step 05 — Live Price Updates (WebSocket / SockJS)

## Confirmed: SockJS WebSocket

pb77 streams live prices over **SockJS**.

```
URL pattern:  wss://ex.pb77.co/customer/ws/multiple-market-prices/{server_id}/{session_id}/websocket
example:      .../customer/ws/multiple-market-prices/575/be6d8741-59f8-4db7-9511-c6696ad30e27/websocket
```

⚠ There is also a `/customer/ws/general/` endpoint (used for PROPERTIES/settings stream),
but **price data comes from `/customer/ws/multiple-market-prices/`**.

- `server_id` = random 3-digit number (e.g. `694`)
- `session_id` = random token (e.g. `d17c1e2e-...`)
- Auth: BIAB cookies (`BIAB_AN`, `BIAB_CUSTOMER`, `CSRF-TOKEN`) sent via Cookie header

### SockJS frame types (first char of each frame)
| Frame | Meaning |
|-------|---------|
| `o` | open (sent by server on connect) |
| `h` | heartbeat |
| `a[...]` | array of messages — each element is a JSON-encoded string |
| `m"..."` | single message |
| `c[code,reason]` | close |

To **send**: encode as a JSON array of strings → `ws.send('["<inner json>"]')`

---

## Price Message Format (inside `a[...]`)

Each data frame: `a["<json string>"]`. The JSON string parses to:

```json
{
  "id": "1.259281545",
  "marketDefinition": {
    "marketType": "MATCH_ODDS",
    "status": "OPEN",
    "inPlay": true,
    "betDelay": 5,
    "numberOfWinners": 1,
    "numberOfActiveRunners": 3,
    "eventId": "35734282",
    "runners": [
      { "id": 6329654, "selectionId": 6329654, "status": "ACTIVE", "sortPriority": 1 }
    ]
  },
  "rc": [
    {
      "id": 6329654,
      "tv": 498.39,
      "bdatb": [ {"index":0,"odds":10.5,"amount":1.19}, {"index":1,"odds":10.0,"amount":47.27}, {"index":2,"odds":9.8,"amount":20.5} ],
      "bdatl": [ {"index":0,"odds":11.5,"amount":14.45}, {"index":1,"odds":12.0,"amount":9.49}, {"index":2,"odds":12.5,"amount":24.01} ],
      "catb": [ [9.8,20.5],[10.0,47.27],[10.5,1.19] ],
      "catl": [ [11.5,14.45],[12.0,9.49],[12.5,24.01] ],
      "locked": false
    }
  ],
  "tv": "2990.80",
  "overround": 101.2,
  "underround": 98.8,
  "currency": "EUR",
  "commission": 2.00,
  "marketNameWithParents": "Match Odds",
  "img": true,
  "bettingEnabled": true
}
```

### Field meanings (Betfair-style)
| Field | Meaning |
|-------|---------|
| `rc` | runner changes (array, one per runner with updates) |
| `rc[].id` | selectionId |
| `rc[].tv` | total matched volume on this runner |
| `rc[].bdatb` | best available to back — object list `[{index,odds,amount}]` (general ws endpoint) |
| `rc[].bdatl` | best available to lay — object list (general ws endpoint) |
| `rc[].catb` | combined available to back — **`[[odds, amount], …]` ascending** (multiple-market-prices endpoint) |
| `rc[].catl` | combined available to lay — **`[[odds, amount], …]` ascending** (multiple-market-prices endpoint) |

**Key**: `multiple-market-prices` sends `catb`/`catl` only. `general` sends `bdatb`/`bdatl`.
- `catb` ascending → reverse → back[0] = best back (highest odds)
- `catl` ascending → keep → lay[0] = best lay (lowest odds)
| `rc[].locked` | runner suspended/locked |
| `img` | `true` = full snapshot; absent/false = delta (merge by runner id) |
| `tv` (top level) | market total matched |
| `overround` / `underround` | book percentages |

### Display mapping (grid like Betfair)
- **Back side**: show levels best-on-the-inside → display order `[bdatb[2], bdatb[1], bdatb[0]]` (best back adjacent to centre)
- **Lay side**: `[bdatl[0], bdatl[1], bdatl[2]]` (best lay adjacent to centre)
- Empty levels come through as `odds:0.0, amount:0.0` → render blank
- Each cell shows **odds** (bold) over **amount** (small)

---

## CONFIRMED — Outgoing connect / subscribe sequence (multiple-market-prices endpoint)

On connect (after the server `o` frame), the client sends these two frames:

```
# 1. General init
["[{\"applicationType\":\"WEB\"}]"]

# 2. MARKET SUBSCRIBE
["[{\"marketId\":\"1.259279218\",\"eventId\":\"35734059\",\"applicationType\":\"WEB\"}]"]
```

No `PROPERTIES` subscribe needed on this endpoint — that lives on `/customer/ws/general/`.

### Key facts
- SockJS send format: a JSON array containing **one string** → `["<inner>"]`
- The market subscribe `<inner>` is itself a **JSON array of one object**:
  `[{"marketId": "...", "eventId": "...", "applicationType": "WEB"}]`
- **Requires both `marketId` AND `eventId`** → `Market.event_id` must be populated
  (it is, from `marketCatalogues[].event.id`).

Implemented in `pb77/api/stream.py._handshake()` + `_send_market()`.

## Status
- [x] Transport confirmed: SockJS over WebSocket
- [x] URL pattern confirmed
- [x] Incoming price message format fully decoded
- [x] Frame parsing implemented
- [x] Outgoing connect + market subscribe sequence confirmed & implemented
- [ ] Heartbeat / reconnect behaviour (relying on websocket-client ping for now)
