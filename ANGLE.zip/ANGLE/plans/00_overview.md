# Betangle — PB77 Edition: Master Plan

## Goal
Build a desktop trading app (PyQt6) for pb77.co, similar to what Betangel does for Betfair.
Since pb77 has no official Python SDK, we reverse-engineer their web API via browser DevTools.

## Architecture Decision
We will use `httpx` (async HTTP client) + a custom `PB77Client` instead of betfairlightweight.
For real-time data we investigate whether pb77 uses:
- WebSockets (preferred — like Betfair Streaming)
- Server-Sent Events (SSE)
- Long polling / REST polling fallback

## Steps to Plan (one file each)

| # | File | Topic |
|---|------|-------|
| 01 | 01_login.md | Authentication — how pb77 logs in, what tokens/cookies are issued |
| 02 | 02_session.md | Session management — keep-alive, token refresh, expiry |
| 03 | 03_market_search.md | Searching events & markets (sport, date, type) |
| 04 | 04_price_data.md | Fetching odds/prices for a market |
| 05 | 05_live_updates.md | Real-time streaming (WebSocket or polling) |
| 06 | 06_order_placement.md | Placing, editing, cancelling bets |
| 07 | 07_account.md | Balance, P&L, bet history |

## Research Method (for each step)
1. Open pb77.co in Chrome
2. Open DevTools → Network tab
3. Perform the action (login, load market, etc.)
4. Record: URL, method, request headers, request body, response shape
5. Document findings in the relevant plan file

## Tech Stack (updated from Betfair version)
- `httpx` — async HTTP with cookie jar support
- `websockets` or `httpx-sse` — for live data
- `PyQt6` — UI (unchanged)
- No betfairlightweight dependency needed

## Confirmed: Site Architecture
- **Framework:** UmiJS (React SPA) — `umi.*.js` / `umi.*.css` bundles
- **CDN:** AWS CloudFront (`X-Amz-Cf-*` headers, `X-Cache: Hit from cloudfront`)
- **Web server:** nginx behind CloudFront
- **Rendering:** Client-side only — `GET /` returns an empty `<div id="root">` shell
- **Implication:** All API data comes via XHR/fetch calls from JavaScript — filter Network tab by **Fetch/XHR** to find real endpoints
- **Required headers to mimic browser:** `User-Agent`, `Accept`, `Sec-Fetch-*`, `Sec-Ch-Ua-*`
