# Step 02 — Session Management

## Confirmed

| Property | Value |
|----------|-------|
| Token lifetime | 36000 seconds = **10 hours** |
| Source | `logoutSetting.tokenTimeout` in login response + JWT `exp - iat` |
| Refresh mechanism | Unknown — need to investigate |
| Session signal | `BIAB_CUSTOMER` JWT cookie + `Token` header |

## What still needs inspecting

- [ ] Is there a refresh/renew endpoint? (watch Network after ~9 hours, or look for periodic calls)
- [ ] On 401 — does the site redirect to login or show an inline error? (paste a failed auth response if you see one)

## Strategy (safe default)

Since the token lasts 10 hours, we:
1. Store `expires_at = login_time + 10h` in `PB77Session`
2. Check before every API call: if < 5 minutes remaining, force re-login via OTP
3. Run a `QTimer` every 60s in MainWindow to check `is_logged_in()` and warn user with 10 minutes remaining

```python
# in MainWindow._tick()
if self._auth.session:
    remaining = self._auth.session.expires_at - datetime.utcnow()
    if remaining < timedelta(minutes=10):
        self._status_bar.showMessage("⚠ Session expiring soon — please re-login", 0)
    if remaining <= timedelta(0):
        self._on_logout()
```

## Status
- [x] Token lifetime confirmed (10 hours)
- [x] Session strategy defined (expiry check + warn)
- [ ] Refresh endpoint — to be investigated
- [ ] 401 error response shape — to be investigated
