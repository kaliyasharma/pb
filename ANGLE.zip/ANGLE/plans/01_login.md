# Step 01 — Login / Authentication

## Flow: 3-step (OTP + Exchange handshake)

```
Step 1: POST /api/v2/otp/email        → triggers OTP email
Step 2: POST /api/v2/login/email      → verifies OTP → returns token + nickname
Step 3: POST /api/exchange2           → exchanges token → returns BIAB_CUSTOMER JWT cookie + exchange URL
```

After Step 3, all exchange calls go to `https://ex.pb77.co` with the `BIAB_CUSTOMER` cookie.

---

## Step 1 — Trigger OTP Email

```
POST https://www.pb77.co/api/v2/otp/email?used=true&email=<url-encoded-email>
Content-Length: 0
Language: en-US
Clienttype: 2
```

Response:
```json
{"status": 200, "data": {}}
```

---

## Step 2 — Verify OTP → Get Token

```
POST https://www.pb77.co/api/v2/login/email
Content-Type: application/x-www-form-urlencoded;charset=UTF-8
Language: en-US
Clienttype: 2

email=user%40email.com&otp=123456
```

Response `data`:
```json
{
  "token": "pq9OnbLtqR8EFAQFQviGCX9d9VdVaFz6",
  "memberId": 396949,
  "nickname": "PB-60e95",
  "email": "manakasad@gmail.com",
  "currencyCode": "INR",
  "currencySymbol": "₹",
  "currencyBalance": 0.00,
  "biab": true,
  "logoutSetting": {
    "tokenTimeout": 36000
  }
}
```

Store `token` and `nickname` — both needed for Step 3.

---

## Step 3 — Exchange Handshake → Get BIAB Cookie

```
POST https://www.pb77.co/api/exchange2?token=<token>&name=<nickname>
Content-Length: 0
Token: <token>
Language: en-US
Clienttype: 2
```

Response sets cookie:
```
Set-Cookie: BIAB_CUSTOMER=eyJ...; domain=.pb77.co; path=/; secure; SameSite=None
```

Response `data`:
```json
{
  "biabUrl": "https://ex.pb77.co",
  "BIAB_CUSTOMER": "eyJ..."
}
```

**`BIAB_CUSTOMER` JWT decodes to:**
```json
{
  "accountId": "pb_PB-60e95",
  "loggedInAccountId": "pb_PB-60e95",
  "accType": "BIAB",
  "status": "active",
  "currency": "INR",
  "level": "BIAB",
  "policies": ["19","54","85","105","20","107","108","110","113","129","130","131","133"],
  "iat": 1781887536,
  "exp": 1781923536
}
```

`exp - iat = 36000 seconds = 10 hours` — matches `tokenTimeout`.

---

## Two Domains — Critical Architecture

| Domain | Purpose |
|--------|---------|
| `www.pb77.co` | Login, account, OTP, exchange handshake |
| `ex.pb77.co` | Everything exchange: markets, prices, orders, streaming |

The `BIAB_CUSTOMER` cookie has `domain=.pb77.co` — the httpx cookie jar sends it to **both** domains automatically.

---

## Required headers (confirmed)

| Header | Value | Where |
|--------|-------|-------|
| `Language` | `en-US` | All requests |
| `Clienttype` | `2` | All requests (www only) |
| `Token` | `<token from Step 2>` | Authenticated www requests |
| `BIAB_CUSTOMER` | JWT cookie (auto via cookie jar) | All ex.pb77.co requests |

---

## Implementation

```python
from dataclasses import dataclass
from datetime import datetime, timedelta
from urllib.parse import quote
import httpx

WWW_BASE = "https://www.pb77.co"
EX_BASE  = "https://ex.pb77.co"

COMMON_HEADERS = {
    "Language": "en-US",
    "Clienttype": "2",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
    "Origin": "https://www.pb77.co",
    "Referer": "https://www.pb77.co/",
}

@dataclass
class PB77Session:
    token: str
    member_id: int
    email: str
    nickname: str
    currency_code: str        # "INR"
    currency_symbol: str      # "₹"
    balance: float
    biab_jwt: str             # BIAB_CUSTOMER cookie value
    exchange_url: str         # "https://ex.pb77.co"
    expires_at: datetime


class PB77Auth:
    def __init__(self):
        self._http = httpx.AsyncClient(headers=COMMON_HEADERS)
        self.session: PB77Session | None = None

    async def request_otp(self, email: str) -> bool:
        resp = await self._http.post(
            f"{WWW_BASE}/api/v2/otp/email",
            params={"used": "true", "email": email},
        )
        return resp.json().get("status") == 200

    async def verify_otp(self, email: str, otp: str) -> bool:
        resp = await self._http.post(
            f"{WWW_BASE}/api/v2/login/email",
            content=f"email={quote(email)}&otp={otp}",
            headers={"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"},
        )
        body = resp.json()
        if body.get("status") != 200:
            return False
        d = body["data"]
        self._pending = d  # store until exchange handshake
        return True

    async def exchange_handshake(self) -> PB77Session | None:
        d = self._pending
        token = d["token"]
        nickname = d["nickname"]

        # Add token header for this call
        resp = await self._http.post(
            f"{WWW_BASE}/api/exchange2",
            params={"token": token, "name": nickname},
            headers={"Token": token},
        )
        body = resp.json()
        if body.get("status") != 200:
            return None

        ex_data = body["data"]
        timeout = d.get("logoutSetting", {}).get("tokenTimeout", 36000)

        self.session = PB77Session(
            token=token,
            member_id=d["memberId"],
            email=d["email"],
            nickname=nickname,
            currency_code=d["currencyCode"],
            currency_symbol=d["currencySymbol"],
            balance=d.get("currencyBalance", 0.0),
            biab_jwt=ex_data["BIAB_CUSTOMER"],
            exchange_url=ex_data["biabUrl"],           # "https://ex.pb77.co"
            expires_at=datetime.utcnow() + timedelta(seconds=timeout),
        )
        # Cookie jar already has BIAB_CUSTOMER from Set-Cookie header
        # Add Token header permanently for www calls
        self._http.headers["Token"] = token
        return self.session

    def is_logged_in(self) -> bool:
        return (
            self.session is not None
            and datetime.utcnow() < self.session.expires_at - timedelta(minutes=5)
        )

    async def logout(self):
        self.session = None
        self._http.cookies.clear()
        self._http.headers.pop("Token", None)
```

## Status
- [x] Step 1 — trigger OTP confirmed
- [x] Step 2 — verify OTP + token confirmed
- [x] Step 3 — exchange handshake confirmed
- [x] Token header name confirmed: `Token: <value>`
- [x] Exchange domain confirmed: `ex.pb77.co`
- [x] BIAB_CUSTOMER cookie mechanism confirmed
- [x] Token lifetime: 10 hours confirmed
- [x] Implementation written — ready to build
