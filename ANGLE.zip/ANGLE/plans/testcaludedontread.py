#!/usr/bin/env python3
"""
Smart Decoder / Encoder GUI
----------------------------
A simple Tkinter desktop tool with two tabs:

  DECODE tab:
    Paste any string (Base64 or Hex) and hit "Smart Decode".
    It will automatically try, in order:
      1. Base64 decode (or Hex decode if Base64 fails)
      2. Standard gzip decompression
      3. Standard zlib (with header) decompression
      4. Raw DEFLATE decompression, trying header offsets 0-15
         (this is what handled the custom 10-byte header payload
         we decoded manually earlier)
    Whatever step succeeds first that yields readable text is shown,
    plus a log of every step it tried.

  ENCODE tab:
    Paste plain text, pick an output format, and it produces the
    encoded string (reverse of the above): Base64, Base64+Gzip,
    Base64+Raw-Deflate, Hex, or URL-encoded.

No external dependencies -- only the Python standard library.
On Linux you may need: sudo apt install python3-tk
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import base64
import zlib
import gzip
import urllib.parse


# ----------------------------- decode helpers -----------------------------

def try_base64(s: str):
    s = s.strip()
    # tolerate missing padding
    padded = s + "=" * (-len(s) % 4)
    try:
        return base64.b64decode(padded, validate=False)
    except Exception:
        return None


def try_hex(s: str):
    s = s.strip().replace(" ", "").replace("\n", "")
    try:
        return bytes.fromhex(s)
    except Exception:
        return None


def try_decompress(data: bytes):
    """
    Try several decompression strategies and collect every one that
    succeeds without erroring. A small header-skip offset can produce
    a tiny, garbage "successful" decompress purely by coincidence, so
    instead of returning the first hit, we score every candidate and
    keep the best one (prefer valid UTF-8 text, then longest output).
    Returns (bytes, method) or (None, None).
    """
    candidates = []

    # 1. standard gzip (magic bytes 1f 8b)
    try:
        candidates.append((gzip.decompress(data), "gzip"))
    except Exception:
        pass

    # 2. standard zlib (has its own 2-byte header)
    try:
        candidates.append((zlib.decompress(data), "zlib (with header)"))
    except Exception:
        pass

    # 3. raw deflate, trying different leading-byte offsets
    #    (handles custom/non-standard headers like the 10-byte
    #    header seen on some API payloads)
    for skip in range(0, 16):
        try:
            d = zlib.decompressobj(-15)  # -15 = raw deflate, no header
            out = d.decompress(data[skip:])
            out += d.flush()
            if out:
                candidates.append((out, f"raw deflate (skipped {skip} header byte{'s' if skip != 1 else ''})"))
        except Exception:
            continue

    if not candidates:
        return None, None

    def score(candidate):
        out_bytes, _ = candidate
        try:
            out_bytes.decode("utf-8")
            is_text = 1
        except UnicodeDecodeError:
            is_text = 0
        return (is_text, len(out_bytes))

    return max(candidates, key=score)


def smart_decode(input_text: str):
    """Returns (result_text, log_lines)."""
    log = []
    raw = try_base64(input_text)
    if raw is not None:
        log.append(f"Step 1: Base64-decoded input -> {len(raw)} bytes")
    else:
        raw = try_hex(input_text)
        if raw is not None:
            log.append(f"Step 1: Base64 failed, Hex-decoded input -> {len(raw)} bytes")
        else:
            log.append("Step 1: Neither Base64 nor Hex decoding worked.")
            return None, log

    decompressed, method = try_decompress(raw)
    if decompressed is not None:
        log.append(f"Step 2: Decompressed via {method} -> {len(decompressed)} bytes")
        try:
            text = decompressed.decode("utf-8")
            log.append("Step 3: Decoded as UTF-8 text")
            return text, log
        except UnicodeDecodeError:
            log.append("Step 3: Not valid UTF-8, showing as hex")
            return decompressed.hex(), log
    else:
        log.append("Step 2: No compression detected, treating raw bytes as final output")
        try:
            text = raw.decode("utf-8")
            log.append("Step 3: Decoded as UTF-8 text")
            return text, log
        except UnicodeDecodeError:
            log.append("Step 3: Not valid UTF-8, showing as hex")
            return raw.hex(), log


# ----------------------------- encode helpers -----------------------------

ENCODE_MODES = [
    "Base64",
    "Base64 + Gzip",
    "Base64 + Raw Deflate",
    "Hex",
    "URL encode",
]


def smart_encode(text: str, mode: str) -> str:
    data = text.encode("utf-8")
    if mode == "Base64":
        return base64.b64encode(data).decode()
    elif mode == "Base64 + Gzip":
        compressed = gzip.compress(data)
        return base64.b64encode(compressed).decode()
    elif mode == "Base64 + Raw Deflate":
        co = zlib.compressobj(9, zlib.DEFLATED, -15)
        compressed = co.compress(data) + co.flush()
        return base64.b64encode(compressed).decode()
    elif mode == "Hex":
        return data.hex()
    elif mode == "URL encode":
        return urllib.parse.quote(text)
    return ""


# --------------------------------- GUI -------------------------------------

class DecoderApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Smart Decoder / Encoder")
        self.geometry("640x560")
        self.minsize(560, 480)

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.decode_tab = ttk.Frame(notebook)
        self.encode_tab = ttk.Frame(notebook)
        notebook.add(self.decode_tab, text="Decode")
        notebook.add(self.encode_tab, text="Encode")

        self._build_decode_tab()
        self._build_encode_tab()

    # ---- Decode tab ----
    def _build_decode_tab(self):
        f = self.decode_tab

        ttk.Label(f, text="Paste string to decode:").pack(anchor="w", pady=(8, 2))
        self.decode_input = scrolledtext.ScrolledText(f, height=6, wrap="word")
        self.decode_input.pack(fill="x", padx=2)

        btn_row = ttk.Frame(f)
        btn_row.pack(fill="x", pady=8)
        ttk.Button(btn_row, text="Smart Decode", command=self.on_smart_decode).pack(side="left")
        ttk.Button(btn_row, text="Clear", command=self.on_decode_clear).pack(side="left", padx=6)
        ttk.Button(btn_row, text="Copy Result", command=self.on_copy_decode_result).pack(side="left")

        ttk.Label(f, text="Result:").pack(anchor="w")
        self.decode_output = scrolledtext.ScrolledText(f, height=8, wrap="word")
        self.decode_output.pack(fill="both", expand=True, padx=2)

        ttk.Label(f, text="Steps tried:").pack(anchor="w", pady=(8, 2))
        self.decode_log = scrolledtext.ScrolledText(f, height=6, wrap="word", state="disabled")
        self.decode_log.pack(fill="x", padx=2, pady=(0, 8))

    def on_smart_decode(self):
        input_text = self.decode_input.get("1.0", "end").strip()
        if not input_text:
            messagebox.showinfo("Smart Decode", "Paste a string first.")
            return

        result, log = smart_decode(input_text)

        self.decode_output.delete("1.0", "end")
        self.decode_output.insert("1.0", result if result is not None else "(could not decode)")

        self.decode_log.config(state="normal")
        self.decode_log.delete("1.0", "end")
        self.decode_log.insert("1.0", "\n".join(log))
        self.decode_log.config(state="disabled")

    def on_decode_clear(self):
        self.decode_input.delete("1.0", "end")
        self.decode_output.delete("1.0", "end")
        self.decode_log.config(state="normal")
        self.decode_log.delete("1.0", "end")
        self.decode_log.config(state="disabled")

    def on_copy_decode_result(self):
        text = self.decode_output.get("1.0", "end").strip()
        if text:
            self.clipboard_clear()
            self.clipboard_append(text)

    # ---- Encode tab ----
    def _build_encode_tab(self):
        f = self.encode_tab

        ttk.Label(f, text="Paste plain text to encode:").pack(anchor="w", pady=(8, 2))
        self.encode_input = scrolledtext.ScrolledText(f, height=6, wrap="word")
        self.encode_input.pack(fill="x", padx=2)

        mode_row = ttk.Frame(f)
        mode_row.pack(fill="x", pady=8)
        ttk.Label(mode_row, text="Output format:").pack(side="left")
        self.encode_mode = tk.StringVar(value=ENCODE_MODES[0])
        mode_dropdown = ttk.Combobox(
            mode_row, textvariable=self.encode_mode, values=ENCODE_MODES, state="readonly", width=24
        )
        mode_dropdown.pack(side="left", padx=8)

        btn_row = ttk.Frame(f)
        btn_row.pack(fill="x", pady=4)
        ttk.Button(btn_row, text="Encode", command=self.on_encode).pack(side="left")
        ttk.Button(btn_row, text="Clear", command=self.on_encode_clear).pack(side="left", padx=6)
        ttk.Button(btn_row, text="Copy Result", command=self.on_copy_encode_result).pack(side="left")

        ttk.Label(f, text="Result:").pack(anchor="w", pady=(8, 2))
        self.encode_output = scrolledtext.ScrolledText(f, height=10, wrap="word")
        self.encode_output.pack(fill="both", expand=True, padx=2, pady=(0, 8))

    def on_encode(self):
        input_text = self.encode_input.get("1.0", "end").strip("\n")
        if not input_text:
            messagebox.showinfo("Encode", "Paste some text first.")
            return
        mode = self.encode_mode.get()
        result = smart_encode(input_text, mode)
        self.encode_output.delete("1.0", "end")
        self.encode_output.insert("1.0", result)

    def on_encode_clear(self):
        self.encode_input.delete("1.0", "end")
        self.encode_output.delete("1.0", "end")

    def on_copy_encode_result(self):
        text = self.encode_output.get("1.0", "end").strip()
        if text:
            self.clipboard_clear()
            self.clipboard_append(text)


if __name__ == "__main__":
    app = DecoderApp()
    app.mainloop()