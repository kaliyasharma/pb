# Step 06 — Order Placement + Full Ladder

## Status: IMPLEMENTED (payload needs one live capture to confirm)

Real-money path. Bets only ever go out on an explicit user click — nothing auto-fires.

---

## Ladder view (`pb77/ui/ladder_view.py`)

A full 1.01→1000 price ladder **per selection**, generalised from `laddercal.py`
(which was hard-wired to 2 slots) to render a column for **every** runner.

- Odds ladder: `pb77/api/ladder.py` → `LADDER_ODDS` (350 ticks, Betfair increments,
  displayed descending so short prices sit at the bottom).
- Each column is a `QTableWidget` (`[Back | Odds | Lay]`, ~350 rows) — far lighter
  than thousands of `QFrame`s. Each column scrolls **independently** (own scrollbar)
  and self-centres on its own live price on first data.
- Live amounts come from the **same `MarketBook`** the grid uses (catb/catl best
  levels). The ladder layout has every price row, but only the best levels carry
  amounts at any moment — identical to laddercal's behaviour.
- Centre toggle in the top bar switches Grid ⇄ Ladder (`QStackedWidget`).

### Ported features
| Feature | How |
|---------|-----|
| Stake presets | 8 editable fields; click selects (gold highlight) |
| One-click bet | single mode → click a cell → place at selected stake |
| Multi-bet queue | Multi toggle → click cells to queue (orange + stake stamp) → **Fire (N)** places all together |
| Cancel All | red button → `cancelBets/all` for the market |
| Liquidity calc | per-selection, sum available back/lay over an odds range (reads raw `back_amt`/`lay_amt`, not the lossy cell text) |

---

## Order placement (`pb77/api/client.py`)

### Place — `POST /customer/api/placeBets`  ✅ CONFIRMED from live capture
```json
{
  "1.259306809": [
    {
      "selectionId": 414464, "handicap": 0,
      "price": 1.1, "size": 225, "side": "BACK",
      "betUuid": "1.259306809_414464_0__1781947205129-vm2lq_INLINE",
      "betType": "EXCHANGE", "persistenceType": "LAPSE", "applicationType": "WEB",
      "netPLBetslipEnabled": false, "netPLMarketPageEnabled": false,
      "quickStakesEnabled": true, "confirmBetsEnabled": false,
      "showLayOddsEnabled": false, "mobile": false, "isEachWay": false,
      "eachWayData": {}, "openBetsEnabled": false, "page": "market",
      "placedUsingEnterKey": false
    }
  ]
}
```
- `price`/`size` are **numbers**, not strings
- `betUuid` = `{marketId}_{selectionId}_{handicap}__{epoch_ms}-{rand5}_INLINE`
- Header `X-Csrf-Token` = value of the `CSRF-TOKEN` cookie (`client.csrf_token()`) — **required**
- `mobile` set to `false` (capture was mobile=true; we send `X-Device: DESKTOP`)
- `Content-Type: application/json`, plus standard `EX_HEADERS`

### CSRF / BIAB cookies — `_ensure_biab_cookies()`
The server never Set-Cookie's `CSRF-TOKEN`; the SPA mints it client-side (double-submit:
cookie value must equal the `X-Csrf-Token` header, server only compares). So the app
generates it itself (UUID4) plus `BIAB_AN` (anon id), `BIAB_LANGUAGE=en`,
`BIAB_TZ` (= JS `getTimezoneOffset()`), only when absent (server value wins if present).
Called after the exchange handshake and again before every place/cancel.

### Cancel — `POST /customer/api/cancelBets/all`
```json
{ "betTypes": ["EXCHANGE"], "marketId": "1.259306809" }
```

### Still unconfirmed
- [ ] **placeBets response envelope** — only the request was captured. `_parse_bet_result`
      is generic (treats 2xx-without-error as success). Capture a response to lock it.
- [x] CSRF-TOKEN cookie — confirmed present in browser; `place_bets` now guards on it
      (returns `NO_CSRF` if the jar has no token yet).

---

## Traded volume — `MARKET_GRAPHS` ✅ IMPLEMENTED + envelope CONFIRMED
- Opening the ladder fires the browser's full "open graphs" handshake on the same socket
  (`PriceStream._send_graph_subscribe()`, object-in-string form, re-sent on reconnect):
  `EVENT_UPDATES{subscribe:false}` → `OPEN_BETS_COUNTER{subscribe:false}` →
  one `MARKET_GRAPHS{subscribe:true, selectionId:"…"}` **per selection** →
  `MARKET_DEFINITIONS{subscribe:true, marketIds:[…]}`.
- **Confirmed response envelope** (one frame per selection, full snapshot):
  `{"MARKET_GRAPHS":{"status":"READY","marketId":"1.…","selectionId":414464,"handicap":0.0,
  "points":[{"value":1.40,"volume":394.45,"timestamp":…}, …]}}`. `selectionId` is an int at
  the object level; `points` is the entire traded history. `extract_graph_points()` tags
  every point with that selectionId and is a no-op on `rc`/definition/CLOSED frames.
- **Aggregation = replace-per-selection.** Each frame is a full `READY` snapshot, so
  `MainWindow._on_graph` rebuilds that selection's `{price: total}` from the frame (summing
  its points) and **replaces** `self._traded[sel]` — never accumulates across frames, else a
  re-sent snapshot would multiply totals.
- Ladder has a dedicated **Vol** column (Back | Odds | Vol | Lay). `LadderView.apply_traded`
  writes the traded total as a visible number with a gold bar scaled by volume share (sqrt).
- **Max 3 ladders** (`LadderView.MAX_LADDERS`): only the first 3 runners get columns; title
  shows `(+N more)`. `MainWindow` subscribes graphs for those 3 selections only.

### Confirmed live
- [x] Envelope + selection attribution (selectionId present at object level → tagged).
- [x] Full handshake replicated (EVENT_UPDATES/OPEN_BETS_COUNTER off, MARKET_GRAPHS per
      selection, MARKET_DEFINITIONS on).
- [x] Snapshots are full (`status:READY`, identical on resend) → replace, not sum.

## Still open
- [ ] Confirm placeBets payload + response (above)
- [ ] List/show open bets (OPEN_BETS_COUNTER stream on `general` ws) — for matched/unmatched display
- [ ] Edit bet (cancel + replace vs PATCH)
- [ ] Balance refresh after a bet settles (need account endpoint — step 07)
