"""Central color palette + Qt stylesheet for a dark trading-terminal look."""


class Palette:
    BG = "#0f1115"            # app background
    PANEL = "#171a21"         # panels / cards
    PANEL_HI = "#1f2430"      # raised / hover
    BORDER = "#2a2f3a"
    BORDER_HI = "#3a4150"

    TEXT = "#e6e8ec"
    TEXT_DIM = "#9aa0ab"
    TEXT_FAINT = "#646b78"

    GOLD = "#d4af37"          # pb77 accent
    GOLD_DIM = "#9a8128"

    BACK = "#72bbef"          # Betfair back blue
    BACK_DK = "#4a93c9"
    LAY = "#faa9ba"           # Betfair lay pink
    LAY_DK = "#e07a92"

    GREEN = "#3fb950"
    RED = "#f85149"
    AMBER = "#e3b341"


def stylesheet() -> str:
    p = Palette
    return f"""
    * {{
        font-family: -apple-system, "Segoe UI", "Helvetica Neue", Arial, sans-serif;
        font-size: 13px;
        color: {p.TEXT};
        outline: none;
    }}
    QWidget {{
        background-color: {p.BG};
    }}

    /* ── Cards / panels ── */
    #Card {{
        background-color: {p.PANEL};
        border: 1px solid {p.BORDER};
        border-radius: 12px;
    }}
    #Panel {{
        background-color: {p.PANEL};
        border: 1px solid {p.BORDER};
        border-radius: 10px;
    }}

    /* ── Top bar ── */
    #TopBar {{
        background-color: {p.PANEL};
        border-bottom: 1px solid {p.BORDER};
    }}
    #Brand {{
        font-size: 18px;
        font-weight: 800;
        color: {p.GOLD};
        letter-spacing: 1px;
    }}
    #BalancePill {{
        background-color: {p.PANEL_HI};
        border: 1px solid {p.BORDER_HI};
        border-radius: 14px;
        padding: 4px 14px;
        font-weight: 700;
        color: {p.GREEN};
    }}
    #AccountName {{
        color: {p.TEXT_DIM};
        font-weight: 600;
    }}

    /* ── Headings ── */
    #H1 {{ font-size: 22px; font-weight: 800; }}
    #H2 {{ font-size: 15px; font-weight: 700; }}
    #Subtle {{ color: {p.TEXT_DIM}; }}
    #Faint  {{ color: {p.TEXT_FAINT}; }}
    #SectionLabel {{
        color: {p.TEXT_FAINT};
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1px;
    }}

    /* ── Inputs ── */
    QLineEdit {{
        background-color: {p.BG};
        border: 1px solid {p.BORDER_HI};
        border-radius: 8px;
        padding: 9px 12px;
        selection-background-color: {p.GOLD_DIM};
    }}
    QLineEdit:focus {{
        border: 1px solid {p.GOLD};
    }}
    QLineEdit::placeholder {{
        color: {p.TEXT_FAINT};
    }}

    /* ── Buttons ── */
    QPushButton {{
        background-color: {p.PANEL_HI};
        border: 1px solid {p.BORDER_HI};
        border-radius: 8px;
        padding: 9px 16px;
        font-weight: 600;
    }}
    QPushButton:hover {{ background-color: {p.BORDER}; }}
    QPushButton:pressed {{ background-color: {p.BORDER_HI}; }}
    QPushButton:disabled {{ color: {p.TEXT_FAINT}; background-color: {p.PANEL}; }}

    QPushButton#Primary {{
        background-color: {p.GOLD};
        color: #1a1500;
        border: none;
        font-weight: 800;
    }}
    QPushButton#Primary:hover {{ background-color: #e6c14e; }}
    QPushButton#Primary:disabled {{ background-color: {p.GOLD_DIM}; color: #4a4020; }}

    QPushButton#Ghost {{
        background-color: transparent;
        border: 1px solid {p.BORDER_HI};
    }}
    QPushButton#Ghost:hover {{ background-color: {p.PANEL_HI}; }}

    QPushButton#Link {{
        background: transparent;
        border: none;
        color: {p.GOLD};
        font-weight: 600;
        padding: 4px;
    }}
    QPushButton#Link:hover {{ color: #e6c14e; }}

    /* ── Sidebar sports list ── */
    #Sidebar {{
        background-color: {p.PANEL};
        border-right: 1px solid {p.BORDER};
    }}
    QListWidget {{
        background-color: transparent;
        border: none;
        padding: 6px;
    }}
    QListWidget::item {{
        padding: 10px 12px;
        border-radius: 8px;
        margin: 2px 4px;
        color: {p.TEXT_DIM};
    }}
    QListWidget::item:hover {{
        background-color: {p.PANEL_HI};
        color: {p.TEXT};
    }}
    QListWidget::item:selected {{
        background-color: {p.PANEL_HI};
        color: {p.GOLD};
        border-left: 2px solid {p.GOLD};
    }}

    /* ── Navigation tree (accordion, single column) ── */
    #NavTree {{
        background-color: {p.PANEL};
        border: none;
        border-top: 1px solid {p.BORDER};
        padding: 4px 0;
    }}
    #NavTree::item {{
        padding: 9px 8px;
        border-radius: 0;
        color: {p.TEXT};
        border: none;
    }}
    #NavTree::item:hover {{
        background-color: {p.PANEL_HI};
    }}
    #NavTree::item:selected {{
        background-color: rgba(212, 175, 55, 0.12);
        border-left: 2px solid {p.GOLD};
    }}
    #NavTree::branch {{
        background: {p.PANEL};
    }}
    QHeaderView::section {{
        background-color: {p.PANEL};
        color: {p.TEXT_FAINT};
        border: none;
        border-bottom: 1px solid {p.BORDER};
        padding: 6px 8px;
        font-weight: 700;
        font-size: 11px;
    }}

    /* ── Scrollbars ── */
    QScrollBar:vertical {{
        background: transparent;
        width: 10px;
        margin: 2px;
    }}
    QScrollBar::handle:vertical {{
        background: {p.BORDER_HI};
        border-radius: 5px;
        min-height: 30px;
    }}
    QScrollBar::handle:vertical:hover {{ background: {p.TEXT_FAINT}; }}
    QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
    QScrollBar:horizontal {{ height: 10px; background: transparent; }}
    QScrollBar::handle:horizontal {{ background: {p.BORDER_HI}; border-radius: 5px; }}

    /* ── Status bar ── */
    QStatusBar {{
        background-color: {p.PANEL};
        border-top: 1px solid {p.BORDER};
        color: {p.TEXT_DIM};
    }}
    QStatusBar::item {{ border: none; }}

    /* ── Premium Login Dialog ── */
    QDialog {{
        background-color: {p.BG};
    }}
    #LoginAccent {{
        background-color: qlineargradient(
            x1:0, y1:0, x2:1, y2:0,
            stop:0 #a07c20, stop:0.4 {p.GOLD}, stop:0.6 {p.GOLD}, stop:1 #a07c20
        );
        border: none;
    }}
    #LoginCard {{
        background-color: rgba(16, 19, 26, 242);
        border: 1px solid {p.BORDER_HI};
        border-top: none;
    }}
    #LoginWordmark {{
        font-size: 56px;
        font-weight: 900;
        color: {p.GOLD};
        letter-spacing: -2px;
    }}
    #LoginTagline {{
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 5px;
        color: {p.TEXT_FAINT};
    }}
    #LoginDivider {{
        background-color: qlineargradient(
            x1:0, y1:0, x2:1, y2:0,
            stop:0 transparent, stop:0.3 {p.BORDER_HI}, stop:0.7 {p.BORDER_HI}, stop:1 transparent
        );
        border: none;
    }}
    #LoginHeading {{
        font-size: 18px;
        font-weight: 700;
        color: {p.TEXT};
    }}
    #LoginFieldLabel {{
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 2px;
        color: {p.TEXT_FAINT};
    }}
    #LoginInput {{
        background-color: transparent;
        border: none;
        border-bottom: 2px solid {p.BORDER_HI};
        border-radius: 0;
        padding: 10px 2px;
        font-size: 15px;
        color: {p.TEXT};
        selection-background-color: {p.GOLD_DIM};
    }}
    #LoginInput:focus {{
        border-bottom: 2px solid {p.GOLD};
    }}
    #LoginInput::placeholder {{
        color: {p.TEXT_FAINT};
    }}
    #LoginInput[readOnly="true"] {{
        color: {p.TEXT_DIM};
        border-bottom: 2px solid {p.BORDER};
    }}
    #LoginBtn {{
        background-color: qlineargradient(
            x1:0, y1:0, x2:0, y2:1,
            stop:0 #e8c547, stop:1 {p.GOLD}
        );
        color: #12100a;
        border: none;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 800;
        letter-spacing: 0.5px;
    }}
    #LoginBtn:hover {{
        background-color: qlineargradient(
            x1:0, y1:0, x2:0, y2:1,
            stop:0 #f0d060, stop:1 #e0be40
        );
    }}
    #LoginBtn:pressed {{
        background-color: {p.GOLD_DIM};
    }}
    #LoginBtn:disabled {{
        background-color: #3a3520;
        color: #6a5f30;
    }}
    #LoginLink {{
        background: transparent;
        border: none;
        color: {p.GOLD_DIM};
        font-size: 12px;
        font-weight: 600;
        padding: 4px;
    }}
    #LoginLink:hover {{ color: {p.GOLD}; }}
    #LoginStatus {{
        font-size: 12px;
        min-height: 18px;
        padding-top: 4px;
    }}
    #LoginFooter {{
        font-size: 11px;
        color: {p.TEXT_FAINT};
        letter-spacing: 0.3px;
    }}

    /* ── View toggle (Grid / Ladder segmented control) ── */
    #ViewToggle {{
        background-color: {p.PANEL};
        border-bottom: 1px solid {p.BORDER};
    }}
    QPushButton#Segment {{
        background-color: transparent;
        border: 1px solid {p.BORDER_HI};
        border-radius: 7px;
        padding: 6px 16px;
        font-weight: 700;
        color: {p.TEXT_DIM};
    }}
    QPushButton#Segment:hover {{ background-color: {p.PANEL_HI}; }}
    QPushButton#Segment:checked {{
        background-color: {p.GOLD};
        color: #1a1500;
        border: 1px solid {p.GOLD};
    }}

    /* ── Stake fields ── */
    QLineEdit#StakeField {{
        background-color: {p.BG};
        border: 1px solid {p.BORDER_HI};
        border-radius: 7px;
        padding: 6px 4px;
        font-weight: 700;
        font-size: 13px;
        color: {p.TEXT};
    }}
    QLineEdit#StakeField[selected="true"] {{
        background-color: {p.GOLD};
        color: #1a1500;
        border: 1px solid {p.GOLD};
    }}

    /* ── Danger button (Cancel All) ── */
    QPushButton#Danger {{
        background-color: {p.RED};
        color: white;
        border: none;
        border-radius: 8px;
        padding: 9px 16px;
        font-weight: 800;
    }}
    QPushButton#Danger:hover {{ background-color: #ff6258; }}
    QPushButton#Danger:pressed {{ background-color: #d83a32; }}

    /* ── Ladder ── */
    QTableWidget#Ladder {{
        background-color: {p.BG};
        border: none;
        gridline-color: transparent;
    }}
    QTableWidget#Ladder::item {{
        padding: 0;
        border-bottom: 1px solid #0c0e12;
    }}
    #LadderBox {{
        background-color: {p.PANEL};
        border: 1px solid {p.BORDER};
        border-radius: 8px;
    }}
    #LadderTitle {{
        background-color: {p.PANEL_HI};
        color: {p.TEXT};
        font-weight: 800;
        font-size: 13px;
        padding: 8px 6px;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }}
    #LiqBack {{ color: {p.BACK}; font-weight: 800; }}
    #LiqLay  {{ color: {p.LAY}; font-weight: 800; }}

    /* ── Misc ── */
    #Badge {{
        background-color: {p.GOLD_DIM};
        color: #1a1500;
        border-radius: 8px;
        padding: 1px 8px;
        font-size: 10px;
        font-weight: 800;
    }}
    #BadgeLive {{
        background-color: {p.RED};
        color: white;
        border-radius: 8px;
        padding: 1px 8px;
        font-size: 10px;
        font-weight: 800;
    }}
    #Divider {{ background-color: {p.BORDER}; }}
    """
