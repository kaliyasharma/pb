"""
Live debug log window.

A separate, non-modal window that streams every Python log record (WebSocket
traffic, bet requests/responses, graph frames, …) into a scrolling text view,
with a Clear button. Wire it up by attaching `handler` to the root logger.

Temporary debugging aid — remove the LogWindow wiring from MainWindow to drop it.
"""
from __future__ import annotations

import logging

from PyQt6.QtCore import Qt, QObject, pyqtSignal
from PyQt6.QtGui import QFont, QTextCursor
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPlainTextEdit, QPushButton,
    QLabel, QCheckBox, QLineEdit,
)

MAX_BLOCKS = 5000        # cap kept in the view so it never grows unbounded


class _LogBridge(QObject):
    """Marshals log records (emitted from any thread) onto the Qt main thread."""
    line = pyqtSignal(str)


class QtLogHandler(logging.Handler):
    """A logging.Handler that pushes formatted records to the LogWindow via a signal."""
    def __init__(self, bridge: _LogBridge):
        super().__init__()
        self._bridge = bridge

    def emit(self, record: logging.LogRecord):
        try:
            self._bridge.line.emit(self.format(record))
        except Exception:
            pass


class LogWindow(QWidget):
    """Standalone debug log viewer with Clear / Pause / filter."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("PB77 — Debug Log")
        self.setWindowFlag(Qt.WindowType.Window, True)
        self.resize(900, 520)

        self._bridge = _LogBridge()
        self._bridge.line.connect(self._append)
        self.handler = QtLogHandler(self._bridge)
        self.handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s", datefmt="%H:%M:%S"))

        self._paused = False
        self._filter = ""
        self._build()

    def _build(self):
        v = QVBoxLayout(self)
        v.setContentsMargins(8, 8, 8, 8)
        v.setSpacing(6)

        bar = QHBoxLayout()
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear)
        bar.addWidget(clear_btn)

        self._pause = QCheckBox("Pause")
        self._pause.toggled.connect(lambda on: setattr(self, "_paused", on))
        bar.addWidget(self._pause)

        self._autoscroll = QCheckBox("Auto-scroll")
        self._autoscroll.setChecked(True)
        bar.addWidget(self._autoscroll)

        bar.addSpacing(12)
        bar.addWidget(QLabel("Filter:"))
        self._filter_edit = QLineEdit()
        self._filter_edit.setPlaceholderText("substring, e.g. PLACEBETS or GRAPH or PRICE◄")
        self._filter_edit.textChanged.connect(lambda t: setattr(self, "_filter", t.strip()))
        self._filter_edit.setMaximumWidth(280)
        bar.addWidget(self._filter_edit)

        bar.addStretch()
        self._count = QLabel("0 lines")
        bar.addWidget(self._count)
        v.addLayout(bar)

        self._view = QPlainTextEdit()
        self._view.setReadOnly(True)
        self._view.setMaximumBlockCount(MAX_BLOCKS)
        self._view.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        f = QFont("Menlo"); f.setStyleHint(QFont.StyleHint.Monospace); f.setPointSize(11)
        self._view.setFont(f)
        v.addWidget(self._view, stretch=1)

        self._lines = 0

    def _append(self, text: str):
        if self._paused:
            return
        if self._filter and self._filter.lower() not in text.lower():
            return
        self._view.appendPlainText(text)
        self._lines += 1
        self._count.setText(f"{self._lines} lines")
        if self._autoscroll.isChecked():
            self._view.moveCursor(QTextCursor.MoveOperation.End)

    def clear(self):
        self._view.clear()
        self._lines = 0
        self._count.setText("0 lines")
