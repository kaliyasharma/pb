"""Premium login dialog with animated odds-stream background."""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThreadPool
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFrame, QSizePolicy, QSpacerItem,
)

from pb77.api.client import PB77Client
from pb77.api.models import Session
from pb77.ui.workers import Worker
from pb77.ui.anim_bg import AnimatedBg


class LoginDialog(QDialog):
    def __init__(self, client: PB77Client, pool: QThreadPool, parent=None):
        super().__init__(parent)
        self._client = client
        self._pool = pool
        self._email = ""
        self.session: Session | None = None

        self.setWindowTitle("PB77 — Sign In")
        self.setFixedWidth(520)
        self.setWindowFlag(Qt.WindowType.WindowContextHelpButtonHint, False)

        # Animated background sits behind everything
        self._bg = AnimatedBg(self)
        self._bg.lower()

        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Gold accent bar ───────────────────────────────────────────────
        accent = QFrame()
        accent.setObjectName("LoginAccent")
        accent.setFixedHeight(4)
        root.addWidget(accent)

        # ── Card body — centered with visible animation margins ───────────
        card = QFrame()
        card.setObjectName("LoginCard")
        card.setFixedWidth(410)
        cl = QVBoxLayout(card)
        cl.setContentsMargins(48, 40, 48, 40)
        cl.setSpacing(0)

        # Brand block
        brand = QLabel("PB77")
        brand.setObjectName("LoginWordmark")
        brand.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cl.addWidget(brand)

        cl.addSpacing(4)

        tagline = QLabel("PREMIUM BET EXCHANGE")
        tagline.setObjectName("LoginTagline")
        tagline.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cl.addWidget(tagline)

        cl.addSpacing(32)

        # Divider
        div = QFrame()
        div.setObjectName("LoginDivider")
        div.setFixedHeight(1)
        cl.addWidget(div)

        cl.addSpacing(32)

        # Sign-in heading
        heading = QLabel("Sign in to your account")
        heading.setObjectName("LoginHeading")
        heading.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cl.addWidget(heading)

        cl.addSpacing(28)

        # Email field
        self._lbl_email = QLabel("EMAIL ADDRESS")
        self._lbl_email.setObjectName("LoginFieldLabel")
        cl.addWidget(self._lbl_email)
        cl.addSpacing(6)

        self._email_input = QLineEdit()
        self._email_input.setObjectName("LoginInput")
        self._email_input.setPlaceholderText("you@email.com")
        self._email_input.returnPressed.connect(self._send_otp)
        cl.addWidget(self._email_input)

        cl.addSpacing(20)

        # OTP field (hidden initially)
        self._lbl_otp = QLabel("ONE-TIME CODE")
        self._lbl_otp.setObjectName("LoginFieldLabel")
        self._otp_input = QLineEdit()
        self._otp_input.setObjectName("LoginInput")
        self._otp_input.setPlaceholderText("Enter 6-digit code")
        self._otp_input.setMaxLength(6)
        self._otp_input.returnPressed.connect(self._login)
        self._lbl_otp.hide()
        self._otp_input.hide()
        cl.addWidget(self._lbl_otp)
        cl.addSpacing(6)
        cl.addWidget(self._otp_input)

        self._otp_spacer = QSpacerItem(0, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        cl.addItem(self._otp_spacer)

        # Primary button
        self._primary = QPushButton("Send OTP")
        self._primary.setObjectName("LoginBtn")
        self._primary.setFixedHeight(52)
        self._primary.clicked.connect(self._send_otp)
        cl.addWidget(self._primary)

        cl.addSpacing(12)

        # Secondary link
        self._secondary = QPushButton("Use a different email")
        self._secondary.setObjectName("LoginLink")
        self._secondary.clicked.connect(self._reset)
        self._secondary.hide()
        cl.addWidget(self._secondary, alignment=Qt.AlignmentFlag.AlignCenter)

        # Status
        self._status = QLabel("")
        self._status.setObjectName("LoginStatus")
        self._status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._status.setWordWrap(True)
        cl.addWidget(self._status)

        cl.addSpacing(28)

        # Footer
        footer = QLabel("🔒  Secured with 256-bit SSL encryption")
        footer.setObjectName("LoginFooter")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cl.addWidget(footer)

        # Center card horizontally so animation shows on both sides
        center = QHBoxLayout()
        center.addStretch()
        center.addWidget(card)
        center.addStretch()
        root.addSpacing(16)
        root.addLayout(center)
        root.addSpacing(16)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._bg.resize(self.size())

    def showEvent(self, event):
        super().showEvent(event)
        self._bg.resize(self.size())

    # ── Flow ──────────────────────────────────────────────────────────────────

    def _send_otp(self):
        if self._otp_input.isVisible():
            return
        email = self._email_input.text().strip()
        if "@" not in email:
            self._error("Enter a valid email address.")
            return
        self._email = email
        self._busy("Sending verification code…")
        w = Worker(self._client.request_otp, email)
        w.signals.result.connect(lambda _: self._otp_sent())
        w.signals.error.connect(self._error)
        self._pool.start(w)

    def _otp_sent(self):
        self._lbl_otp.show()
        self._otp_input.show()
        self._secondary.show()
        self._email_input.setReadOnly(True)
        self._primary.setText("Verify & Continue")
        self._primary.setEnabled(True)
        self._primary.clicked.disconnect()
        self._primary.clicked.connect(self._login)
        self._otp_input.setFocus()
        self._ok(f"Code sent to {self._email}")
        self.adjustSize()

    def _login(self):
        otp = self._otp_input.text().strip()
        if len(otp) != 6 or not otp.isdigit():
            self._error("Enter the 6-digit code from your email.")
            return
        self._busy("Authenticating…")
        w = Worker(self._client.login, self._email, otp)
        w.signals.result.connect(self._on_session)
        w.signals.error.connect(self._error)
        self._pool.start(w)

    def _on_session(self, session: Session):
        self.session = session
        self._ok(f"Welcome back, {session.nickname}")
        self.accept()

    def _reset(self):
        self._lbl_otp.hide()
        self._otp_input.hide()
        self._otp_input.clear()
        self._secondary.hide()
        self._email_input.setReadOnly(False)
        self._email_input.setFocus()
        self._primary.setText("Send OTP")
        self._primary.setEnabled(True)
        self._primary.clicked.disconnect()
        self._primary.clicked.connect(self._send_otp)
        self._status.clear()
        self.adjustSize()

    def _busy(self, msg: str):
        self._primary.setEnabled(False)
        self._status.setStyleSheet("color: #9aa0ab; font-size: 12px;")
        self._status.setText(msg)

    def _ok(self, msg: str):
        self._primary.setEnabled(True)
        self._status.setStyleSheet("color: #3fb950; font-size: 12px;")
        self._status.setText(msg)

    def _error(self, msg: str):
        self._primary.setEnabled(True)
        self._status.setStyleSheet("color: #f85149; font-size: 12px;")
        self._status.setText(msg)
