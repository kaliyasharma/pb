"""
Center panel: live market grid (Betfair-style 3-deep back/lay per runner).

Layout per runner row:
    [name]  back[2] back[1] back[0] | lay[0] lay[1] lay[2]
best back (back[0]) sits on the inner-right, best lay (lay[0]) on inner-left.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QFrame, QScrollArea,
)

from pb77.api.models import Market
from pb77.api.prices import MarketBook, RunnerBook, PriceLevel
from pb77.ui.theme import Palette

BACK_LEVELS = 3
LAY_LEVELS = 3
N_BACK_COLS = BACK_LEVELS
N_LAY_COLS = LAY_LEVELS

# Cell styles
_BACK_BG = ["#16242f", "#1a3040", "#1d3c52"]   # deepest → best
_LAY_BG = ["#3a1d28", "#4a2030", "#5a2438"]     # best → deepest


class _Cell(QFrame):
    """A single price/amount cell with two stacked labels."""
    clicked = pyqtSignal()

    def __init__(self, bg: str, odds_color: str):
        super().__init__()
        self.setFixedSize(78, 46)
        self.setStyleSheet(f"background:{bg}; border-radius:6px;")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 4, 2, 4)
        lay.setSpacing(0)
        self._odds = QLabel("")
        self._odds.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._odds.setStyleSheet(f"color:{odds_color}; font-weight:800; font-size:14px; background:transparent;")
        self._amt = QLabel("")
        self._amt.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._amt.setStyleSheet(f"color:{Palette.TEXT_DIM}; font-size:10px; background:transparent;")
        lay.addWidget(self._odds)
        lay.addWidget(self._amt)

    def set_level(self, level: PriceLevel | None):
        if level and level.odds > 0:
            self._odds.setText(f"{level.odds:g}")
            self._amt.setText(f"{level.amount:,.0f}")
        else:
            self._odds.setText("")
            self._amt.setText("")

    def mousePressEvent(self, event):
        self.clicked.emit()
        super().mousePressEvent(event)


class MarketGrid(QWidget):
    # selection_id, side ("BACK"/"LAY"), odds
    bet_clicked = pyqtSignal(int, str, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._market: Market | None = None
        # (selection_id, side, level) -> _Cell
        self._cells: dict[tuple[int, str, int], _Cell] = {}
        self._build()
        self.show_empty()

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(12)

        # Header
        head = QHBoxLayout()
        self._title = QLabel("No market selected")
        self._title.setObjectName("H1")
        head.addWidget(self._title)
        self._live = QLabel("")
        self._live.setObjectName("BadgeLive")
        self._live.hide()
        head.addWidget(self._live)
        head.addStretch()
        self._matched = QLabel("")
        self._matched.setObjectName("Subtle")
        head.addWidget(self._matched)
        root.addLayout(head)

        self._subtitle = QLabel("")
        self._subtitle.setObjectName("Subtle")
        root.addWidget(self._subtitle)

        # Column header (Back all / Lay all)
        self._colhead = QWidget()
        ch = QHBoxLayout(self._colhead)
        ch.setContentsMargins(0, 0, 0, 0)
        ch.addStretch()
        back_lbl = QLabel("Back")
        back_lbl.setFixedWidth(78)
        back_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        back_lbl.setStyleSheet(f"color:{Palette.BACK}; font-weight:700;")
        lay_lbl = QLabel("Lay")
        lay_lbl.setFixedWidth(78)
        lay_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay_lbl.setStyleSheet(f"color:{Palette.LAY}; font-weight:700;")
        ch.addWidget(back_lbl)
        ch.addSpacing(4)
        ch.addWidget(lay_lbl)
        ch.addSpacing(6)
        root.addWidget(self._colhead)

        # Runner rows host (scrollable)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._rows_host = QWidget()
        self._rows = QVBoxLayout(self._rows_host)
        self._rows.setContentsMargins(0, 0, 0, 0)
        self._rows.setSpacing(8)
        self._rows.addStretch()
        scroll.setWidget(self._rows_host)
        root.addWidget(scroll, stretch=1)

    # ── Public API ────────────────────────────────────────────────────────────

    def show_empty(self):
        self._title.setText("No market selected")
        self._subtitle.setText("Pick a market from the navigation tree on the left.")
        self._matched.setText("")
        self._live.hide()
        self._colhead.hide()
        self._clear_rows()

    def set_market(self, market: Market):
        self._market = market
        self._title.setText(market.market_name)
        bits = [b for b in (market.event_name, market.competition_name) if b]
        self._subtitle.setText("  •  ".join(bits))
        self._matched.setText("Matched: —")
        self._live.hide()
        self._colhead.show()
        self._clear_rows()
        self._cells.clear()

        for i, r in enumerate(market.runners):
            self._rows.insertWidget(i, self._runner_row(r.selection_id, r.runner_name))

    def apply_book(self, book: MarketBook):
        if not self._market:
            return
        self._matched.setText(f"Matched: {book.total_matched:,.0f}")
        if book.in_play:
            self._live.setText(f"● LIVE  (delay {book.bet_delay}s)")
            self._live.show()
        else:
            self._live.hide()

        for sid, rb in book.runners.items():
            self._update_runner(sid, rb)

    # ── Row building ──────────────────────────────────────────────────────────

    def _runner_row(self, selection_id: int, name: str) -> QWidget:
        row = QFrame()
        row.setObjectName("Panel")
        h = QHBoxLayout(row)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(4)

        label = QLabel(name)
        label.setStyleSheet("font-weight:700; font-size:14px;")
        label.setMinimumWidth(180)
        h.addWidget(label)
        h.addStretch()

        # Back cells: display order level 2,1,0 (best on the right)
        for lvl in reversed(range(N_BACK_COLS)):
            cell = _Cell(_BACK_BG[lvl], Palette.BACK)
            cell.clicked.connect(lambda sid=selection_id, c=cell: self._emit_bet(sid, "BACK", c))
            self._cells[(selection_id, "BACK", lvl)] = cell
            h.addWidget(cell)

        h.addSpacing(4)

        # Lay cells: display order level 0,1,2 (best on the left)
        for lvl in range(N_LAY_COLS):
            cell = _Cell(_LAY_BG[lvl], Palette.LAY)
            cell.clicked.connect(lambda sid=selection_id, c=cell: self._emit_bet(sid, "LAY", c))
            self._cells[(selection_id, "LAY", lvl)] = cell
            h.addWidget(cell)

        return row

    def _update_runner(self, selection_id: int, rb: RunnerBook):
        for lvl in range(N_BACK_COLS):
            cell = self._cells.get((selection_id, "BACK", lvl))
            if cell:
                cell.set_level(rb.back[lvl] if lvl < len(rb.back) else None)
        for lvl in range(N_LAY_COLS):
            cell = self._cells.get((selection_id, "LAY", lvl))
            if cell:
                cell.set_level(rb.lay[lvl] if lvl < len(rb.lay) else None)

    def _emit_bet(self, selection_id: int, side: str, cell: _Cell):
        text = cell._odds.text()
        if not text:
            return
        try:
            odds = float(text)
        except ValueError:
            return
        self.bet_clicked.emit(selection_id, side, odds)

    def _clear_rows(self):
        while self._rows.count() > 1:   # keep trailing stretch
            item = self._rows.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
