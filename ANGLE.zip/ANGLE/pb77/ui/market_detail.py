"""
Right-hand detail panel shown when a market is selected.

For now it shows market + runner metadata. The live price ladder will plug in
here once the price-data / streaming endpoints (plan steps 04–05) are captured.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QScrollArea,
)

from pb77.api.models import Market


class MarketDetail(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._build()
        self.show_empty()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(12)

        self._title = QLabel()
        self._title.setObjectName("H1")
        self._title.setWordWrap(True)
        root.addWidget(self._title)

        self._subtitle = QLabel()
        self._subtitle.setObjectName("Subtle")
        self._subtitle.setWordWrap(True)
        root.addWidget(self._subtitle)

        divider = QFrame()
        divider.setObjectName("Divider")
        divider.setFixedHeight(1)
        root.addWidget(divider)

        # Runners area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._runners_host = QWidget()
        self._runners_layout = QVBoxLayout(self._runners_host)
        self._runners_layout.setContentsMargins(0, 0, 0, 0)
        self._runners_layout.setSpacing(8)
        self._runners_layout.addStretch()
        scroll.setWidget(self._runners_host)
        root.addWidget(scroll, stretch=1)

    # ── Public API ────────────────────────────────────────────────────────────

    def show_empty(self):
        self._title.setText("No market selected")
        self._subtitle.setText("Pick a market from the navigation tree to view its runners.")
        self._clear_runners()

    def show_market(self, market: Market):
        self._title.setText(market.market_name)
        bits = [b for b in (market.event_name, market.competition_name) if b]
        meta = "  •  ".join(bits)
        start = market.market_start_time.strftime("%a %d %b, %H:%M") if market.market_start_time else "—"
        self._subtitle.setText(
            f"{meta}\nStart: {start}    Commission: {market.commission:.1f}%    "
            f"Type: {market.market_type}    ID: {market.market_id}"
        )
        self._clear_runners()

        header = QLabel("RUNNERS")
        header.setObjectName("SectionLabel")
        self._runners_layout.insertWidget(0, header)

        for idx, r in enumerate(market.runners, start=1):
            self._runners_layout.insertWidget(idx, self._runner_row(idx, r.runner_name, r.selection_id))

    # ── Internals ─────────────────────────────────────────────────────────────

    def _runner_row(self, num: int, name: str, selection_id: int) -> QWidget:
        row = QFrame()
        row.setObjectName("Panel")
        rl = QHBoxLayout(row)
        rl.setContentsMargins(12, 10, 12, 10)

        index = QLabel(str(num))
        index.setObjectName("Faint")
        index.setFixedWidth(20)
        rl.addWidget(index)

        label = QLabel(name)
        label.setStyleSheet("font-weight: 600;")
        rl.addWidget(label)
        rl.addStretch()

        # Placeholder back/lay cells (will become live ladder cells later)
        back = QLabel("—")
        back.setAlignment(Qt.AlignmentFlag.AlignCenter)
        back.setFixedWidth(64)
        back.setStyleSheet("background:#1d2c3a; color:#72bbef; border-radius:6px; padding:6px; font-weight:700;")
        lay = QLabel("—")
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.setFixedWidth(64)
        lay.setStyleSheet("background:#3a1d28; color:#faa9ba; border-radius:6px; padding:6px; font-weight:700;")
        rl.addWidget(back)
        rl.addWidget(lay)

        sid = QLabel(f"#{selection_id}")
        sid.setObjectName("Faint")
        sid.setFixedWidth(90)
        sid.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        rl.addWidget(sid)
        return row

    def _clear_runners(self):
        while self._runners_layout.count() > 1:   # keep the trailing stretch
            item = self._runners_layout.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
