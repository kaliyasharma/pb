"""
Left navigation panel — single accordion tree.

Sports → Competitions → Events → Markets, all in one column.
Single click expands/collapses; clicking a market selects it.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThreadPool, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit,
    QTreeWidget, QTreeWidgetItem, QFrame,
)

from pb77.api.client import PB77Client
from pb77.api.models import Sport, Competition, Event, Market
from pb77.api.sports import DEFAULT_SPORTS
from pb77.ui.workers import Worker

ROLE_TYPE   = Qt.ItemDataRole.UserRole
ROLE_ID     = Qt.ItemDataRole.UserRole + 1
ROLE_LOADED = Qt.ItemDataRole.UserRole + 2
ROLE_DATA   = Qt.ItemDataRole.UserRole + 3

T_SPORT       = "sport"
T_COMPETITION = "competition"
T_EVENT       = "event"
T_MARKET      = "market"
T_PLACEHOLDER = "placeholder"

# Colours
_C_SPORT  = QColor("#e6e8ec")
_C_COMP   = QColor("#9aa0ab")
_C_EVENT  = QColor("#c8ccd4")
_C_MARKET = QColor("#d4af37")
_C_DIM    = QColor("#646b78")

# Fonts
_F_SPORT  = QFont(); _F_SPORT.setBold(True);  _F_SPORT.setPointSize(13)
_F_COMP   = QFont(); _F_COMP.setBold(False);  _F_COMP.setPointSize(12)
_F_EVENT  = QFont(); _F_EVENT.setBold(False); _F_EVENT.setPointSize(12)
_F_MARKET = QFont(); _F_MARKET.setBold(True); _F_MARKET.setPointSize(12)
_F_DIM    = QFont(); _F_DIM.setItalic(True);  _F_DIM.setPointSize(11)


class Navigator(QWidget):
    market_selected = pyqtSignal(object)   # emits Market
    status = pyqtSignal(str)

    def __init__(
        self,
        client: PB77Client,
        pool: QThreadPool,
        sports: list[Sport] | None = None,
        parent=None,
    ):
        super().__init__(parent)
        self._client = client
        self._pool = pool
        self._sports_list = sports if sports is not None else DEFAULT_SPORTS
        self._build()
        self._populate_sports()

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header
        header = QFrame()
        header.setObjectName("Sidebar")
        hl = QVBoxLayout(header)
        hl.setContentsMargins(14, 14, 14, 10)
        hl.setSpacing(8)

        cap = QLabel("SPORTS & MARKETS")
        cap.setObjectName("SectionLabel")
        hl.addWidget(cap)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Search competitions, teams…")
        self._search.textChanged.connect(self._filter_tree)
        hl.addWidget(self._search)

        root.addWidget(header)

        # Tree
        self._tree = QTreeWidget()
        self._tree.setObjectName("NavTree")
        self._tree.setHeaderHidden(True)
        self._tree.setRootIsDecorated(True)
        self._tree.setIndentation(18)
        self._tree.setAnimated(True)
        self._tree.setVerticalScrollMode(QTreeWidget.ScrollMode.ScrollPerPixel)
        self._tree.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._tree.itemClicked.connect(self._on_clicked)
        self._tree.itemExpanded.connect(self._on_expand)
        root.addWidget(self._tree, stretch=1)

    # ── Populate ──────────────────────────────────────────────────────────────

    def _populate_sports(self):
        for sport in self._sports_list:
            node = QTreeWidgetItem([f" {sport.icon}  {sport.name}"])
            node.setFont(0, _F_SPORT)
            node.setForeground(0, _C_SPORT)
            node.setData(0, ROLE_TYPE, T_SPORT)
            node.setData(0, ROLE_ID, sport.id)
            node.setData(0, ROLE_LOADED, False)
            node.setData(0, ROLE_DATA, sport)
            node.addChild(self._placeholder())
            self._tree.addTopLevelItem(node)

    # ── Click — single click expands / collapses ──────────────────────────────

    def _on_clicked(self, item: QTreeWidgetItem, _col: int):
        ntype = item.data(0, ROLE_TYPE)
        if ntype == T_MARKET:
            market: Market = item.data(0, ROLE_DATA)
            if market:
                self.market_selected.emit(market)
                self.status.emit(f"{market.event_name}  —  {market.market_name}")
        elif ntype != T_PLACEHOLDER:
            item.setExpanded(not item.isExpanded())

    # ── Lazy expand ───────────────────────────────────────────────────────────

    def _on_expand(self, node: QTreeWidgetItem):
        if node.data(0, ROLE_LOADED):
            return
        ntype = node.data(0, ROLE_TYPE)
        node_id = node.data(0, ROLE_ID)
        node.setData(0, ROLE_LOADED, True)
        node.takeChildren()
        node.addChild(self._loading())

        if ntype == T_SPORT:
            w = Worker(self._client.list_competitions, node_id)
            w.signals.result.connect(lambda d, n=node: self._on_competitions(n, d))
        elif ntype == T_COMPETITION:
            w = Worker(self._client.list_events, node_id)
            w.signals.result.connect(lambda d, n=node: self._on_events(n, d))
        elif ntype == T_EVENT:
            w = Worker(self._client.list_markets, node_id)
            w.signals.result.connect(lambda d, n=node: self._on_markets(n, d))
        else:
            return
        w.signals.error.connect(self._on_error)
        self._pool.start(w)

    # ── Data handlers ─────────────────────────────────────────────────────────

    def _on_competitions(self, node: QTreeWidgetItem, comps: list[Competition]):
        node.takeChildren()
        if not comps:
            node.addChild(self._empty("No competitions"))
            return
        for c in comps:
            prefix = "★  " if c.highlighted else ""
            child = QTreeWidgetItem([f" {prefix}{c.name}"])
            child.setFont(0, _F_COMP)
            child.setForeground(0, _C_COMP)
            child.setData(0, ROLE_TYPE, T_COMPETITION)
            child.setData(0, ROLE_ID, c.id)
            child.setData(0, ROLE_LOADED, False)
            child.setData(0, ROLE_DATA, c)
            child.addChild(self._placeholder())
            node.addChild(child)
        self.status.emit(f"{len(comps)} competitions")

    def _on_events(self, node: QTreeWidgetItem, events: list[Event]):
        node.takeChildren()
        if not events:
            node.addChild(self._empty("No open events"))
            return
        for e in events:
            start = e.start_time.strftime("%d %b %H:%M") if e.start_time else ""
            label = f" {e.name}" + (f"  ·  {start}" if start else "")
            child = QTreeWidgetItem([label])
            child.setFont(0, _F_EVENT)
            child.setForeground(0, _C_EVENT)
            child.setData(0, ROLE_TYPE, T_EVENT)
            child.setData(0, ROLE_ID, e.id)
            child.setData(0, ROLE_LOADED, False)
            child.setData(0, ROLE_DATA, e)
            child.addChild(self._placeholder())
            node.addChild(child)

    def _on_markets(self, node: QTreeWidgetItem, markets: list[Market]):
        node.takeChildren()
        if not markets:
            node.addChild(self._empty("No markets"))
            return
        for m in markets:
            child = QTreeWidgetItem([f" {m.market_name}"])
            child.setFont(0, _F_MARKET)
            child.setForeground(0, _C_MARKET)
            child.setData(0, ROLE_TYPE, T_MARKET)
            child.setData(0, ROLE_ID, m.market_id)
            child.setData(0, ROLE_DATA, m)
            node.addChild(child)

    # ── Search ────────────────────────────────────────────────────────────────

    def _filter_tree(self, text: str):
        text = text.strip().lower()
        for i in range(self._tree.topLevelItemCount()):
            self._filter_node(self._tree.topLevelItem(i), text)

    def _filter_node(self, item: QTreeWidgetItem, text: str) -> bool:
        self_match = not text or text in item.text(0).lower()
        child_match = any(
            self._filter_node(item.child(i), text)
            for i in range(item.childCount())
        )
        visible = self_match or child_match
        item.setHidden(not visible)
        return visible

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _placeholder(self) -> QTreeWidgetItem:
        it = QTreeWidgetItem([""])
        it.setData(0, ROLE_TYPE, T_PLACEHOLDER)
        return it

    def _loading(self) -> QTreeWidgetItem:
        it = QTreeWidgetItem([" Loading…"])
        it.setFont(0, _F_DIM)
        it.setForeground(0, _C_DIM)
        it.setData(0, ROLE_TYPE, T_PLACEHOLDER)
        return it

    def _empty(self, msg: str) -> QTreeWidgetItem:
        it = QTreeWidgetItem([f" {msg}"])
        it.setFont(0, _F_DIM)
        it.setForeground(0, _C_DIM)
        it.setData(0, ROLE_TYPE, T_PLACEHOLDER)
        return it

    def _on_error(self, msg: str):
        self.status.emit(f"⚠  {msg}")
