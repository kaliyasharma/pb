"""
Animated odds-stream background for the login dialog.

Renders Matrix-style falling exchange odds in gold / blue / pink columns,
with a dot-grid underlay and soft vignette edges — all inside a QWidget
that sits behind the login card via widget.lower().
"""
from __future__ import annotations

import random

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QLinearGradient, QPainter, QPen,
)
from PyQt6.QtWidgets import QWidget

_ODDS = [
    "1.05", "1.10", "1.15", "1.20", "1.25", "1.30", "1.40", "1.50",
    "1.60", "1.72", "1.80", "1.90", "2.00", "2.10", "2.20", "2.30",
    "2.50", "2.75", "3.00", "3.25", "3.50", "4.00", "4.50", "5.00",
    "6.00", "7.00", "8.00", "9.00", "10.0", "12.0", "15.0", "20.0",
]

_GOLD = (212, 175, 55)
_BLUE = (114, 187, 239)
_PINK = (250, 169, 186)
_PALETTE = [_GOLD, _BLUE, _PINK, _GOLD, _BLUE, _PINK, _GOLD, _GOLD]

_COL_W   = 50    # pixels per column
_ITEM_H  = 22    # pixels between odds rows
_FPS     = 20


class _Stream:
    def __init__(self, col_idx: int, h: int):
        self.col = col_idx
        self.h   = h
        self.length = random.randint(7, 16)
        self.speed  = random.uniform(1.0, 2.6)
        self.head_y = random.uniform(-h, 0)
        self.chars  = [random.choice(_ODDS) for _ in range(self.length)]

    def step(self) -> None:
        self.head_y += self.speed
        if self.head_y - self.length * _ITEM_H > self.h:
            self.head_y = -random.uniform(20, self.h * 0.6)
            self.speed  = random.uniform(1.0, 2.6)
            self.length = random.randint(7, 16)
            self.chars  = [random.choice(_ODDS) for _ in range(self.length)]

    def mutate(self) -> None:
        if random.random() < 0.12:
            self.chars[random.randrange(len(self.chars))] = random.choice(_ODDS)


class AnimatedBg(QWidget):
    """Drop behind the login card with widget.lower()."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._streams: list[_Stream] = []
        self._tick = 0
        self._font = QFont("-apple-system, Helvetica Neue, Arial")
        self._font.setPixelSize(11)
        self._font.setWeight(QFont.Weight.Medium)
        self._font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 0.5)

        t = QTimer(self, interval=1000 // _FPS)
        t.timeout.connect(self._step)
        t.start()

    # ── internal ──────────────────────────────────────────────────────────────

    def _rebuild(self) -> None:
        w, h = self.width(), self.height()
        if w == 0 or h == 0:
            return
        n = max(1, w // _COL_W)
        self._streams = [_Stream(c, h) for c in range(n)]

    def _step(self) -> None:
        self._tick += 1
        if not self._streams:
            self._rebuild()
        for s in self._streams:
            s.step()
            if self._tick % 4 == 0:
                s.mutate()
        self.update()

    # ── Qt overrides ──────────────────────────────────────────────────────────

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._rebuild()

    def paintEvent(self, event):
        w, h = self.width(), self.height()
        if w == 0 or h == 0:
            return

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        # ── background fill ──────────────────────────────────────────────────
        p.fillRect(self.rect(), QColor(11, 13, 18))

        # ── dot grid ─────────────────────────────────────────────────────────
        p.setPen(QPen(QColor(38, 44, 60, 210), 1.4))
        gs = 30
        for gx in range(gs // 2, w + gs, gs):
            for gy in range(gs // 2, h + gs, gs):
                p.drawPoint(gx, gy)

        # ── falling odds streams ──────────────────────────────────────────────
        p.setFont(self._font)
        fm = p.fontMetrics()

        for i, stream in enumerate(self._streams):
            r, g, b = _PALETTE[i % len(_PALETTE)]
            col_x = i * _COL_W

            for j in range(stream.length):
                y = int(stream.head_y - j * _ITEM_H)
                if y < -_ITEM_H or y > h + _ITEM_H:
                    continue

                frac = j / max(1, stream.length - 1)
                if j == 0:
                    alpha = 210
                elif j == 1:
                    alpha = 155
                elif j == 2:
                    alpha = 110
                else:
                    alpha = max(12, int(80 * (1.0 - frac * 0.75)))

                p.setPen(QPen(QColor(r, g, b, alpha)))
                text_w = fm.horizontalAdvance(stream.chars[j])
                x = col_x + (_COL_W - text_w) // 2
                p.drawText(x, y, stream.chars[j])

        # ── vignette overlays (top / bottom / sides) ─────────────────────────
        def fill_grad(x1, y1, x2, y2, c0, c1):
            g = QLinearGradient(x1, y1, x2, y2)
            g.setColorAt(0, c0)
            g.setColorAt(1, c1)
            p.fillRect(self.rect(), QBrush(g))

        bg = QColor(11, 13, 18)
        clr = lambda a: QColor(bg.red(), bg.green(), bg.blue(), a)
        tr  = QColor(0, 0, 0, 0)

        fill_grad(0, 0,        0, h * 0.35,  clr(240), tr)      # top fade
        fill_grad(0, h * 0.65, 0, h,         tr, clr(240))      # bottom fade
        fill_grad(0, 0,        w * 0.18, 0,  clr(210), tr)      # left fade
        fill_grad(w * 0.82, 0, w, 0,         tr, clr(210))      # right fade

        p.end()
