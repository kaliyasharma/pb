
"""PB77 Terminal — application entry point."""
import logging
import os
import sys

if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt6.QtCore import Qt, QThreadPool
from PyQt6.QtWidgets import QApplication

from pb77.api.client import PB77Client
from pb77.ui.login_view import LoginDialog
from pb77.ui.main_window import MainWindow
from pb77.ui.theme import stylesheet


def main():
    log_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "pb77.log")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler(), logging.FileHandler(log_path, mode="w")],
    )
    logging.getLogger(__name__).info("Logging to %s", log_path)

    app = QApplication(sys.argv)
    app.setApplicationName("PB77 Terminal")
    app.setStyleSheet(stylesheet())
    try:
        app.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps)
    except Exception:
        pass

    client = PB77Client()
    pool = QThreadPool.globalInstance()

    # Show small login popup — blocks until accepted or dismissed
    dialog = LoginDialog(client, pool)
    if dialog.exec() != LoginDialog.DialogCode.Accepted or dialog.session is None:
        sys.exit(0)

    # Open full trading window
    window = MainWindow(client, dialog.session)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
