"""
Exchange odds ladder — the full set of valid Betfair-style price increments
from 1.01 to 1000, plus display helpers.

Tick structure (confirmed from laddercal.py, standard Betfair ladder):
    1.01 – 2.00   step 0.01
    2.00 – 3.00   step 0.02
    3.00 – 4.00   step 0.05
    4.00 – 6.00   step 0.1
    6.00 – 10.0   step 0.2
    10.0 – 20.0   step 0.5
    20   – 30     step 1
    30   – 50     step 2
    50   – 100    step 5
    100  – 1000   step 10
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right


def _generate_odds() -> list[float]:
    odds: list[float] = []

    x = 1.01
    while round(x, 2) <= 2.00:
        odds.append(round(x, 2)); x = round(x + 0.01, 10)
    x = 2.02
    while round(x, 2) <= 3.00:
        odds.append(round(x, 2)); x = round(x + 0.02, 10)
    x = 3.05
    while round(x, 2) <= 4.00:
        odds.append(round(x, 2)); x = round(x + 0.05, 10)
    x = 4.1
    while round(x, 1) <= 6.0:
        odds.append(round(x, 1)); x = round(x + 0.1, 10)
    x = 6.2
    while round(x, 1) <= 10.0:
        odds.append(round(x, 1)); x = round(x + 0.2, 10)
    x = 10.5
    while round(x, 1) <= 20.0:
        odds.append(round(x, 1)); x = round(x + 0.5, 10)
    x = 21
    while x <= 30:
        odds.append(float(int(x))); x += 1
    x = 32
    while x <= 50:
        odds.append(float(int(x))); x += 2
    x = 55
    while x <= 100:
        odds.append(float(int(x))); x += 5
    x = 110
    while x <= 1000:
        odds.append(float(int(x))); x += 10
    return odds


# Ascending 1.01 → 1000 (used for range math + bisect lookups)
LADDER_ODDS_ASC: list[float] = _generate_odds()
# Descending 1000 → 1.01 (display order: short prices at the bottom like a real ladder)
LADDER_ODDS: list[float] = LADDER_ODDS_ASC[::-1]


def fmt_amount(amount: float) -> str:
    """Compact money formatting for ladder cells: 1.2k, 340, 12.5."""
    if not amount:
        return ""
    if amount >= 1000:
        return f"{amount / 1000:.1f}k"
    if amount >= 100:
        return f"{amount:.0f}"
    return f"{amount:.1f}"


def fmt_amount_full(amount: float) -> str:
    """Full money amount with thousands separators (no 'k'): 29,047,600."""
    if not amount:
        return ""
    return f"{amount:,.0f}"


def fmt_odds(odds: float) -> str:
    """Render an odd the way the ladder labels it (no trailing .0 on integers)."""
    return f"{odds:g}"


def odds_in_range(lo: float, hi: float) -> list[float]:
    """All ladder odds with lo <= odd <= hi (inclusive), ascending."""
    lo, hi = min(lo, hi), max(lo, hi)
    left = bisect_left(LADDER_ODDS_ASC, lo)
    right = bisect_right(LADDER_ODDS_ASC, hi)
    return LADDER_ODDS_ASC[left:right]


def line_ladder(min_v: float, max_v: float, interval: float) -> list[float]:
    """Descending ladder of line values for a LINE/LINE_RANGE market.

    e.g. minUnitValue=0.5, maxUnitValue=999.5, interval=1.0 ->
        [999.5, 998.5, ..., 1.5, 0.5]  (largest at top, like the odds ladder).
    """
    if interval <= 0:
        interval = 1.0
    lo, hi = min(min_v, max_v), max(min_v, max_v)
    n = int(round((hi - lo) / interval))
    vals = [round(lo + i * interval, 2) for i in range(n + 1)]
    return vals[::-1]


def snap_odd(x: float) -> float:
    """Snap any value to the nearest valid Betfair tick (e.g. 101 -> 100)."""
    return min(LADDER_ODDS_ASC, key=lambda t: abs(t - x))


def opposite_odds(odd: float) -> float | None:
    """Fair back odd for the other runner in a 2-outcome market: o/(o-1), snapped.

    Derived from the 2-runner equivalence (Back B @ o == Lay A @ o/(o-1)).
    Only meaningful when the market has exactly two runners.
    """
    if odd is None or odd <= 1:
        return None
    return snap_odd(odd / (odd - 1))
