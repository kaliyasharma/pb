"""
Sports catalogue and ordered list for pb77's navigation sidebar.

minNavSportIds confirmed from GET /customer/api/page/properties:
["4","1","7522","3","7","5","2"]  (Cricket, Soccer, Basketball, Golf, Horse Racing, Rugby Union, Tennis)
"""
from pb77.api.models import Sport

# Full ID→(name, icon) lookup. Add more here as they appear.
_CATALOGUE: dict[str, tuple[str, str]] = {
    "1":    ("Soccer",        "⚽"),
    "2":    ("Tennis",        "🎾"),
    "3":    ("Golf",          "⛳"),
    "4":    ("Cricket",       "🏏"),
    "5":    ("Rugby Union",   "🏉"),
    "6":    ("Boxing",        "🥊"),
    "7":    ("Horse Racing",  "🐎"),
    "8":    ("Motor Sport",   "🏎️"),
    "1477": ("Rugby League",  "🏉"),
    "7511": ("Baseball",      "⚾"),
    "7522": ("Basketball",    "🏀"),
    "6422": ("Snooker",       "🎱"),
    "6423": ("American Football", "🏈"),
}

# Ordered sport IDs from /customer/api/page/properties minNavSportIds
DEFAULT_SPORT_IDS = ["4", "1", "7522", "3", "7", "5", "2"]


def sports_from_ids(ids: list[str]) -> list[Sport]:
    """Build an ordered Sport list from a list of sport ID strings."""
    return [Sport(id_, *_CATALOGUE[id_]) for id_ in ids if id_ in _CATALOGUE]


DEFAULT_SPORTS = sports_from_ids(DEFAULT_SPORT_IDS)
