"""
PB77 API client — synchronous (driven from Qt background workers).

A single httpx.Client carries the cookie jar so the BIAB_CUSTOMER cookie
(set during the exchange handshake, domain=.pb77.co) is sent to both
www.pb77.co and ex.pb77.co automatically.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta
from urllib.parse import quote

import httpx

import random
import string
import time
import uuid

from pb77.api.models import (
    Session, Competition, Event, Market, PlatformConfig,
    BetInstruction, BetResult,
)
from pb77.api.sports import DEFAULT_SPORT_IDS

logger = logging.getLogger(__name__)

WWW_BASE = "https://www.pb77.co"
EX_BASE = "https://ex.pb77.co"

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/146.0.0.0 Safari/537.36"
)

# Headers for the www.pb77.co (account / auth) domain
WWW_HEADERS = {
    "Language": "en-US",
    "Clienttype": "2",
    "User-Agent": USER_AGENT,
    "Origin": "https://www.pb77.co",
    "Referer": "https://www.pb77.co/",
    "Accept": "*/*",
}

# Headers for the ex.pb77.co (exchange) domain
EX_HEADERS = {
    "X-Device": "DESKTOP",
    "User-Agent": USER_AGENT,
    "Origin": "https://ex.pb77.co",
    "Referer": "https://ex.pb77.co/",
    "Accept": "application/json, text/plain, */*",
}


class PB77Error(Exception):
    pass


class PB77Client:
    def __init__(self):
        self._http = httpx.Client(follow_redirects=True, timeout=20.0)
        self.session: Session | None = None
        self.platform_config: PlatformConfig | None = None
        self._pending_login: dict | None = None

    # ── Auth: 3-step OTP login ────────────────────────────────────────────────

    def request_otp(self, email: str) -> None:
        """Step 1 — trigger the OTP email."""
        resp = self._http.post(
            f"{WWW_BASE}/api/v2/otp/email",
            params={"used": "true", "email": email},
            headers=WWW_HEADERS,
        )
        body = self._unwrap(resp)
        logger.info("OTP requested for %s", email)
        return body

    def verify_otp(self, email: str, otp: str) -> dict:
        """Step 2 — verify the OTP, capture token + nickname."""
        resp = self._http.post(
            f"{WWW_BASE}/api/v2/login/email",
            content=f"email={quote(email)}&otp={otp}",
            headers={
                **WWW_HEADERS,
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
            },
        )
        body = self._unwrap(resp)
        self._pending_login = body["data"]
        logger.info("OTP verified, token acquired")
        return self._pending_login

    def exchange_handshake(self) -> Session:
        """Step 3 — exchange token for the BIAB session, build Session."""
        if not self._pending_login:
            raise PB77Error("Call verify_otp() before exchange_handshake().")

        d = self._pending_login
        token = d["token"]
        nickname = d["nickname"]

        resp = self._http.post(
            f"{WWW_BASE}/api/exchange2",
            params={"token": token, "name": nickname},
            headers={**WWW_HEADERS, "Token": token},
        )
        body = self._unwrap(resp)
        ex = body["data"]

        timeout = (d.get("logoutSetting") or {}).get("tokenTimeout", 36000)
        self.session = Session(
            token=token,
            member_id=int(d.get("memberId", 0)),
            email=d.get("email", ""),
            nickname=nickname,
            currency_code=d.get("currencyCode", ""),
            currency_symbol=d.get("currencySymbol", ""),
            balance=float(d.get("currencyBalance", 0.0)),
            biab_jwt=ex.get("BIAB_CUSTOMER", ""),
            exchange_url=ex.get("biabUrl", EX_BASE),
            expires_at=datetime.utcnow() + timedelta(seconds=timeout),
        )
        # Token header is needed on subsequent www calls
        self._http.headers["Token"] = token
        self._pending_login = None
        self._ensure_biab_cookies()
        logger.info("Exchange handshake complete for %s", nickname)
        try:
            self.platform_config = self.get_page_properties()
        except Exception as e:
            logger.warning("Could not fetch platform config: %s", e)
            self.platform_config = PlatformConfig(nav_sport_ids=DEFAULT_SPORT_IDS)
        return self.session

    def login(self, email: str, otp: str) -> Session:
        """Convenience: run steps 2 + 3 (OTP already sent)."""
        self.verify_otp(email, otp)
        return self.exchange_handshake()

    def logout(self) -> None:
        self.session = None
        self.platform_config = None
        self._pending_login = None
        self._http.cookies.clear()
        self._http.headers.pop("Token", None)

    def is_logged_in(self) -> bool:
        return self.session is not None and self.session.seconds_remaining > 300

    # ── Exchange: navigation ──────────────────────────────────────────────────

    def list_competitions(self, sport_id: str) -> list[Competition]:
        resp = self._http.get(
            f"{EX_BASE}/customer/api/competition/sport/{sport_id}",
            headers=EX_HEADERS,
        )
        data = resp.json()
        comps: list[Competition] = []
        for c in data.get("topCompetitions", []):
            if c.get("type") == "COMPETITION":
                comps.append(Competition.from_json(c, highlighted=True))
        for c in data.get("moreCompetitions", []):
            if c.get("type") == "COMPETITION":
                comps.append(Competition.from_json(c, highlighted=False))
        return comps

    def list_events(self, competition_id: str) -> list[Event]:
        resp = self._http.get(
            f"{EX_BASE}/customer/api/competition/{competition_id}",
            headers=EX_HEADERS,
        )
        children = resp.json().get("children", [])
        return [Event.from_json(c) for c in children if c.get("type") == "EVENT"]

    def list_markets(self, event_id: str) -> list[Market]:
        resp = self._http.get(
            f"{EX_BASE}/customer/api/event/details/{event_id}",
            headers=EX_HEADERS,
        )
        cats = resp.json().get("marketCatalogues", [])
        return [Market.from_json(m) for m in cats]

    def get_market(self, market_id: str) -> Market:
        resp = self._http.get(
            f"{EX_BASE}/customer/api/market/{market_id}",
            headers=EX_HEADERS,
        )
        return Market.from_json(resp.json())

    def get_page_properties(self) -> PlatformConfig:
        """Fetch runtime platform settings from /customer/api/page/properties."""
        resp = self._http.get(
            f"{EX_BASE}/customer/api/page/properties",
            headers=EX_HEADERS,
        )
        data = resp.json()
        return PlatformConfig(
            nav_sport_ids=data.get("minNavSportIds", DEFAULT_SPORT_IDS),
            reconnect_attempts=int(data.get("reconnectAttempts", 100)),
            reconnect_timeout_ms=int(data.get("reconnectTimeout", 15000)),
        )

    # ── Exchange: order placement ─────────────────────────────────────────────

    def place_bets(self, market_id: str, bets: list[BetInstruction]) -> BetResult:
        """
        POST /customer/api/placeBets — place one or more bets on a single market.

        Payload shape confirmed from a live pb77 capture:
            { "<marketId>": [ {selectionId, handicap, price, size, side, betUuid,
                               betType, persistenceType, applicationType, …flags}, … ] }
        """
        if not bets:
            return BetResult(success=False, status="EMPTY", message="No bets to place")
        self._ensure_biab_cookies()
        if not self.csrf_token():
            return BetResult(
                success=False, status="NO_CSRF",
                message="Could not establish a CSRF token — are you logged in?",
            )

        base_ts = int(time.time() * 1000)
        entries = [self._bet_entry(market_id, b, base_ts + i) for i, b in enumerate(bets)]
        payload = {market_id: entries}

        url = f"{EX_BASE}/customer/api/placeBets"
        headers = self._ex_write_headers()
        logger.info("PLACEBETS → POST %s", url)
        logger.info("PLACEBETS headers: %s", self._loggable_headers(headers))
        logger.info("PLACEBETS body: %s", json.dumps(payload))
        resp = self._http.post(url, json=payload, headers=headers)
        logger.info("PLACEBETS ← HTTP %s  body: %s", resp.status_code, resp.text[:1000])
        return self._parse_bet_result(resp)

    def cancel_all_bets(self, market_id: str | None = None) -> BetResult:
        """POST /customer/api/cancelBets/all — cancel all unmatched exchange bets."""
        self._ensure_biab_cookies()
        body: dict = {"betTypes": ["EXCHANGE"]}
        if market_id:
            body["marketId"] = market_id
        url = f"{EX_BASE}/customer/api/cancelBets/all"
        headers = self._ex_write_headers()
        logger.info("CANCELALL → POST %s  body: %s", url, json.dumps(body))
        logger.info("CANCELALL headers: %s", self._loggable_headers(headers))
        resp = self._http.post(url, json=body, headers=headers)
        logger.info("CANCELALL ← HTTP %s  body: %s", resp.status_code, resp.text[:600])
        return self._parse_bet_result(resp)

    def cancel_bet(self, bet: dict) -> BetResult:
        """POST /customer/api/cancelBets — cancel one specific unmatched bet."""
        self._ensure_biab_cookies()
        market_id = str(bet["marketId"])
        payload = {market_id: [bet]}
        url = f"{EX_BASE}/customer/api/cancelBets"
        headers = self._ex_write_headers()
        logger.info("CANCELBET → POST %s  offerId: %s", url, bet.get("offerId"))
        resp = self._http.post(url, json=payload, headers=headers)
        logger.info("CANCELBET ← HTTP %s  body: %s", resp.status_code, resp.text[:400])
        return self._parse_bet_result(resp)

    @staticmethod
    def _bet_entry(market_id: str, b: BetInstruction, ts: int) -> dict:
        """One bet object, matching the confirmed live placeBets payload exactly."""
        hcap = int(b.handicap) if float(b.handicap).is_integer() else b.handicap
        rand = "".join(random.choices(string.ascii_lowercase + string.digits, k=5))
        return {
            "selectionId": b.selection_id,
            "handicap": hcap,                 # int when whole (0), matches capture
            "price": b.price,                 # numeric, not string
            "size": b.size,
            "side": b.side,
            # betUuid: {marketId}_{selectionId}_{handicap}__{epoch_ms}-{rand}_INLINE
            "betUuid": f"{market_id}_{b.selection_id}_{hcap}__{ts}-{rand}_INLINE",
            "betType": "EXCHANGE",
            "netPLBetslipEnabled": False,
            "netPLMarketPageEnabled": False,
            "quickStakesEnabled": True,
            "confirmBetsEnabled": False,
            "applicationType": "WEB",
            "showLayOddsEnabled": False,
            "mobile": False,                  # desktop client (X-Device: DESKTOP)
            "isEachWay": False,
            "eachWayData": {},
            "openBetsEnabled": False,
            "page": "market",
            "persistenceType": "LAPSE",
            "placedUsingEnterKey": False,
        }

    def _ex_write_headers(self) -> dict:
        """Exchange headers for state-changing POSTs — adds the CSRF token."""
        headers = dict(EX_HEADERS)
        headers["Content-Type"] = "application/json"
        token = self.csrf_token()
        if token:
            headers["X-Csrf-Token"] = token
        return headers

    @staticmethod
    def _loggable_headers(headers: dict) -> str:
        """Compact header dump for the debug log (cookies are added by httpx, not here)."""
        return json.dumps({k: v for k, v in headers.items()})

    def csrf_token(self) -> str:
        """The CSRF-TOKEN cookie value, echoed back in the X-Csrf-Token header."""
        for c in self._http.cookies.jar:
            if c.name == "CSRF-TOKEN":
                return c.value or ""
        return ""

    def _cookie_value(self, name: str) -> str:
        for c in self._http.cookies.jar:
            if c.name == name:
                return c.value or ""
        return ""

    def _ensure_biab_cookies(self) -> None:
        """
        Mint the frontend-generated BIAB cookies the browser creates client-side.

        CSRF-TOKEN uses the double-submit pattern: the SPA generates a UUID, stores it
        as a cookie AND sends it back in the X-Csrf-Token header — the server only checks
        the two match. BIAB_AN is an anonymous id, BIAB_LANGUAGE / BIAB_TZ are prefs.
        We only set a cookie if the server hasn't already issued one (prefer server value).
        """
        have = {c.name for c in self._http.cookies.jar}
        defaults = {
            "CSRF-TOKEN": str(uuid.uuid4()),
            "BIAB_AN": str(uuid.uuid4()),
            "BIAB_LANGUAGE": "en",
            "BIAB_TZ": self._tz_offset(),
        }
        for name, value in defaults.items():
            if name not in have:
                self._http.cookies.set(name, value, domain="ex.pb77.co", path="/")

    @staticmethod
    def _tz_offset() -> str:
        """JS getTimezoneOffset() equivalent in minutes (IST → '-330')."""
        is_dst = time.daylight and time.localtime().tm_isdst > 0
        secs = time.altzone if is_dst else time.timezone
        return str(secs // 60)

    @staticmethod
    def _parse_bet_result(resp: httpx.Response) -> BetResult:
        try:
            body = resp.json()
        except Exception:
            body = {}
        if resp.status_code >= 400:
            msg = (body.get("message") or body.get("exceptionMessage")
                   or f"HTTP {resp.status_code}: {resp.text[:160]}")
            return BetResult(success=False, status=str(resp.status_code), message=msg, raw=body)
        # BIAB success envelopes vary; treat 2xx without an error flag as success
        status = body.get("status") or body.get("result") or "SUCCESS"
        failed = str(status).upper() in {"FAILURE", "ERROR"} or body.get("error")
        msg = body.get("message") or body.get("errorMessage") or ""
        return BetResult(success=not failed, status=str(status), message=msg, raw=body)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def cookie_header(self) -> str:
        """Cookie string for the exchange domain — needed by the WebSocket."""
        return "; ".join(f"{c.name}={c.value}" for c in self._http.cookies.jar)

    @staticmethod
    def _unwrap(resp: httpx.Response) -> dict:
        """Validate the standard pb77 response envelope."""
        try:
            body = resp.json()
        except Exception as e:
            raise PB77Error(f"Non-JSON response ({resp.status_code}): {resp.text[:200]}") from e
        if body.get("status") != 200:
            msg = body.get("message") or body.get("exceptionMessage") or "Unknown error"
            raise PB77Error(f"API error {body.get('status')}: {msg}")
        return body

    def close(self) -> None:
        self._http.close()
