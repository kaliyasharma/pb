"""Data models mapped from pb77 API responses."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Session:
    """Authenticated session, built across the 3-step login flow."""
    token: str
    member_id: int
    email: str
    nickname: str
    currency_code: str          # "INR"
    currency_symbol: str        # "₹"
    balance: float
    biab_jwt: str               # BIAB_CUSTOMER cookie value
    exchange_url: str           # "https://ex.pb77.co"
    expires_at: datetime

    @property
    def seconds_remaining(self) -> float:
        return (self.expires_at - datetime.utcnow()).total_seconds()


@dataclass
class Sport:
    id: str
    name: str
    icon: str = ""              # optional emoji/icon hint


@dataclass
class Competition:
    id: str
    name: str
    event_type_id: str
    highlighted: bool = False   # True if from topCompetitions

    @classmethod
    def from_json(cls, d: dict, highlighted: bool = False) -> "Competition":
        return cls(
            id=str(d.get("id", "")),
            name=d.get("name", ""),
            event_type_id=str(d.get("eventTypeId") or ""),
            highlighted=highlighted,
        )


@dataclass
class Event:
    id: str
    name: str
    start_time: Optional[datetime]
    event_type_id: str
    country_code: str = ""

    @classmethod
    def from_json(cls, d: dict) -> "Event":
        ms = d.get("startTime")
        start = datetime.fromtimestamp(ms / 1000) if ms else None
        return cls(
            id=str(d.get("id", "")),
            name=d.get("name", ""),
            start_time=start,
            event_type_id=str(d.get("eventTypeId") or ""),
            country_code=d.get("countryCode") or "",
        )

    @property
    def home_away(self) -> tuple[str, str]:
        if " v " in self.name:
            home, away = self.name.split(" v ", 1)
            return home.strip(), away.strip()
        return self.name, ""


@dataclass
class Runner:
    selection_id: int
    runner_name: str
    handicap: float = 0.0
    sort_priority: int = 0

    @classmethod
    def from_json(cls, d: dict) -> "Runner":
        return cls(
            selection_id=int(d.get("selectionId", 0)),
            runner_name=d.get("runnerName", ""),
            handicap=float(d.get("handicap", 0.0)),
            sort_priority=int(d.get("sortPriority", 0)),
        )


@dataclass
class PlatformConfig:
    """Runtime settings fetched from /customer/api/page/properties after login."""
    nav_sport_ids: list[str]
    reconnect_attempts: int = 100
    reconnect_timeout_ms: int = 15000


@dataclass
class BetInstruction:
    """One bet to place on the exchange."""
    selection_id: int
    side: str                   # "BACK" | "LAY"
    price: float
    size: float
    handicap: float = 0.0


@dataclass
class BetResult:
    """Outcome of a placeBets call (best-effort parse of the response)."""
    success: bool
    status: str = ""            # "SUCCESS" | "FAILURE" | http status text
    message: str = ""
    raw: dict = field(default_factory=dict)


@dataclass
class Market:
    market_id: str              # "1.259307107"
    market_name: str            # "Match Odds"
    market_type: str            # "MATCH_ODDS"
    market_start_time: Optional[datetime]
    total_matched: float
    commission: float
    in_play: bool
    runners: list[Runner] = field(default_factory=list)
    event_id: str = ""
    event_name: str = ""
    competition_name: str = ""
    betting_type: str = ""      # "ODDS" | "LINE" | "ASIAN_HANDICAP_SINGLE_LINE"
    # LINE/LINE_RANGE markets ladder on a line value, not odds.
    # {"minUnitValue": 0.5, "maxUnitValue": 999.5, "interval": 1.0, "marketUnit": "Runs"}
    line_range: Optional[dict] = None

    @property
    def is_line(self) -> bool:
        """True when this market's ladder is a line range (runs/points), not odds."""
        return self.betting_type == "LINE" and bool(self.line_range)

    @classmethod
    def from_json(cls, d: dict) -> "Market":
        ms = d.get("marketStartTime")
        start = datetime.fromtimestamp(ms / 1000) if ms else None
        desc = d.get("description") or {}
        event = d.get("event") or {}
        return cls(
            market_id=str(d.get("marketId", "")),
            market_name=d.get("marketName", ""),
            market_type=desc.get("marketType") or d.get("marketType") or "",
            market_start_time=start,
            total_matched=float(d.get("totalMatched", 0.0)),
            commission=float(d.get("commission", 0.0)),
            in_play=bool(d.get("inPlay", False)),
            runners=[Runner.from_json(r) for r in (d.get("runners") or [])],
            event_id=str(event.get("id", "")),
            event_name=event.get("name", ""),
            competition_name=(d.get("competition") or {}).get("name", ""),
            betting_type=desc.get("bettingType") or "",
            line_range=desc.get("lineRangeInfo") or None,
        )
