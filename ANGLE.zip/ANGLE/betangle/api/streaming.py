import threading
import logging
from typing import Callable, Optional
import betfairlightweight
from betfairlightweight import StreamListener

from betangle.api.models import Market, Runner, PriceSize

logger = logging.getLogger(__name__)


class MarketStreamListener(StreamListener):
    def __init__(self, on_update: Callable[[str, dict], None]):
        super().__init__()
        self._on_update = on_update

    def on_data(self, raw_data: str) -> Optional[bool]:
        try:
            return super().on_data(raw_data)
        except Exception as e:
            logger.error(f"Stream data error: {e}")
            return False


class StreamingClient:
    def __init__(self, betfair_client, on_market_update: Callable[[str, dict], None]):
        self._betfair_client = betfair_client
        self._on_market_update = on_market_update
        self._stream = None
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._subscribed_markets: set[str] = set()

    def subscribe(self, market_ids: list[str]):
        new_ids = [mid for mid in market_ids if mid not in self._subscribed_markets]
        if not new_ids:
            return
        self._subscribed_markets.update(new_ids)
        if self._running:
            self._update_subscription()
        else:
            self._start(list(self._subscribed_markets))

    def unsubscribe(self, market_ids: list[str]):
        for mid in market_ids:
            self._subscribed_markets.discard(mid)
        if self._running and self._subscribed_markets:
            self._update_subscription()
        elif not self._subscribed_markets:
            self.stop()

    def stop(self):
        self._running = False
        if self._stream:
            try:
                self._stream.stop()
            except Exception:
                pass
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)
        self._stream = None
        self._thread = None

    def _start(self, market_ids: list[str]):
        listener = MarketStreamListener(on_update=self._on_market_update)
        self._stream = self._betfair_client._client.streaming.create_stream(listener=listener)

        market_filter = betfairlightweight.filters.streaming_market_filter(
            market_ids=market_ids,
        )
        market_data_filter = betfairlightweight.filters.streaming_market_data_filter(
            fields=["EX_BEST_OFFERS", "EX_TRADED", "EX_MARKET_DEF"],
            ladder_levels=3,
        )
        self._stream.subscribe_to_markets(
            market_filter=market_filter,
            market_data_filter=market_data_filter,
        )
        self._running = True
        self._thread = threading.Thread(target=self._run_stream, daemon=True)
        self._thread.start()

    def _update_subscription(self):
        self.stop()
        if self._subscribed_markets:
            self._start(list(self._subscribed_markets))

    def _run_stream(self):
        try:
            self._stream.start()
        except Exception as e:
            if self._running:
                logger.error(f"Stream error: {e}")
            self._running = False


def parse_runner_prices(runner_book) -> tuple[list[PriceSize], list[PriceSize]]:
    available_to_back = [
        PriceSize(price=ps.price, size=ps.size)
        for ps in (runner_book.ex.available_to_back or [])
    ]
    available_to_lay = [
        PriceSize(price=ps.price, size=ps.size)
        for ps in (runner_book.ex.available_to_lay or [])
    ]
    return available_to_back, available_to_lay
