from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class Side(str, Enum):
    BACK = "BACK"
    LAY = "LAY"


class OrderStatus(str, Enum):
    PENDING = "PENDING"
    EXECUTABLE = "EXECUTABLE"
    EXECUTION_COMPLETE = "EXECUTION_COMPLETE"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"


@dataclass
class PriceSize:
    price: float
    size: float


@dataclass
class Runner:
    selection_id: int
    runner_name: str
    handicap: float = 0.0
    status: str = "ACTIVE"
    last_price_traded: Optional[float] = None
    total_matched: float = 0.0
    available_to_back: list[PriceSize] = field(default_factory=list)
    available_to_lay: list[PriceSize] = field(default_factory=list)
    traded_volume: list[PriceSize] = field(default_factory=list)

    @property
    def best_back(self) -> Optional[float]:
        return self.available_to_back[0].price if self.available_to_back else None

    @property
    def best_lay(self) -> Optional[float]:
        return self.available_to_lay[0].price if self.available_to_lay else None


@dataclass
class Market:
    market_id: str
    market_name: str
    event_name: str
    market_start_time: datetime
    total_matched: float = 0.0
    status: str = "OPEN"
    runners: list[Runner] = field(default_factory=list)
    in_play: bool = False

    def get_runner(self, selection_id: int) -> Optional[Runner]:
        return next((r for r in self.runners if r.selection_id == selection_id), None)


@dataclass
class Order:
    bet_id: str
    market_id: str
    selection_id: int
    side: Side
    price: float
    size: float
    status: OrderStatus
    placed_date: datetime = field(default_factory=datetime.now)
    size_matched: float = 0.0
    size_remaining: float = 0.0
    size_lapsed: float = 0.0
    average_price_matched: Optional[float] = None

    @property
    def profit_loss(self) -> float:
        if not self.average_price_matched or self.size_matched == 0:
            return 0.0
        if self.side == Side.BACK:
            return self.size_matched * (self.average_price_matched - 1)
        else:
            return -self.size_matched * (self.average_price_matched - 1)
