import betfairlightweight
from betfairlightweight import APIClient
from betfairlightweight.filters import market_filter, time_range
from datetime import datetime, timedelta
from typing import Optional
import logging

from betangle.api.models import Market, Runner, PriceSize, Order, Side, OrderStatus

logger = logging.getLogger(__name__)

PRICE_PROJECTION = betfairlightweight.filters.price_projection(
    price_data=["EX_BEST_OFFERS", "EX_TRADED"],
)


class BetfairClient:
    def __init__(self, username: str, password: str, app_key: str, certs_path: Optional[str] = None):
        self._client = APIClient(
            username=username,
            password=password,
            app_key=app_key,
            certs=certs_path,
        )
        self._logged_in = False

    def login(self) -> bool:
        try:
            self._client.login()
            self._logged_in = True
            logger.info("Logged in to Betfair successfully")
            return True
        except Exception as e:
            logger.error(f"Login failed: {e}")
            return False

    def logout(self):
        if self._logged_in:
            try:
                self._client.logout()
            except Exception:
                pass
            self._logged_in = False

    def is_logged_in(self) -> bool:
        return self._logged_in

    def list_event_types(self) -> list[dict]:
        try:
            event_types = self._client.betting.list_event_types(filter=market_filter())
            return [{"id": et.event_type.id, "name": et.event_type.name} for et in event_types]
        except Exception as e:
            logger.error(f"Failed to list event types: {e}")
            return []

    def list_markets(
        self,
        event_type_ids: Optional[list[str]] = None,
        hours_ahead: int = 24,
    ) -> list[Market]:
        try:
            tf = time_range(
                from_=datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
                to=(datetime.utcnow() + timedelta(hours=hours_ahead)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            )
            mf = market_filter(
                event_type_ids=event_type_ids or [],
                market_countries=["GB", "IE"],
                market_type_codes=["WIN", "PLACE"],
                market_start_time=tf,
            )
            catalogues = self._client.betting.list_market_catalogue(
                filter=mf,
                market_projection=["MARKET_START_TIME", "RUNNER_DESCRIPTION", "EVENT"],
                max_results=200,
            )
            markets = []
            for cat in catalogues:
                runners = [
                    Runner(
                        selection_id=r.selection_id,
                        runner_name=r.runner_name,
                        handicap=r.handicap,
                    )
                    for r in (cat.runners or [])
                ]
                markets.append(
                    Market(
                        market_id=cat.market_id,
                        market_name=cat.market_name,
                        event_name=cat.event.name if cat.event else "",
                        market_start_time=cat.market_start_time or datetime.utcnow(),
                        runners=runners,
                    )
                )
            return markets
        except Exception as e:
            logger.error(f"Failed to list markets: {e}")
            return []

    def get_market_book(self, market_id: str) -> Optional[dict]:
        try:
            books = self._client.betting.list_market_book(
                market_ids=[market_id],
                price_projection=PRICE_PROJECTION,
            )
            return books[0] if books else None
        except Exception as e:
            logger.error(f"Failed to get market book for {market_id}: {e}")
            return None

    def place_order(
        self,
        market_id: str,
        selection_id: int,
        side: Side,
        price: float,
        size: float,
    ) -> Optional[str]:
        try:
            instruction = betfairlightweight.filters.limit_order(
                size=size,
                price=price,
                persistence_type="LAPSE",
            )
            place_instruction = betfairlightweight.filters.place_instruction(
                order_type="LIMIT",
                selection_id=selection_id,
                side=side.value,
                limit_order=instruction,
            )
            result = self._client.betting.place_orders(
                market_id=market_id,
                instructions=[place_instruction],
            )
            if result.status == "SUCCESS":
                return result.instruction_reports[0].bet_id
            logger.warning(f"Place order failed: {result.error_code}")
            return None
        except Exception as e:
            logger.error(f"Failed to place order: {e}")
            return None

    def cancel_order(self, market_id: str, bet_id: str) -> bool:
        try:
            instruction = betfairlightweight.filters.cancel_instruction(bet_id=bet_id)
            result = self._client.betting.cancel_orders(
                market_id=market_id,
                instructions=[instruction],
            )
            return result.status == "SUCCESS"
        except Exception as e:
            logger.error(f"Failed to cancel order {bet_id}: {e}")
            return False

    def list_current_orders(self) -> list[Order]:
        try:
            result = self._client.betting.list_current_orders()
            orders = []
            for o in result.current_orders:
                orders.append(Order(
                    bet_id=o.bet_id,
                    market_id=o.market_id,
                    selection_id=o.selection_id,
                    side=Side(o.side),
                    price=o.price_size.price,
                    size=o.price_size.size,
                    status=OrderStatus(o.status),
                    placed_date=o.placed_date,
                    size_matched=o.size_matched,
                    size_remaining=o.size_remaining,
                    size_lapsed=o.size_lapsed,
                    average_price_matched=o.average_price_matched,
                ))
            return orders
        except Exception as e:
            logger.error(f"Failed to list orders: {e}")
            return []
