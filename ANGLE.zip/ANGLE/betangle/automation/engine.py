import logging
from typing import Optional
from betangle.automation.rules import AutomationRule, Action, RuleAction
from betangle.api.models import Side

logger = logging.getLogger(__name__)


class AutomationEngine:
    def __init__(self, order_manager):
        self._order_manager = order_manager
        self._rules: dict[str, AutomationRule] = {}

    def add_rule(self, rule: AutomationRule):
        self._rules[rule.rule_id] = rule
        logger.info(f"Added automation rule: {rule.name}")

    def remove_rule(self, rule_id: str):
        self._rules.pop(rule_id, None)

    def enable_rule(self, rule_id: str, enabled: bool = True):
        if rule_id in self._rules:
            self._rules[rule_id].enabled = enabled

    def get_rules(self) -> list[AutomationRule]:
        return list(self._rules.values())

    def evaluate(self, market_id: str, market_state: dict):
        for rule in self._rules.values():
            if rule.market_id != market_id:
                continue
            try:
                if rule.evaluate(market_state):
                    self._execute(rule, market_state)
                    rule.fired = True
            except Exception as e:
                logger.error(f"Error evaluating rule {rule.rule_id}: {e}")

    def _execute(self, rule: AutomationRule, market_state: dict):
        logger.info(f"Firing rule: {rule.name}")
        for action in rule.actions:
            self._run_action(rule, action, market_state)

    def _run_action(self, rule: AutomationRule, action: RuleAction, market_state: dict):
        match action.action:
            case Action.PLACE_BACK:
                price = action.price or self._best_back(rule.selection_id, market_state)
                if price and action.size:
                    self._order_manager.place(
                        rule.market_id, rule.selection_id, Side.BACK, price, action.size
                    )
            case Action.PLACE_LAY:
                price = action.price or self._best_lay(rule.selection_id, market_state)
                if price and action.size:
                    self._order_manager.place(
                        rule.market_id, rule.selection_id, Side.LAY, price, action.size
                    )
            case Action.CANCEL_ALL:
                self._order_manager.cancel_all(rule.market_id)
            case Action.HEDGE:
                self._hedge(rule, market_state)

    def _hedge(self, rule: AutomationRule, market_state: dict):
        position = self._order_manager.get_position(rule.market_id, rule.selection_id)
        net = position["matched_back"] - position["matched_lay"]
        if net == 0:
            return
        best_lay = self._best_lay(rule.selection_id, market_state)
        best_back = self._best_back(rule.selection_id, market_state)
        if net > 0 and best_lay:
            self._order_manager.place(rule.market_id, rule.selection_id, Side.LAY, best_lay, net)
        elif net < 0 and best_back:
            self._order_manager.place(rule.market_id, rule.selection_id, Side.BACK, best_back, -net)

    def _best_back(self, selection_id: int, market_state: dict) -> Optional[float]:
        runner = next((r for r in market_state.get("runners", []) if r.get("id") == selection_id), None)
        if runner and runner.get("atb"):
            return runner["atb"][0][0]
        return None

    def _best_lay(self, selection_id: int, market_state: dict) -> Optional[float]:
        runner = next((r for r in market_state.get("runners", []) if r.get("id") == selection_id), None)
        if runner and runner.get("atl"):
            return runner["atl"][0][0]
        return None
