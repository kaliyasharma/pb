from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Callable


class Condition(str, Enum):
    BACK_PRICE_BELOW = "back_price_below"
    BACK_PRICE_ABOVE = "back_price_above"
    LAY_PRICE_BELOW = "lay_price_below"
    LAY_PRICE_ABOVE = "lay_price_above"
    MATCHED_VOLUME_ABOVE = "matched_volume_above"
    IN_PLAY = "in_play"
    NOT_IN_PLAY = "not_in_play"


class Action(str, Enum):
    PLACE_BACK = "place_back"
    PLACE_LAY = "place_lay"
    CANCEL_ALL = "cancel_all"
    HEDGE = "hedge"


@dataclass
class RuleCondition:
    condition: Condition
    value: float = 0.0


@dataclass
class RuleAction:
    action: Action
    price: Optional[float] = None
    size: Optional[float] = None


@dataclass
class AutomationRule:
    rule_id: str
    name: str
    market_id: str
    selection_id: int
    conditions: list[RuleCondition] = field(default_factory=list)
    actions: list[RuleAction] = field(default_factory=list)
    enabled: bool = True
    fire_once: bool = True
    fired: bool = False

    def evaluate(self, market_state: dict) -> bool:
        if not self.enabled or (self.fire_once and self.fired):
            return False
        runner = next(
            (r for r in market_state.get("runners", []) if r.get("id") == self.selection_id),
            None,
        )
        if not runner:
            return False

        for cond in self.conditions:
            if not self._check(cond, runner, market_state):
                return False
        return True

    def _check(self, cond: RuleCondition, runner: dict, market_state: dict) -> bool:
        atb = runner.get("atb", [])
        atl = runner.get("atl", [])
        best_back = atb[0][0] if atb else None
        best_lay = atl[0][0] if atl else None

        match cond.condition:
            case Condition.BACK_PRICE_BELOW:
                return best_back is not None and best_back < cond.value
            case Condition.BACK_PRICE_ABOVE:
                return best_back is not None and best_back > cond.value
            case Condition.LAY_PRICE_BELOW:
                return best_lay is not None and best_lay < cond.value
            case Condition.LAY_PRICE_ABOVE:
                return best_lay is not None and best_lay > cond.value
            case Condition.MATCHED_VOLUME_ABOVE:
                return market_state.get("totalMatched", 0) > cond.value
            case Condition.IN_PLAY:
                return market_state.get("inPlay", False)
            case Condition.NOT_IN_PLAY:
                return not market_state.get("inPlay", False)
            case _:
                return False
