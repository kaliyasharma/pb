import logging
import sys
from pathlib import Path

LOG_DIR = Path.home() / ".betangle" / "logs"


def setup_logger(level: int = logging.INFO):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    root = logging.getLogger()
    root.setLevel(level)

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    root.addHandler(stream_handler)

    file_handler = logging.FileHandler(LOG_DIR / "betangle.log")
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)
