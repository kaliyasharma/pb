import json
import os
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Optional


CONFIG_DIR = Path.home() / ".betangle"
CONFIG_FILE = CONFIG_DIR / "config.json"


@dataclass
class Config:
    betfair_username: Optional[str] = None
    betfair_app_key: Optional[str] = None
    betfair_certs_path: Optional[str] = None
    default_stake: float = 2.0
    theme: str = "dark"

    @classmethod
    def load(cls) -> "Config":
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE) as f:
                    data = json.load(f)
                return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
            except Exception:
                pass
        return cls()

    def save(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "w") as f:
            json.dump(asdict(self), f, indent=2)
