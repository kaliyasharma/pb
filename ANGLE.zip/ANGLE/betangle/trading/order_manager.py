import logging
from typing import Optional
from betangle.api.models import Order, Side, OrderStatus

logger = logging.getLogger(__name__)


class OrderManager:
    def __init__(self, betfair_client):
        self._client = betfair_client
        self._orders: dict[str, Order] = {}  # bet_id -> Order

    def place(
        self,
        market_id: str,
        selection_id: int,
        side: Side,
        price: float,
        size: float,
    ) -> Optional[str]:
        bet_id = self._client.place_order(market_id, selection_id, side, price, size)
        if bet_id:
            from datetime import datetime
            order = Order(
                bet_id=bet_id,
                market_id=market_id,
                selection_id=selection_id,
                side=side,
                price=price,
                size=size,
                status=OrderStatus.EXECUTABLE,
                placed_date=datetime.now(),
                size_remaining=size,
            )
            self._orders[bet_id] = order
            logger.info(f"Placed {side.value} order: {bet_id} @ {price} for £{size}")
        return bet_id

    def cancel(self, bet_id: str) -> bool:
        order = self._orders.get(bet_id)
        if not order:
            logger.warning(f"Cancel requested for unknown bet: {bet_id}")
            return False
        success = self._client.cancel_order(order.market_id, bet_id)
        if success:
            order.status = OrderStatus.CANCELLED
            logger.info(f"Cancelled order {bet_id}")
        return success

    def cancel_all(self, market_id: Optional[str] = None) -> int:
        targets = [
            o for o in self._orders.values()
            if o.status == OrderStatus.EXECUTABLE
            and (market_id is None or o.market_id == market_id)
        ]
        cancelled = 0
        for order in targets:
            if self.cancel(order.bet_id):
                cancelled += 1
        return cancelled

    def refresh(self):
        live = self._client.list_current_orders()
        for order in live:
            self._orders[order.bet_id] = order

    def get_orders(self, market_id: Optional[str] = None) -> list[Order]:
        orders = list(self._orders.values())
        if market_id:
            orders = [o for o in orders if o.market_id == market_id]
        return orders

    def get_position(self, market_id: str, selection_id: int) -> dict:
        orders = [
            o for o in self._orders.values()
            if o.market_id == market_id and o.selection_id == selection_id
        ]
        matched_back = sum(o.size_matched for o in orders if o.side == Side.BACK)
        matched_lay = sum(o.size_matched for o in orders if o.side == Side.LAY)
        pnl = sum(o.profit_loss for o in orders)
        return {
            "matched_back": matched_back,
            "matched_lay": matched_lay,
            "net_pnl": pnl,
            "orders": orders,
        }
