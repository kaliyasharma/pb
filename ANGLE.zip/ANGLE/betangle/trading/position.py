from dataclasses import dataclass, field
from betangle.api.models import Side


@dataclass
class Position:
    market_id: str
    selection_id: int
    backed_amount: float = 0.0
    laid_amount: float = 0.0
    average_back_price: float = 0.0
    average_lay_price: float = 0.0
    realised_pnl: float = 0.0

    @property
    def net_exposure(self) -> float:
        return self.backed_amount - self.laid_amount

    @property
    def if_wins(self) -> float:
        back_profit = self.backed_amount * (self.average_back_price - 1) if self.average_back_price else 0
        lay_liability = self.laid_amount * (self.average_lay_price - 1) if self.average_lay_price else 0
        return back_profit - lay_liability + self.realised_pnl

    @property
    def if_loses(self) -> float:
        return -self.backed_amount + self.laid_amount + self.realised_pnl


class PositionTracker:
    def __init__(self):
        self._positions: dict[tuple[str, int], Position] = {}

    def get(self, market_id: str, selection_id: int) -> Position:
        key = (market_id, selection_id)
        if key not in self._positions:
            self._positions[key] = Position(market_id=market_id, selection_id=selection_id)
        return self._positions[key]

    def record_match(
        self,
        market_id: str,
        selection_id: int,
        side: Side,
        price: float,
        size: float,
    ):
        pos = self.get(market_id, selection_id)
        if side == Side.BACK:
            total = pos.backed_amount + size
            pos.average_back_price = (
                (pos.average_back_price * pos.backed_amount + price * size) / total
                if total > 0 else price
            )
            pos.backed_amount = total
        else:
            total = pos.laid_amount + size
            pos.average_lay_price = (
                (pos.average_lay_price * pos.laid_amount + price * size) / total
                if total > 0 else price
            )
            pos.laid_amount = total

    def all_positions(self) -> list[Position]:
        return list(self._positions.values())

    def clear_market(self, market_id: str):
        keys = [k for k in self._positions if k[0] == market_id]
        for k in keys:
            del self._positions[k]
