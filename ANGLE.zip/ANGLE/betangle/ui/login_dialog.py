from PyQt6.QtWidgets import (
    QDialog, QFormLayout, QLineEdit, QPushButton,
    QDialogButtonBox, QFileDialog, QHBoxLayout, QWidget,
)
from betangle.utils.config import Config


class LoginDialog(QDialog):
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Login to Betfair")
        self.setMinimumWidth(400)
        self._config = config

        layout = QFormLayout(self)

        self._username = QLineEdit(config.betfair_username or "")
        self._password = QLineEdit()
        self._password.setEchoMode(QLineEdit.EchoMode.Password)
        self._app_key = QLineEdit(config.betfair_app_key or "")

        cert_row = QWidget()
        cert_layout = QHBoxLayout(cert_row)
        cert_layout.setContentsMargins(0, 0, 0, 0)
        self._certs_path = QLineEdit(config.betfair_certs_path or "")
        browse_btn = QPushButton("Browse")
        browse_btn.clicked.connect(self._browse_certs)
        cert_layout.addWidget(self._certs_path)
        cert_layout.addWidget(browse_btn)

        layout.addRow("Username:", self._username)
        layout.addRow("Password:", self._password)
        layout.addRow("App Key:", self._app_key)
        layout.addRow("Certs folder:", cert_row)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def _browse_certs(self):
        path = QFileDialog.getExistingDirectory(self, "Select certificates folder")
        if path:
            self._certs_path.setText(path)

    def _on_accept(self):
        self._config.betfair_username = self._username.text().strip()
        self._config.betfair_app_key = self._app_key.text().strip()
        self._config.betfair_certs_path = self._certs_path.text().strip()
        self._config.save()
        self.accept()

    def credentials(self) -> dict:
        return {
            "username": self._username.text().strip(),
            "password": self._password.text(),
            "app_key": self._app_key.text().strip(),
            "certs_path": self._certs_path.text().strip() or None,
        }
