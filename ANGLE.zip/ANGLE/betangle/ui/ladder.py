from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QLabel, QPushButton, QDoubleSpinBox, QHeaderView, QSizePolicy,
    QComboBox,
)
from PyQt6.QtCore import Qt, pyqtSignal, pyqtSlot
from PyQt6.QtGui import QColor, QFont, QBrush
import logging

from betangle.api.models import Side

logger = logging.getLogger(__name__)

BETFAIR_PRICES = [
    1.01, 1.02, 1.03, 1.04, 1.05, 1.06, 1.07, 1.08, 1.09, 1.10,
    1.11, 1.12, 1.13, 1.14, 1.15, 1.16, 1.17, 1.18, 1.19, 1.20,
    1.21, 1.22, 1.23, 1.24, 1.25, 1.26, 1.27, 1.28, 1.29, 1.30,
    1.31, 1.32, 1.33, 1.34, 1.35, 1.36, 1.37, 1.38, 1.39, 1.40,
    1.41, 1.42, 1.43, 1.44, 1.45, 1.46, 1.47, 1.48, 1.49, 1.50,
    1.55, 1.60, 1.65, 1.70, 1.75, 1.80, 1.85, 1.90, 1.95, 2.00,
    2.10, 2.20, 2.30, 2.40, 2.50, 2.60, 2.70, 2.80, 2.90, 3.00,
    3.10, 3.20, 3.30, 3.40, 3.50, 3.60, 3.70, 3.80, 3.90, 4.00,
    4.20, 4.40, 4.60, 4.80, 5.00, 5.50, 6.00, 6.50, 7.00, 7.50,
    8.00, 8.50, 9.00, 9.50, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0,
    16.0, 17.0, 18.0, 19.0, 20.0, 22.0, 25.0, 28.0, 30.0, 35.0,
    40.0, 45.0, 50.0, 55.0, 60.0, 65.0, 70.0, 75.0, 80.0, 85.0,
    90.0, 95.0, 100.0, 110.0, 120.0, 130.0, 140.0, 150.0, 160.0,
    170.0, 180.0, 190.0, 200.0, 210.0, 220.0, 230.0, 240.0, 250.0,
    260.0, 270.0, 280.0, 290.0, 300.0, 350.0, 400.0, 450.0, 500.0,
    550.0, 600.0, 650.0, 700.0, 750.0, 800.0, 850.0, 900.0, 950.0, 1000.0,
]

COL_LAY_VOL = 0
COL_LAY = 1
COL_PRICE = 2
COL_BACK = 3
COL_BACK_VOL = 4
COL_MY_BETS = 5

BACK_COLOR = QColor(163, 212, 255)   # light blue
LAY_COLOR = QColor(255, 192, 203)    # light pink
TRADED_COLOR = QColor(200, 200, 200)
BEST_BACK_COLOR = QColor(100, 180, 255)
BEST_LAY_COLOR = QColor(255, 140, 160)


class RunnerLadder(QWidget):
    bet_requested = pyqtSignal(int, Side, float, float)  # selection_id, side, price, size

    def __init__(self, selection_id: int, runner_name: str, parent=None):
        super().__init__(parent)
        self.selection_id = selection_id
        self.runner_name = runner_name
        self._best_back: float | None = None
        self._best_lay: float | None = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)

        header = QLabel(self.runner_name)
        font = QFont()
        font.setBold(True)
        header.setFont(font)
        layout.addWidget(header)

        self._table = QTableWidget(len(BETFAIR_PRICES), 6)
        self._table.setHorizontalHeaderLabels(["Lay Vol", "Lay", "Price", "Back", "Back Vol", "My Bets"])
        self._table.verticalHeader().setVisible(False)
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)

        for col in range(6):
            self._table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.Stretch)
        self._table.cellClicked.connect(self._on_cell_clicked)

        for row, price in enumerate(reversed(BETFAIR_PRICES)):
            item = QTableWidgetItem(f"{price:.2f}")
            item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item.setBackground(QBrush(TRADED_COLOR))
            self._table.setItem(row, COL_PRICE, item)
            self._table.setRowHeight(row, 18)

        layout.addWidget(self._table)

    def _price_row(self, price: float) -> int | None:
        prices = list(reversed(BETFAIR_PRICES))
        try:
            return prices.index(price)
        except ValueError:
            return None

    def update_prices(
        self,
        available_to_back: list,
        available_to_lay: list,
        traded_volume: list,
    ):
        # Clear existing back/lay columns
        for row in range(self._table.rowCount()):
            for col in [COL_LAY_VOL, COL_LAY, COL_BACK, COL_BACK_VOL]:
                self._table.setItem(row, col, QTableWidgetItem(""))
            price_item = self._table.item(row, COL_PRICE)
            if price_item:
                price_item.setBackground(QBrush(TRADED_COLOR))

        # Fill lay side
        for ps in available_to_lay:
            row = self._price_row(ps.price)
            if row is None:
                continue
            lay_item = QTableWidgetItem(f"{ps.price:.2f}")
            lay_item.setBackground(QBrush(LAY_COLOR))
            lay_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            vol_item = QTableWidgetItem(f"£{ps.size:.0f}")
            vol_item.setBackground(QBrush(LAY_COLOR))
            vol_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self._table.setItem(row, COL_LAY, lay_item)
            self._table.setItem(row, COL_LAY_VOL, vol_item)

        # Fill back side
        for ps in available_to_back:
            row = self._price_row(ps.price)
            if row is None:
                continue
            back_item = QTableWidgetItem(f"{ps.price:.2f}")
            back_item.setBackground(QBrush(BACK_COLOR))
            back_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            vol_item = QTableWidgetItem(f"£{ps.size:.0f}")
            vol_item.setBackground(QBrush(BACK_COLOR))
            vol_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self._table.setItem(row, COL_BACK, back_item)
            self._table.setItem(row, COL_BACK_VOL, vol_item)

        # Highlight best back/lay
        if available_to_back:
            self._best_back = available_to_back[0].price
            row = self._price_row(self._best_back)
            if row is not None:
                item = self._table.item(row, COL_BACK)
                if item:
                    item.setBackground(QBrush(BEST_BACK_COLOR))

        if available_to_lay:
            self._best_lay = available_to_lay[0].price
            row = self._price_row(self._best_lay)
            if row is not None:
                item = self._table.item(row, COL_LAY)
                if item:
                    item.setBackground(QBrush(BEST_LAY_COLOR))

    def _on_cell_clicked(self, row: int, col: int):
        price_item = self._table.item(row, COL_PRICE)
        if not price_item:
            return
        try:
            price = float(price_item.text())
        except ValueError:
            return

        if col in (COL_BACK, COL_BACK_VOL):
            self.bet_requested.emit(self.selection_id, Side.BACK, price, 2.0)
        elif col in (COL_LAY, COL_LAY_VOL):
            self.bet_requested.emit(self.selection_id, Side.LAY, price, 2.0)


class LadderWidget(QWidget):
    place_bet = pyqtSignal(str, int, Side, float, float)  # market_id, selection_id, side, price, size

    def __init__(self, parent=None):
        super().__init__(parent)
        self._market_id: str | None = None
        self._runner_ladders: dict[int, RunnerLadder] = {}
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)

        controls = QHBoxLayout()
        controls.addWidget(QLabel("Stake: £"))
        self._stake = QDoubleSpinBox()
        self._stake.setRange(2.0, 10000.0)
        self._stake.setValue(2.0)
        self._stake.setSingleStep(1.0)
        controls.addWidget(self._stake)
        controls.addStretch()

        self._market_label = QLabel("No market selected")
        font = QFont()
        font.setBold(True)
        self._market_label.setFont(font)
        controls.addWidget(self._market_label)

        layout.addLayout(controls)

        self._runners_layout = QHBoxLayout()
        layout.addLayout(self._runners_layout)

    def set_market(self, market_book):
        self._market_id = market_book.market_id

        # Clear existing ladders
        for ladder in self._runner_ladders.values():
            ladder.setParent(None)
        self._runner_ladders.clear()

        for runner in market_book.runners:
            ladder = RunnerLadder(
                selection_id=runner.selection_id,
                runner_name=str(runner.selection_id),
            )
            ladder.bet_requested.connect(self._on_bet_requested)
            self._runners_layout.addWidget(ladder)
            self._runner_ladders[runner.selection_id] = ladder
            ladder.update_prices(
                available_to_back=runner.ex.available_to_back or [],
                available_to_lay=runner.ex.available_to_lay or [],
                traded_volume=runner.ex.traded_volume or [],
            )

    def on_stream_update(self, update: dict):
        for runner_book in update.get("runners", []):
            selection_id = runner_book.get("id")
            ladder = self._runner_ladders.get(selection_id)
            if ladder:
                ladder.update_prices(
                    available_to_back=runner_book.get("atb", []),
                    available_to_lay=runner_book.get("atl", []),
                    traded_volume=runner_book.get("trd", []),
                )

    @pyqtSlot(int, Side, float, float)
    def _on_bet_requested(self, selection_id: int, side: Side, price: float, _default_size: float):
        if self._market_id:
            stake = self._stake.value()
            self.place_bet.emit(self._market_id, selection_id, side, price, stake)
