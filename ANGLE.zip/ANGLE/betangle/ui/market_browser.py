from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QTreeWidget, QTreeWidgetItem,
    QLineEdit, QLabel,
)
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QFont
from datetime import datetime

from betangle.api.models import Market


class MarketBrowser(QWidget):
    market_selected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._markets: list[Market] = []
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        label = QLabel("Markets")
        font = QFont()
        font.setBold(True)
        label.setFont(font)
        layout.addWidget(label)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Search markets...")
        self._search.textChanged.connect(self._filter)
        layout.addWidget(self._search)

        self._tree = QTreeWidget()
        self._tree.setHeaderLabels(["Event / Market", "Start", "In-Play"])
        self._tree.setColumnWidth(0, 200)
        self._tree.setColumnWidth(1, 80)
        self._tree.setColumnWidth(2, 50)
        self._tree.itemDoubleClicked.connect(self._on_item_double_clicked)
        layout.addWidget(self._tree)

    def set_markets(self, markets: list[Market]):
        self._markets = markets
        self._render(markets)

    def _filter(self, text: str):
        text = text.lower()
        filtered = [
            m for m in self._markets
            if text in m.event_name.lower() or text in m.market_name.lower()
        ]
        self._render(filtered)

    def _render(self, markets: list[Market]):
        self._tree.clear()
        grouped: dict[str, list[Market]] = {}
        for m in markets:
            grouped.setdefault(m.event_name, []).append(m)

        for event_name, event_markets in sorted(grouped.items()):
            event_item = QTreeWidgetItem([event_name])
            event_item.setExpanded(True)
            for market in sorted(event_markets, key=lambda m: m.market_start_time):
                start = market.market_start_time.strftime("%H:%M")
                in_play = "Yes" if market.in_play else ""
                child = QTreeWidgetItem([market.market_name, start, in_play])
                child.setData(0, Qt.ItemDataRole.UserRole, market.market_id)
                event_item.addChild(child)
            self._tree.addTopLevelItem(event_item)

    def _on_item_double_clicked(self, item: QTreeWidgetItem, _col: int):
        market_id = item.data(0, Qt.ItemDataRole.UserRole)
        if market_id:
            self.market_selected.emit(market_id)

    def clear(self):
        self._markets = []
        self._tree.clear()
