from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QStatusBar, QToolBar, QLabel, QPushButton,
    QMessageBox, QTabWidget,
)
from PyQt6.QtCore import Qt, QTimer, pyqtSlot
from PyQt6.QtGui import QAction, QIcon
import logging

from betangle.utils.config import Config
from betangle.api.client import BetfairClient
from betangle.api.streaming import StreamingClient
from betangle.trading.order_manager import OrderManager
from betangle.automation.engine import AutomationEngine
from betangle.ui.market_browser import MarketBrowser
from betangle.ui.ladder import LadderWidget
from betangle.ui.login_dialog import LoginDialog

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    def __init__(self, config: Config):
        super().__init__()
        self._config = config
        self._betfair_client: BetfairClient | None = None
        self._streaming_client: StreamingClient | None = None
        self._order_manager: OrderManager | None = None
        self._automation_engine: AutomationEngine | None = None
        self._active_market_id: str | None = None

        self._setup_ui()
        self._setup_toolbar()
        self._setup_status_bar()

        self._refresh_timer = QTimer(self)
        self._refresh_timer.timeout.connect(self._tick)
        self._refresh_timer.start(1000)

    def _setup_ui(self):
        self.setWindowTitle("Betangle")
        self.setMinimumSize(1280, 800)
        self.resize(1440, 900)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(4, 4, 4, 4)

        self._splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(self._splitter)

        # Left panel: market browser
        self._market_browser = MarketBrowser()
        self._market_browser.market_selected.connect(self._on_market_selected)
        self._splitter.addWidget(self._market_browser)

        # Right panel: tabbed (ladder + automation)
        self._right_tabs = QTabWidget()
        self._splitter.addWidget(self._right_tabs)

        self._ladder = LadderWidget()
        self._right_tabs.addTab(self._ladder, "Ladder")

        self._splitter.setSizes([320, 960])

    def _setup_toolbar(self):
        toolbar = QToolBar("Main")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        self._login_action = QAction("Login", self)
        self._login_action.triggered.connect(self._on_login)
        toolbar.addAction(self._login_action)

        self._logout_action = QAction("Logout", self)
        self._logout_action.triggered.connect(self._on_logout)
        self._logout_action.setEnabled(False)
        toolbar.addAction(self._logout_action)

        toolbar.addSeparator()

        self._refresh_markets_btn = QPushButton("Refresh Markets")
        self._refresh_markets_btn.clicked.connect(self._refresh_markets)
        self._refresh_markets_btn.setEnabled(False)
        toolbar.addWidget(self._refresh_markets_btn)

    def _setup_status_bar(self):
        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)
        self._connection_label = QLabel("Not connected")
        self._status_bar.addPermanentWidget(self._connection_label)

    @pyqtSlot()
    def _on_login(self):
        dialog = LoginDialog(self._config, parent=self)
        if dialog.exec():
            creds = dialog.credentials()
            self._betfair_client = BetfairClient(
                username=creds["username"],
                password=creds["password"],
                app_key=creds["app_key"],
                certs_path=creds.get("certs_path"),
            )
            if self._betfair_client.login():
                self._order_manager = OrderManager(self._betfair_client)
                self._streaming_client = StreamingClient(
                    betfair_client=self._betfair_client,
                    on_market_update=self._on_stream_update,
                )
                self._automation_engine = AutomationEngine(self._order_manager)
                self._connection_label.setText(f"Connected: {creds['username']}")
                self._login_action.setEnabled(False)
                self._logout_action.setEnabled(True)
                self._refresh_markets_btn.setEnabled(True)
                self._refresh_markets()
            else:
                QMessageBox.critical(self, "Login Failed", "Could not log in to Betfair. Check your credentials.")

    @pyqtSlot()
    def _on_logout(self):
        if self._streaming_client:
            self._streaming_client.stop()
        if self._betfair_client:
            self._betfair_client.logout()
        self._betfair_client = None
        self._streaming_client = None
        self._order_manager = None
        self._automation_engine = None
        self._connection_label.setText("Not connected")
        self._login_action.setEnabled(True)
        self._logout_action.setEnabled(False)
        self._refresh_markets_btn.setEnabled(False)
        self._market_browser.clear()

    @pyqtSlot()
    def _refresh_markets(self):
        if not self._betfair_client:
            return
        markets = self._betfair_client.list_markets()
        self._market_browser.set_markets(markets)
        self._status_bar.showMessage(f"Loaded {len(markets)} markets", 3000)

    @pyqtSlot(str)
    def _on_market_selected(self, market_id: str):
        if self._active_market_id and self._streaming_client:
            self._streaming_client.unsubscribe([self._active_market_id])

        self._active_market_id = market_id

        if self._betfair_client:
            market_book = self._betfair_client.get_market_book(market_id)
            if market_book:
                self._ladder.set_market(market_book)

        if self._streaming_client:
            self._streaming_client.subscribe([market_id])

    def _on_stream_update(self, market_id: str, update: dict):
        if market_id == self._active_market_id:
            self._ladder.on_stream_update(update)

        if self._automation_engine:
            self._automation_engine.evaluate(market_id, update)

    @pyqtSlot()
    def _tick(self):
        pass

    def closeEvent(self, event):
        if self._streaming_client:
            self._streaming_client.stop()
        if self._betfair_client:
            self._betfair_client.logout()
        event.accept()
