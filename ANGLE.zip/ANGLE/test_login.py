"""
PB77 Login Test — verifies the 3-step auth flow:
  Step 1: Send OTP email
  Step 2: Verify OTP → get token
  Step 3: Exchange handshake → get BIAB_CUSTOMER + exchange URL
"""
import sys
import json
from urllib.parse import quote
import httpx
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QStatusBar,
    QMainWindow,
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont


WWW_BASE = "https://www.pb77.co"

HEADERS = {
    "Language": "en-US",
    "Clienttype": "2",
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/146.0.0.0 Safari/537.36"
    ),
    "Origin": "https://www.pb77.co",
    "Referer": "https://www.pb77.co/",
    "Accept": "*/*",
}


# ── Background workers ────────────────────────────────────────────────────────

class OtpWorker(QThread):
    done = pyqtSignal(bool, str)   # success, message

    def __init__(self, client: httpx.Client, email: str):
        super().__init__()
        self._client = client
        self._email = email

    def run(self):
        try:
            resp = self._client.post(
                f"{WWW_BASE}/api/v2/otp/email",
                params={"used": "true", "email": self._email},
            )
            body = resp.json()
            if body.get("status") == 200:
                self.done.emit(True, "OTP sent — check your email.")
            else:
                self.done.emit(False, f"Failed: {json.dumps(body, indent=2)}")
        except Exception as e:
            self.done.emit(False, f"Error: {e}")


class LoginWorker(QThread):
    done = pyqtSignal(bool, str, dict)  # success, message, full_data

    def __init__(self, client: httpx.Client, email: str, otp: str):
        super().__init__()
        self._client = client
        self._email = email
        self._otp = otp

    def run(self):
        # Step 2 — verify OTP
        try:
            resp = self._client.post(
                f"{WWW_BASE}/api/v2/login/email",
                content=f"email={quote(self._email)}&otp={self._otp}",
                headers={"Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"},
            )
            body = resp.json()
            if body.get("status") != 200:
                self.done.emit(False, f"OTP verify failed:\n{json.dumps(body, indent=2)}", {})
                return

            d = body["data"]
            token = d["token"]
            nickname = d["nickname"]

            # Step 3 — exchange handshake
            resp2 = self._client.post(
                f"{WWW_BASE}/api/exchange2",
                params={"token": token, "name": nickname},
                headers={"Token": token},
            )
            body2 = resp2.json()
            if body2.get("status") != 200:
                self.done.emit(False, f"Exchange handshake failed:\n{json.dumps(body2, indent=2)}", {})
                return

            result = {
                "step2_login": body,
                "step3_exchange": body2,
            }
            self.done.emit(True, "All 3 steps succeeded!", result)

        except Exception as e:
            self.done.emit(False, f"Error: {e}", {})


# ── Main window ───────────────────────────────────────────────────────────────

class LoginTestWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PB77 Login Test")
        self.setMinimumWidth(680)
        self.setMinimumHeight(600)

        self._client = httpx.Client(headers=HEADERS, follow_redirects=True, timeout=15)
        self._worker = None

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(10)
        layout.setContentsMargins(16, 16, 16, 16)

        # Title
        title = QLabel("PB77 Auth Flow Tester")
        font = QFont()
        font.setPointSize(15)
        font.setBold(True)
        title.setFont(font)
        layout.addWidget(title)

        # Email row
        email_row = QHBoxLayout()
        email_row.addWidget(QLabel("Email:"))
        self._email_input = QLineEdit()
        self._email_input.setPlaceholderText("your@email.com")
        email_row.addWidget(self._email_input)
        self._otp_btn = QPushButton("Send OTP")
        self._otp_btn.setFixedWidth(100)
        self._otp_btn.clicked.connect(self._send_otp)
        email_row.addWidget(self._otp_btn)
        layout.addLayout(email_row)

        # OTP row
        otp_row = QHBoxLayout()
        otp_row.addWidget(QLabel("OTP:   "))
        self._otp_input = QLineEdit()
        self._otp_input.setPlaceholderText("6-digit code from email")
        self._otp_input.setMaxLength(6)
        self._otp_input.setEnabled(False)
        otp_row.addWidget(self._otp_input)
        self._login_btn = QPushButton("Verify & Login")
        self._login_btn.setFixedWidth(100)
        self._login_btn.setEnabled(False)
        self._login_btn.clicked.connect(self._verify_login)
        otp_row.addWidget(self._login_btn)
        layout.addLayout(otp_row)

        # Output
        layout.addWidget(QLabel("Response:"))
        self._output = QTextEdit()
        self._output.setReadOnly(True)
        self._output.setFont(QFont("Courier", 11))
        self._output.setPlaceholderText("Response will appear here...")
        layout.addWidget(self._output)

        # Status bar
        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.showMessage("Enter your email and click Send OTP")

    # ── Actions ───────────────────────────────────────────────────────────────

    def _send_otp(self):
        email = self._email_input.text().strip()
        if not email:
            self._status.showMessage("Please enter your email first.")
            return
        self._set_busy(True)
        self._output.clear()
        self._log(f"Step 1 — Sending OTP to {email} ...")
        self._worker = OtpWorker(self._client, email)
        self._worker.done.connect(self._on_otp_sent)
        self._worker.start()

    def _on_otp_sent(self, success: bool, message: str):
        self._set_busy(False)
        self._log(message)
        if success:
            self._otp_input.setEnabled(True)
            self._login_btn.setEnabled(True)
            self._otp_input.setFocus()
            self._status.showMessage("OTP sent. Enter the code from your email.")
        else:
            self._status.showMessage("OTP send failed — see output.")

    def _verify_login(self):
        email = self._email_input.text().strip()
        otp = self._otp_input.text().strip()
        if not otp or len(otp) != 6:
            self._status.showMessage("Enter the 6-digit OTP code.")
            return
        self._set_busy(True)
        self._log(f"\nStep 2 — Verifying OTP ...")
        self._log(f"Step 3 — Exchange handshake ...")
        self._worker = LoginWorker(self._client, email, otp)
        self._worker.done.connect(self._on_logged_in)
        self._worker.start()

    def _on_logged_in(self, success: bool, message: str, data: dict):
        self._set_busy(False)
        self._log(f"\n{'✓' if success else '✗'} {message}\n")
        if data:
            self._log("=" * 60)
            self._log("STEP 2 — Login Response:")
            self._log(json.dumps(data.get("step2_login", {}), indent=2))
            self._log("\n" + "=" * 60)
            self._log("STEP 3 — Exchange Response:")
            self._log(json.dumps(data.get("step3_exchange", {}), indent=2))
        self._status.showMessage("Done — check output above." if success else "Login failed.")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _log(self, text: str):
        self._output.append(text)

    def _set_busy(self, busy: bool):
        self._otp_btn.setEnabled(not busy)
        self._login_btn.setEnabled(not busy)
        self._email_input.setEnabled(not busy)
        self._status.showMessage("Working..." if busy else "")

    def closeEvent(self, event):
        self._client.close()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = LoginTestWindow()
    win.show()
    sys.exit(app.exec())
