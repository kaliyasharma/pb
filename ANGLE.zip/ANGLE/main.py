import sys
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from betangle.ui.main_window import MainWindow
from betangle.utils.logger import setup_logger
from betangle.utils.config import Config


def main():
    setup_logger()
    config = Config.load()

    app = QApplication(sys.argv)
    app.setApplicationName("Betangle")
    app.setApplicationVersion("0.1.0")
    app.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps)

    window = MainWindow(config)
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
