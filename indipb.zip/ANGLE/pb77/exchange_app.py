"""
Exchange Suite  (Team A vs Team B)
==================================
One window, two tabs:

  1. Market Simulator  - dummy 2-runner order book with unmatched back & lay on
     both teams, place Back/Lay bets, built-in cross-matching engine.
  2. Odds Calculator   - Team A back odd -> Team B fair back odd converter.

2-runner equivalence used everywhere:
    Back B @ o == Lay  A @ o/(o-1)
    Lay  B @ o == Back A @ o/(o-1)
Match rule between opposite-team backs:  (oA-1)(oB-1) <= 1.

Pure standard library (Tkinter).   Run:  python exchange_app.py
"""

import tkinter as tk
from tkinter import ttk
from itertools import count

_ids = count(1)


# =========================================================================== #
#  Matching engine
# =========================================================================== #
def to_line(team, side, odds, stake):
    """Translate (team, side, odds, stake) to the selection-A line.

    Returns (line_side, line_odds, capA) with capA in A backer-stake units.
    """
    if team == 'A' and side == 'back':
        return 'backA', odds, stake
    if team == 'A' and side == 'lay':
        return 'layA', odds, stake
    if team == 'B' and side == 'back':                   # Back B == Lay A
        return 'layA', odds / (odds - 1), stake * (odds - 1)
    if team == 'B' and side == 'lay':                    # Lay B == Back A
        return 'backA', odds / (odds - 1), stake * (odds - 1)
    raise ValueError("bad order")


def own_stake(team, m, q):
    """A-backer-stake q matched at A-line odds m -> this team's own stake."""
    if team == 'A':
        return q
    b_odds = m / (m - 1)
    return q / (b_odds - 1)


class Market:
    def __init__(self):
        self.backA = []
        self.layA = []
        self.fills = []

    def submit(self, team, side, odds, stake):
        line_side, line_odds, capA = to_line(team, side, odds, stake)
        order = {'oid': next(_ids), 'team': team, 'side': side, 'odds': odds,
                 'line_side': line_side, 'line_odds': line_odds, 'capA': capA}

        if line_side == 'backA':
            opp = self.layA
            opp.sort(key=lambda o: -o['line_odds'])
            crosses = lambda r: r['line_odds'] >= order['line_odds'] - 1e-12
        else:
            opp = self.backA
            opp.sort(key=lambda o: o['line_odds'])
            crosses = lambda r: r['line_odds'] <= order['line_odds'] + 1e-12

        for r in opp:
            if order['capA'] <= 1e-9:
                break
            if not crosses(r):
                break
            m = r['line_odds']
            q = min(order['capA'], r['capA'])
            order['capA'] -= q
            r['capA'] -= q
            self.fills.append({
                'm': m, 'q': q,
                'in': f"{order['team']} {order['side']} @{order['odds']:.2f}",
                'rest': f"{r['team']} {r['side']} @{r['odds']:.2f}",
                'A_stake': own_stake('A', m, q),
                'B_stake': own_stake('B', m, q),
                'A_odds': m, 'B_odds': m / (m - 1),
            })

        opp[:] = [o for o in opp if o['capA'] > 1e-9]
        if order['capA'] > 1e-9:
            (self.backA if line_side == 'backA' else self.layA).append(order)
        return order

    def clear_to_odds(self, team, side, target):
        """Match ALL resting liquidity shown on ladders()[team][side] up to
        'target' in one shot.

        We sweep in the common selection-A space (capA units) so the fill is
        exact: a single team-priced order would either miss the boundary level
        (its displayed tick sits above the resting order's exact odd) or, for
        Team B, under-fill (its stake is scaled by the placement odd).  Here we
        gather the exact capA to clear and submit one generous A-line order
        whose stake cap stops it right at 'target'.

        Returns the capA cleared.
        """
        def b_odd(o):
            return o['line_odds'] / (o['line_odds'] - 1)

        if (team, side) == ('A', 'back'):
            book, bucket, ge, aline = self.layA, lambda o: o['line_odds'], True, ('A', 'back', 1.01)
        elif (team, side) == ('B', 'lay'):
            book, bucket, ge, aline = self.layA, b_odd, False, ('A', 'back', 1.01)
        elif (team, side) == ('A', 'lay'):
            book, bucket, ge, aline = self.backA, lambda o: o['line_odds'], False, ('A', 'lay', 1000.0)
        else:  # ('B', 'back')
            book, bucket, ge, aline = self.backA, b_odd, True, ('A', 'lay', 1000.0)

        cap = 0.0
        for o in book:
            disp = snap_odd(bucket(o))           # the tick the ladder shows
            keep = disp >= target - 1e-9 if ge else disp <= target + 1e-9
            if keep:
                cap += o['capA']
        if cap > 1e-9:
            t, s, od = aline
            self.submit(t, s, od, cap)
        return cap

    def ladders(self):
        def agg(pairs):
            # snap each cross-derived odd to the nearest valid Betfair tick
            d = {}
            for o, s in pairs:
                tick = snap_odd(o)
                d[tick] = d.get(tick, 0.0) + s
            return d

        a_back = agg((o['line_odds'], o['capA']) for o in self.layA)
        a_lay = agg((o['line_odds'], o['capA']) for o in self.backA)
        b_back = agg((bo := o['line_odds'] / (o['line_odds'] - 1),
                      o['capA'] / (bo - 1)) for o in self.backA)
        b_lay = agg((bo := o['line_odds'] / (o['line_odds'] - 1),
                     o['capA'] / (bo - 1)) for o in self.layA)

        def top(d, reverse):
            return sorted(d.items(), key=lambda kv: kv[0], reverse=reverse)

        return {
            'A': {'back': top(a_back, True),  'lay': top(a_lay, False)},
            'B': {'back': top(b_back, True),  'lay': top(b_lay, False)},
        }


def seed_dummy(market):
    # Nothing crosses on load: every LAY-A-line order sits at A-odds <= 3.00,
    # every BACK-A-line order at A-odds >= 3.20  (so both teams show deep,
    # unmatched back & lay ladders).
    orders = [
        # --- LAY-A line  (Team A back-avail / Team B lay-avail) ---
        ('A', 'lay',  3.00, 120),
        ('A', 'lay',  2.95,  80),
        ('A', 'lay',  2.90, 150),
        ('A', 'lay',  2.85,  60),
        ('B', 'back', 1.55, 120),   # line 2.82
        ('B', 'back', 1.60, 200),   # line 2.67
        ('B', 'back', 1.65,  90),   # line 2.54
        ('B', 'back', 1.70, 140),   # line 2.43
        # --- BACK-A line (Team A lay-avail / Team B back-avail) ---
        ('A', 'back', 3.20, 100),
        ('A', 'back', 3.30,  75),
        ('A', 'back', 3.40, 130),
        ('A', 'back', 3.50,  90),
        ('A', 'back', 3.70,  60),
        ('B', 'lay',  1.45,  90),   # line 3.22
        ('B', 'lay',  1.42, 110),   # line 3.38
        ('B', 'lay',  1.40, 160),   # line 3.50
        ('B', 'lay',  1.38,  70),   # line 3.63
    ]
    for team, side, odds, stake in orders:
        market.submit(team, side, odds, stake)


def _betfair_ladder():
    """The full Betfair price ladder (valid tradeable odds), 350 ticks."""
    ranges = [
        (1.01, 2.00, 0.01), (2.00, 3.00, 0.02), (3.00, 4.00, 0.05),
        (4.00, 6.00, 0.10), (6.00, 10.00, 0.20), (10.00, 20.00, 0.50),
        (20.00, 30.00, 1.00), (30.00, 50.00, 2.00), (50.00, 100.00, 5.00),
        (100.00, 1000.00, 10.00),
    ]
    odds = []
    for start, end, step in ranges:
        for i in range(round((end - start) / step)):   # integer ticks: no FP drift
            odds.append(round(start + i * step, 2))
    odds.append(1000.0)
    return odds


BETFAIR_ODDS = _betfair_ladder()


def snap_odd(x):
    """Snap any odd to the nearest valid Betfair tick (e.g. 101 -> 100, 51 -> 50)."""
    return min(BETFAIR_ODDS, key=lambda t: abs(t - x))


def opposite(odd):
    """Valid Betfair back odd for the other team in a 2-outcome market."""
    if odd <= 1:
        return None
    return snap_odd(odd / (odd - 1))


# =========================================================================== #
#  Tab 1 — Market Simulator
# =========================================================================== #
class MarketTab(ttk.Frame):
    LEVELS = 4
    SKY = "#87CEEB"       # back odds   - sky blue
    PINK = "#FFC0CB"      # lay odds    - light pink
    WHITE = "#ffffff"     # size (£)    - plain white, no color
    HILITE = "#FFD54A"    # changed cell - gold highlight
    VISIBLE_ROWS = 7      # rows shown before the ladder scrolls

    def __init__(self, parent):
        super().__init__(parent, padding=10)
        self.market = Market()
        self.prev_a = {'back': set(), 'lay': set()}
        self.prev_b = {'back': set(), 'lay': set()}

        ladders = ttk.Frame(self)
        ladders.pack(fill="x")
        self.body_a, self.canvas_a = self._team_panel(ladders, "TEAM  A", 0)
        self.body_b, self.canvas_b = self._team_panel(ladders, "TEAM  B", 1)
        ladders.columnconfigure(0, weight=1)
        ladders.columnconfigure(1, weight=1)

        self._converter_form()
        self._bet_form()

        seed_dummy(self.market)
        self.refresh()

    def _team_panel(self, parent, title, col):
        frame = ttk.LabelFrame(parent, text=title, padding=6)
        frame.grid(row=0, column=col, sticky="nsew", padx=6)

        # fixed header row
        header = tk.Frame(frame)
        header.grid(row=0, column=0, sticky="w")
        head_bg = (self.WHITE, self.SKY, self.PINK, self.WHITE)
        for j, h in enumerate(("Back £", "Back", "Lay", "Lay £")):
            tk.Label(header, text=h, font=("Segoe UI", 9, "bold"), width=8,
                     bg=head_bg[j], relief="ridge", borderwidth=1).grid(row=0, column=j)

        # scrollable body (canvas + vertical scrollbar)
        canvas = tk.Canvas(frame, height=self.VISIBLE_ROWS * 24,
                           highlightthickness=0)
        vsb = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        canvas.grid(row=1, column=0, sticky="nsew")
        vsb.grid(row=1, column=1, sticky="ns")

        body = tk.Frame(canvas)
        canvas.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>",
                  lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        # mouse-wheel scrolling while hovering the ladder
        canvas.bind("<Enter>", lambda e: canvas.bind_all(
            "<MouseWheel>",
            lambda ev: canvas.yview_scroll(int(-ev.delta / 120), "units")))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
        return body, canvas

    def _converter_form(self):
        f = ttk.LabelFrame(self, text="Odds converter "
                                      "(select a team, enter its odd -> get the other team's odd)",
                           padding=8)
        f.pack(fill="x", pady=(10, 0))

        self._snap_after = None        # pending auto-correct (debounce) id
        self.cv_team = tk.StringVar(value="A")
        ttk.Label(f, text="Team").grid(row=0, column=0, padx=(4, 6))
        ttk.Radiobutton(f, text="A", variable=self.cv_team, value="A",
                        command=self._recalc_conv).grid(row=0, column=1)
        ttk.Radiobutton(f, text="B", variable=self.cv_team, value="B",
                        command=self._recalc_conv).grid(row=0, column=2)

        # ---- BACK row (opponent) ----
        ttk.Label(f, text="Back Odd").grid(row=0, column=3, padx=(16, 6))
        self.cv_in = tk.StringVar(value="2.00")
        e = ttk.Entry(f, textvariable=self.cv_in, width=8, justify="right",
                      font=("Consolas", 12))
        e.grid(row=0, column=4)
        e.bind("<KeyRelease>", lambda _e: self._on_odd_edit(self.cv_in, self._sync_from_team_odd))

        ttk.Label(f, text="->").grid(row=0, column=5, padx=10)
        self.cv_out = ttk.Label(f, text="", font=("Segoe UI", 10, "bold"),
                                foreground="#0a7d28")
        self.cv_out.grid(row=0, column=6, padx=(0, 4))
        # opponent odd is editable: derived from the team odd, or typed directly
        self.cv_opp = tk.StringVar(value="2.00")
        eo = ttk.Entry(f, textvariable=self.cv_opp, width=8, justify="right",
                       font=("Consolas", 12))
        eo.grid(row=0, column=7)
        eo.bind("<KeyRelease>", lambda _e: self._on_odd_edit(self.cv_opp, self._sync_from_opp_odd))
        # second line: just the result (total back stake) + a place-bet button
        self.cv_liq = ttk.Label(f, text="", font=("Consolas", 11, "bold"),
                                foreground="#0a4d8c")
        self.cv_liq.grid(row=1, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Label(f, text="Add +").grid(row=1, column=3, padx=(14, 4), pady=(6, 0))
        self.cv_add = tk.StringVar(value="")      # blank = add nothing
        ttk.Entry(f, textvariable=self.cv_add, width=7, justify="right").grid(
            row=1, column=4, pady=(6, 0))
        self.cv_bet_btn = ttk.Button(f, text="Place Bet",
                                     command=self.place_converter_bet)
        self.cv_bet_btn.grid(row=1, column=5, sticky="w", padx=(14, 0), pady=(6, 0))
        self._cv_bet = None       # (team, odds, total_stake) ready to place

        ttk.Separator(f, orient="horizontal").grid(
            row=2, column=0, columnspan=8, sticky="ew", pady=(8, 6))

        # ---- SAME-TEAM BACK row (same shape; backs the selected team) ----
        ttk.Label(f, text="Back Odd (same)").grid(row=3, column=3, padx=(16, 6))
        self.cv_sb_in = tk.StringVar(value="2.00")
        el = ttk.Entry(f, textvariable=self.cv_sb_in, width=8, justify="right",
                       font=("Consolas", 12))
        el.grid(row=3, column=4)
        el.bind("<KeyRelease>", lambda _e: self._on_odd_edit(self.cv_sb_in, self._sync_from_sameback_odd))

        ttk.Label(f, text="=").grid(row=3, column=5, padx=10)
        self.cv_sb_out = ttk.Label(f, text="", font=("Consolas", 13, "bold"),
                                   foreground="#0a7d28")
        self.cv_sb_out.grid(row=3, column=6)
        self.cv_sb_liq = ttk.Label(f, text="", font=("Consolas", 11, "bold"),
                                   foreground="#0a4d8c")
        self.cv_sb_liq.grid(row=4, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Label(f, text="Add +").grid(row=4, column=3, padx=(14, 4), pady=(6, 0))
        self.cv_sb_add = tk.StringVar(value="")      # blank = add nothing
        ttk.Entry(f, textvariable=self.cv_sb_add, width=7, justify="right").grid(
            row=4, column=4, pady=(6, 0))
        self.cv_sb_btn = ttk.Button(f, text="Place Back Bet (same)",
                                    command=self.place_converter_sameback)
        self.cv_sb_btn.grid(row=4, column=5, sticky="w", padx=(14, 0), pady=(6, 0))
        self._cv_sb_bet = None   # (team, odds, total_stake) ready to place

        self._recalc_conv()

    def _recalc_conv(self):
        self._sync_from_team_odd()

    def _sync_from_team_odd(self):
        """Selected team's back odd is the source: mirror it to the same-team
        field and derive the opponent odd, then recompute both rows."""
        self.cv_sb_in.set(self.cv_in.get())          # same-team field mirrors it
        try:
            val = float(self.cv_in.get())
            if val > 1:
                self.cv_opp.set(f"{opposite(val):.2f}")
        except ValueError:
            pass
        self.calc_conv()
        self.calc_sameback()

    def _sync_from_sameback_odd(self):
        """Same-team odd typed -> copy into the team field, then sync the rest."""
        self.cv_in.set(self.cv_sb_in.get())
        self._sync_from_team_odd()

    def _sync_from_opp_odd(self):
        """Opponent odd typed -> derive the team / same-team odds (without
        overwriting what's being typed), then recompute both rows."""
        try:
            val = float(self.cv_opp.get())
            if val > 1:
                self.cv_in.set(f"{opposite(val):.2f}")
                self.cv_sb_in.set(self.cv_in.get())
        except ValueError:
            pass
        self.calc_conv()
        self.calc_sameback()

    def _on_odd_edit(self, var, sync):
        """Recompute live on each keystroke, and (re)arm a 1-second auto-correct
        that snaps the typed odd to the nearest valid Betfair tick."""
        sync()
        if self._snap_after is not None:
            self.after_cancel(self._snap_after)
        self._snap_after = self.after(1000, lambda: self._autocorrect(var, sync))

    def _autocorrect(self, var, sync):
        self._snap_after = None
        try:
            val = float(var.get())
        except ValueError:
            return                       # not a number -> nothing to snap
        snapped = snap_odd(val)
        if f"{snapped:.2f}" != var.get().strip():
            var.set(f"{snapped:.2f}")    # correct it to a valid odd
            sync()

    def calc_conv(self):
        team = self.cv_team.get()
        other = 'B' if team == 'A' else 'A'
        self.cv_out.config(text=f"Team {other} Back", foreground="#0a7d28")
        try:
            other_odd = float(self.cv_opp.get())   # typed directly or auto-filled
            if other_odd <= 1:
                raise ValueError
        except ValueError:
            self.cv_liq.config(text="")
            self._cv_bet = None
            self.cv_bet_btn.config(state="disabled")
            return
        other_odd = snap_odd(other_odd)
        # stake to clear ALL unmatched back liquidity up to that odd (result only)
        _, total, _ = self._clear_cost(other, 'back', other_odd)
        self.cv_liq.config(text=f"Total back stake = {total:.2f}",
                           foreground="#0a4d8c" if total > 0 else "#b00020")
        # keep the button live even at 0 liquidity, so an Add+ stake can rest
        self._cv_bet = (other, other_odd, total)
        self.cv_bet_btn.config(state="normal")

    def calc_sameback(self):
        # Back strategy on the SAME selected team (no opponent conversion).
        team = self.cv_team.get()
        try:
            val = float(self.cv_sb_in.get())
            if val <= 1:
                raise ValueError
        except ValueError:
            self.cv_sb_out.config(text=f"Team {team}: -", foreground="#b00020")
            self.cv_sb_liq.config(text="")
            self._cv_sb_bet = None
            self.cv_sb_btn.config(state="disabled")
            return
        odd = snap_odd(val)
        self.cv_sb_out.config(text=f"Team {team} Back = {odd:.2f}",
                              foreground="#0a7d28")
        # stake to clear ALL unmatched back liquidity up to that odd (result only)
        _, total, _ = self._clear_cost(team, 'back', odd)
        self.cv_sb_liq.config(text=f"Total back stake = {total:.2f}",
                              foreground="#0a4d8c" if total > 0 else "#b00020")
        # keep the button live even at 0 liquidity, so an Add+ stake can rest
        self._cv_sb_bet = (team, odd, total)
        self.cv_sb_btn.config(state="normal")

    def place_converter_sameback(self):
        if not self._cv_sb_bet:
            return
        team, odds, total = self._cv_sb_bet
        add = 0.0
        txt = self.cv_sb_add.get().strip()
        if txt:                              # blank = add nothing
            try:
                add = float(txt)
            except ValueError:
                self._note(f"⚠  'Add +' value '{txt}' ignored (not a number).")
                add = 0.0
        extra = f" (clear {total:.2f} + add {add:g})" if add else ""
        before = len(self.market.fills)
        self.market.clear_to_odds(team, 'back', odds)   # sweep every level up to odds
        if add > 0:                                      # extra rests beyond the clear
            self.market.submit(team, 'back', odds, add)
        new = self.market.fills[before:]
        self._note(f"YOU: BACK Team {team} @ {odds:.2f}{extra}  (clear-to-odds)")
        for fl in new:
            self._note(f"   -> MATCHED  A@{fl['A_odds']:.2f} (A£{fl['A_stake']:.2f}) "
                       f"<-> B@{fl['B_odds']:.2f} (B£{fl['B_stake']:.2f})   "
                       f"[{fl['in']} x {fl['rest']}]")
        self.refresh(highlight=True)

    def place_converter_bet(self):
        if not self._cv_bet:
            return
        team, odds, total = self._cv_bet
        add = 0.0
        txt = self.cv_add.get().strip()
        if txt:                              # blank = add nothing
            try:
                add = float(txt)
            except ValueError:
                self._note(f"⚠  'Add +' value '{txt}' ignored (not a number).")
                add = 0.0
        extra = f" (clear {total:.2f} + add {add:g})" if add else ""
        before = len(self.market.fills)
        self.market.clear_to_odds(team, 'back', odds)   # sweep every level up to odds
        if add > 0:                                      # extra rests beyond the clear
            self.market.submit(team, 'back', odds, add)
        new = self.market.fills[before:]
        self._note(f"YOU: BACK Team {team} @ {odds:.2f}{extra}  (clear-to-odds)")
        for fl in new:
            self._note(f"   -> MATCHED  A@{fl['A_odds']:.2f} (A£{fl['A_stake']:.2f}) "
                       f"<-> B@{fl['B_odds']:.2f} (B£{fl['B_stake']:.2f})   "
                       f"[{fl['in']} x {fl['rest']}]")
        self.refresh(highlight=True)

    def _bet_form(self):
        f = ttk.LabelFrame(self, text="Place a bet", padding=10)
        f.pack(fill="x", pady=(12, 0))
        self.v_team = tk.StringVar(value="B")
        self.v_side = tk.StringVar(value="back")
        ttk.Label(f, text="Team").grid(row=0, column=0, padx=4)
        ttk.Radiobutton(f, text="A", variable=self.v_team, value="A").grid(row=0, column=1)
        ttk.Radiobutton(f, text="B", variable=self.v_team, value="B").grid(row=0, column=2)
        ttk.Label(f, text="Side").grid(row=0, column=3, padx=(14, 4))
        ttk.Radiobutton(f, text="Back", variable=self.v_side, value="back").grid(row=0, column=4)
        ttk.Radiobutton(f, text="Lay", variable=self.v_side, value="lay").grid(row=0, column=5)
        ttk.Label(f, text="Odds").grid(row=0, column=6, padx=(14, 4))
        self.v_odds = tk.StringVar(value="3.00")
        ttk.Entry(f, textvariable=self.v_odds, width=7, justify="right").grid(row=0, column=7)
        ttk.Label(f, text="Stake").grid(row=0, column=8, padx=(10, 4))
        self.v_stake = tk.StringVar(value="50")
        ttk.Entry(f, textvariable=self.v_stake, width=8, justify="right").grid(row=0, column=9)
        ttk.Button(f, text="Submit Bet", command=self.place_bet).grid(row=0, column=10, padx=(14, 0))

        btns = ttk.Frame(self)
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="Reload Dummy Market", command=self.reload).pack(side="left")
        ttk.Button(btns, text="Clear Market", command=self.clear).pack(side="left", padx=6)

    def place_bet(self):
        try:
            odds = float(self.v_odds.get())
            stake = float(self.v_stake.get())
            if odds <= 1 or stake <= 0:
                raise ValueError
        except ValueError:
            self._note("⚠  Odds must be > 1 and stake > 0.")
            return
        team, side = self.v_team.get(), self.v_side.get()
        before = len(self.market.fills)
        self.market.submit(team, side, odds, stake)
        new = self.market.fills[before:]
        self._note(f"YOU: {side.upper()} Team {team} @ {odds:.2f} for {stake:g}")
        if not new:
            self._note(f"   -> UNMATCHED (rested). {self._explain(team, side, odds)}")
        else:
            for fl in new:
                self._note(f"   -> MATCHED  A@{fl['A_odds']:.2f} (A£{fl['A_stake']:.2f}) "
                           f"<-> B@{fl['B_odds']:.2f} (B£{fl['B_stake']:.2f})   "
                           f"[{fl['in']} x {fl['rest']}]")
        self.refresh(highlight=True)

    def _explain(self, team, side, odds):
        if team == 'A' and side == 'back':
            return f"Needs Lay A (or Back B) at >= {odds:.2f}."
        if team == 'A' and side == 'lay':
            return f"Needs Back A (or Lay B) at <= {odds:.2f}."
        if team == 'B' and side == 'back':
            return f"Needs Back A at <= {odds/(odds-1):.2f} (or Lay B >= {odds:.2f})."
        return f"Needs Lay A at >= {odds/(odds-1):.2f} (or Back B <= {odds:.2f})."

    def _clear_cost(self, team, side, target):
        """All resting levels on (team, side) up to 'target', and the stake/
        liability to sweep them.  back: odds >= target ; lay: odds <= target."""
        swept = []
        for o, s in self.market.ladders()[team][side]:
            keep = (o >= target - 1e-9) if side == 'back' else (o <= target + 1e-9)
            if keep:
                swept.append((o, s))
            else:
                break
        total = sum(s for _, s in swept)
        liability = sum(s * (o - 1) for o, s in swept)
        return swept, total, liability

    def reload(self):
        self.market = Market()
        seed_dummy(self.market)
        self._note("── Dummy market reloaded ──")
        self.refresh()

    def clear(self):
        # wipe everything: book and highlights
        self.market = Market()
        self.prev_a = {'back': set(), 'lay': set()}
        self.prev_b = {'back': set(), 'lay': set()}
        self.refresh()

    def refresh(self, highlight=False):
        lad = self.market.ladders()
        self._fill(self.body_a, lad['A'], self.prev_a if highlight else None)
        self._fill(self.body_b, lad['B'], self.prev_b if highlight else None)
        self.prev_a = self._snapshot(lad['A'])
        self.prev_b = self._snapshot(lad['B'])
        if hasattr(self, 'cv_liq'):       # keep converter liquidity live
            self.calc_conv()
            self.calc_sameback()

    @staticmethod
    def _snapshot(data):
        return {side: {(round(o, 2), round(s, 2)) for o, s in data[side]}
                for side in ('back', 'lay')}

    def _fill(self, body, data, prev):
        # rebuild rows so the scroll region tracks the real number of levels
        for w in body.winfo_children():
            w.destroy()
        back, lay = data['back'], data['lay']
        for i in range(max(len(back), len(lay))):
            if i < len(back):
                o, s = back[i]
                hot = prev is not None and (round(o, 2), round(s, 2)) not in prev['back']
                self._mk(body, i, 0, f"{s:.0f}", self.WHITE, False)   # size: white
                self._mk(body, i, 1, f"{o:.2f}", self.SKY, hot)       # odds: sky
            else:
                self._mk(body, i, 0, "", self.WHITE, False)
                self._mk(body, i, 1, "", self.SKY, False)
            if i < len(lay):
                o, s = lay[i]
                hot = prev is not None and (round(o, 2), round(s, 2)) not in prev['lay']
                self._mk(body, i, 2, f"{o:.2f}", self.PINK, hot)      # odds: pink
                self._mk(body, i, 3, f"{s:.0f}", self.WHITE, False)   # size: white
            else:
                self._mk(body, i, 2, "", self.PINK, False)
                self._mk(body, i, 3, "", self.WHITE, False)

    def _mk(self, parent, r, c, text, base, hot):
        tk.Label(parent, text=text, width=8, bg=self.HILITE if hot else base,
                 relief="ridge", borderwidth=1, font=("Consolas", 10)).grid(
            row=r, column=c, sticky="nsew")

    def _note(self, text):
        # activity log removed; kept as a no-op so callers stay simple
        pass


# =========================================================================== #
#  Main window
# =========================================================================== #
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Exchange Market Simulator — Team A vs Team B")
        self.geometry("780x680")
        self.minsize(740, 620)
        self.configure(padx=10, pady=10)

        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TLabel", font=("Segoe UI", 10))

        MarketTab(self).pack(fill="both", expand=True)


if __name__ == "__main__":
    App().mainloop()
