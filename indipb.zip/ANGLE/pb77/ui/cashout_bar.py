"""
Cash Out bar — a one-click button showing the live cash-out value and profit.

Shared by both the market grid and the ladder view. Live quotes arrive on the
general WebSocket (CASH_OUT_QUOTE) and are pushed in via `apply_quote`; clicking
emits `cash_out_requested`, which the main window turns into POST /customer/api/cashout
followed by a status poll.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QPushButton, QLabel

from pb77.api.models import CashOutQuote, Market

# Amber button (matches the site's cash-out pill); greys out when unavailable.
_AMBER       = "#f4b942"
_AMBER_Hover = "#f6c65c"
_DISABLED_BG = "#2a2f3a"
_INK         = "#1a1207"   # dark text on amber
_INK_DIM     = "#5a3d10"
_DIM_TEXT    = "#9aa0ab"   # text when disabled (on dark grey)
_GREEN       = "#1b7a34"
_RED         = "#b00020"


class CashOutBar(QWidget):
    # market_id, profit, quote(value) — the figures sent to POST /cashout
    cash_out_requested = pyqtSignal(str, float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._market_id: str = ""
        self._quote: CashOutQuote | None = None
        self._currency = ""
        self._pending = False
        self._build()
        self._reset_idle("Cash Out")

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._btn = QPushButton()
        self._btn.setObjectName("CashOut")
        self._btn.setMinimumHeight(48)
        self._btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn.clicked.connect(self._on_click)

        bl = QVBoxLayout(self._btn)
        bl.setContentsMargins(10, 4, 10, 4)
        bl.setSpacing(0)
        self._value_lbl = QLabel("Cash Out")
        self._profit_lbl = QLabel("")
        for lbl in (self._value_lbl, self._profit_lbl):
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            # Let clicks fall through the labels to the button beneath.
            lbl.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
            lbl.setStyleSheet("background:transparent;")
        bl.addWidget(self._value_lbl)
        bl.addWidget(self._profit_lbl)

        root.addWidget(self._btn, stretch=1)

    # ── Public API ────────────────────────────────────────────────────────────

    def set_market(self, market: Market):
        """Reset for a freshly selected market (no quote yet)."""
        self._market_id = market.market_id
        self._quote = None
        self._pending = False
        self._reset_idle("Cash Out")

    def apply_quote(self, quote: CashOutQuote):
        """Update the button from a live CASH_OUT_QUOTE frame for this market."""
        if self._pending or quote.market_id != self._market_id:
            return
        self._quote = quote
        self._currency = quote.currency
        if not quote.available:
            self._btn.setEnabled(False)
            self._style(enabled=False)
            self._value_lbl.setText("Cash Out unavailable")
            self._profit_lbl.setText("")
            return
        self._btn.setEnabled(True)
        self._style(enabled=True)
        sym = _symbol(quote.currency)
        self._value_lbl.setText(f"Cash Out {sym}{quote.value:,.2f}")
        self._set_profit(quote.profit)

    def set_pending(self):
        """Disable + show in-flight feedback while the cash-out settles."""
        self._pending = True
        self._btn.setEnabled(False)
        self._style(enabled=False)
        self._value_lbl.setText("Cashing out…")
        self._profit_lbl.setText("")

    def notify_result(self, success: bool, message: str = ""):
        """Re-enable after a cash-out attempt; the next quote refreshes the value."""
        self._pending = False
        if success:
            self._value_lbl.setText("✓ Cashed out")
            self._profit_lbl.setText(message or "")
            self._btn.setEnabled(False)
            self._style(enabled=False)
        else:
            # Fall back to the last quote (or an idle prompt) so the user can retry.
            if self._quote is not None:
                self.apply_quote(self._quote)
            else:
                self._reset_idle("Cash Out — retry")
            if message:
                self._profit_lbl.setText(message)

    # ── Internals ─────────────────────────────────────────────────────────────

    def _on_click(self):
        q = self._quote
        if self._pending or q is None or not q.available or not self._market_id:
            return
        self.cash_out_requested.emit(self._market_id, q.profit, q.value)

    def _reset_idle(self, text: str):
        self._btn.setEnabled(False)
        self._style(enabled=False)
        self._value_lbl.setText(text)
        self._profit_lbl.setText("")

    def _set_profit(self, profit: float):
        color = _GREEN if profit >= 0 else _RED
        self._profit_lbl.setText(f"Profit: {profit:+,.2f}")
        self._profit_lbl.setStyleSheet(
            f"background:transparent; color:{color}; font-size:11px; font-weight:700;"
        )

    def _style(self, *, enabled: bool):
        """Recolour the button + value label for enabled (amber) / disabled (grey)."""
        if enabled:
            self._btn.setStyleSheet(
                f"QPushButton#CashOut {{ background:{_AMBER}; border:none; border-radius:8px; }}"
                f"QPushButton#CashOut:hover {{ background:{_AMBER_Hover}; }}"
            )
            self._value_lbl.setStyleSheet(
                f"background:transparent; color:{_INK}; font-size:15px; font-weight:800;"
            )
        else:
            self._btn.setStyleSheet(
                f"QPushButton#CashOut {{ background:{_DISABLED_BG}; border:none; border-radius:8px; }}"
            )
            self._value_lbl.setStyleSheet(
                f"background:transparent; color:{_DIM_TEXT}; font-size:14px; font-weight:700;"
            )
            self._profit_lbl.setStyleSheet(
                f"background:transparent; color:{_DIM_TEXT}; font-size:11px;"
            )


def _symbol(currency: str) -> str:
    return {"INR": "₹", "GBP": "£", "USD": "$", "EUR": "€"}.get(currency.upper(), "")
