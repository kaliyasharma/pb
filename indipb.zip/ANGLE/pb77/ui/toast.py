"""
Toast notifications — the bet-placement popups that overlay the top of the window.

A bet toast shows the bet ("Lay (Bet Against): The Draw – Match Odds" /
"225.00 @1.01 - Placing…") with a live status driven by the BET_STATUSES feed:
PENDING shows an animated spinner, then PLACED/MATCHED/UNMATCHED/… swaps in a
coloured icon and the toast auto-dismisses. ToastManager stacks them top-centre
and also shows transient error toasts (e.g. stake below minimum).
"""
from __future__ import annotations

import itertools

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
)

_SPINNER = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

# state → (suffix label, colour, icon, is_terminal)
_STATES = {
    "PENDING":   ("Placing…",          "#1a73e8", "spin", False),
    "PLACED":    ("Placed",            "#1b9e3a", "✓",    True),
    "MATCHED":   ("Matched",           "#1b9e3a", "✓",    True),
    "PARTIAL":   ("Partially matched", "#1b9e3a", "✓",    True),
    "UNMATCHED": ("Unmatched",         "#e8821a", "🕘",   True),
    "LAPSED":    ("Lapsed",            "#c0392b", "✕",    True),
    "CANCELLED": ("Cancelled",         "#c0392b", "✕",    True),
    "EXPIRED":   ("Expired",           "#c0392b", "✕",    True),
    "FAILED":    ("Failed",            "#c0392b", "✕",    True),
    "ERROR":     ("Failed",            "#c0392b", "✕",    True),
}
_DISMISS_MS = 6000


class Toast(QFrame):
    dismissed = pyqtSignal(object)      # emits the toast's key

    def __init__(self, key, parent=None):
        super().__init__(parent)
        self._key = key
        self._amount = ""
        self._spin = itertools.cycle(_SPINNER)
        self._spin_timer = QTimer(self)
        self._spin_timer.timeout.connect(self._tick)
        self._build()

    def _build(self):
        self.setObjectName("Toast")
        self.setStyleSheet(
            "QFrame#Toast { background:#ffffff; border:1px solid #e1e1e1;"
            " border-radius:8px; }"
        )
        h = QHBoxLayout(self)
        h.setContentsMargins(12, 9, 10, 9)
        h.setSpacing(11)

        self._icon = QLabel("⠋")
        self._icon.setFixedWidth(20)
        self._icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._icon.setStyleSheet("font-size:15px; color:#1a73e8; background:transparent;")
        h.addWidget(self._icon, alignment=Qt.AlignmentFlag.AlignVCenter)

        col = QVBoxLayout()
        col.setSpacing(1)
        self._title = QLabel("")
        self._title.setTextFormat(Qt.TextFormat.RichText)
        self._title.setStyleSheet("color:#1a1a1a; font-size:13px; background:transparent;")
        self._sub = QLabel("")
        self._sub.setStyleSheet("color:#1a73e8; font-size:13px; font-weight:700; background:transparent;")
        col.addWidget(self._title)
        col.addWidget(self._sub)
        h.addLayout(col, stretch=1)

        close = QPushButton("✕")
        close.setFixedSize(24, 24)
        close.setCursor(Qt.CursorShape.PointingHandCursor)
        close.setStyleSheet(
            "QPushButton { background:transparent; border:none; color:#9aa0a6; font-size:15px; }"
            "QPushButton:hover { color:#333; }"
        )
        close.clicked.connect(lambda: self.dismissed.emit(self._key))
        h.addWidget(close, alignment=Qt.AlignmentFlag.AlignTop)

    # ── content ───────────────────────────────────────────────────────────────

    def set_bet(self, title_html: str, amount: str, state: str = "PENDING"):
        self._title.setText(title_html)
        self._amount = amount
        self.set_state(state)

    def set_error(self, message: str):
        """Render as a one-line error toast (no bet line)."""
        self._title.setText(f"<span style='color:#c0392b;'>⚠ {message}</span>")
        self._sub.setText("")
        self._icon.setText("✕")
        self._icon.setStyleSheet("font-size:15px; color:#c0392b; background:transparent;")
        QTimer.singleShot(_DISMISS_MS, lambda: self.dismissed.emit(self._key))

    def set_state(self, state: str):
        suffix, color, icon, terminal = _STATES.get(
            str(state).upper(), (str(state).title(), "#555", "•", True))
        if icon == "spin":
            self._start_spin(color)
        else:
            self._stop_spin(icon, color)
        if self._amount:
            self._sub.setText(f"{self._amount} - {suffix}")
        self._sub.setStyleSheet(f"color:{color}; font-size:13px; font-weight:700; background:transparent;")
        if terminal:
            QTimer.singleShot(_DISMISS_MS, lambda: self.dismissed.emit(self._key))

    # ── spinner ───────────────────────────────────────────────────────────────

    def _start_spin(self, color: str):
        self._icon.setStyleSheet(f"font-size:15px; color:{color}; background:transparent;")
        if not self._spin_timer.isActive():
            self._spin_timer.start(90)

    def _stop_spin(self, icon: str, color: str):
        self._spin_timer.stop()
        self._icon.setText(icon)
        self._icon.setStyleSheet(f"font-size:15px; color:{color}; background:transparent;")

    def _tick(self):
        self._icon.setText(next(self._spin))


class ToastManager(QWidget):
    """Stacks toasts at the top-centre of its parent window."""

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self._toasts: dict = {}
        self._err_seq = 0
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(8)
        self._v = v
        self.hide()

    # ── public ────────────────────────────────────────────────────────────────

    def show_bet(self, key, title_html: str, amount: str, state: str = "PENDING"):
        t = self._toasts.get(key)
        if t is None:
            t = Toast(key, self)
            t.dismissed.connect(self._remove)
            self._v.addWidget(t)
            self._toasts[key] = t
        t.set_bet(title_html, amount, state)
        self._refresh()
        return t

    def update_state(self, key, state: str):
        t = self._toasts.get(key)
        if t is not None:
            t.set_state(state)

    def has(self, key) -> bool:
        return key in self._toasts

    def error(self, message: str):
        self._err_seq += 1
        key = ("__error__", self._err_seq)
        t = Toast(key, self)
        t.dismissed.connect(self._remove)
        self._v.addWidget(t)
        self._toasts[key] = t
        t.set_error(message)
        self._refresh()

    def reposition(self):
        parent = self.parentWidget()
        if parent is None:
            return
        width = min(540, max(320, parent.width() - 40))
        self.setFixedWidth(width)
        self.adjustSize()
        self.move((parent.width() - width) // 2, 14)

    # ── internal ──────────────────────────────────────────────────────────────

    def _remove(self, key):
        t = self._toasts.pop(key, None)
        if t is not None:
            t.setParent(None)
            t.deleteLater()
        if not self._toasts:
            self.hide()
        else:
            self._refresh()

    def _refresh(self):
        self.reposition()
        self.show()
        self.raise_()
