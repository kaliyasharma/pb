"""
Reusable trade-tools bar: stake selector + 2-runner odds converter +
clear-to-odds sweep. Liquidity is read from a live MarketBook, so the same
widget works in the grid view and (potentially) anywhere else.

Behaviour mirrors the ladder's tools:
  • Type Team A's back odd  → Team B's odd auto-fills, and Place Bet backs B.
  • Type Team B's back odd  → Team A's odd auto-fills, and Place Bet backs A.
  • The convert field you type in also drives the clear-to-odds row below
    (one-way: editing the clear row never flows back up).
  • ⚡ Instant toggle: off = confirm before firing, on = fire immediately.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFrame, QComboBox, QMessageBox,
)

from pb77.api.models import Market, BetInstruction
from pb77.api.prices import MarketBook
from pb77.api.ladder import snap_odd, opposite_odds

DEFAULT_STAKES = [100, 200, 300, 500, 750, 1000, 1500, 2000]


class TradeTools(QWidget):
    bets_requested = pyqtSignal(str, object)   # market_id, list[BetInstruction]
    cancel_requested = pyqtSignal(str)
    status = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._market: Market | None = None
        self._book: MarketBook | None = None
        self._selected_stake = float(DEFAULT_STAKES[0])
        self._is_line = False
        self._conv_active = "a"                       # which odd field was last typed
        self._conv_runners: list = []
        self._conv_bet: BetInstruction | None = None
        self._clear_bet: BetInstruction | None = None
        self._build()
        self.show_empty()

    # ── public API ────────────────────────────────────────────────────────────
    def selected_stake(self) -> float:
        return self._selected_stake

    def set_market(self, market: Market):
        self._market = market
        self._book = None
        self._is_line = market.is_line
        self._conv_runners = []

        self._clear_sel.blockSignals(True)
        self._clear_sel.clear()
        for r in market.runners:
            self._clear_sel.addItem(r.runner_name, r.selection_id)
        self._clear_sel.blockSignals(False)
        self._clear_to.setText("2.00")

        # Converter only valid for true 2-outcome ODDS markets.
        self._setup_converter([] if market.is_line else market.runners)
        self._calc_clear()

    def apply_book(self, book: MarketBook):
        self._book = book
        self._calc_clear()
        self._calc_conv()

    def show_empty(self):
        self._conv_row.setVisible(False)
        self._conv_bet = None
        self._clear_bet = None
        self._conv_total.setText("—")
        self._clear_size.setText("—")
        self._clear_sel.clear()

    # ── build ──────────────────────────────────────────────────────────────────
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(8)
        root.addWidget(self._build_stake_bar())
        root.addWidget(self._build_trade_tools())

    def _build_stake_bar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("Panel")
        h = QHBoxLayout(bar)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(6)

        lbl = QLabel("STAKE")
        lbl.setObjectName("SectionLabel")
        h.addWidget(lbl)

        self._stake_fields: list[QLineEdit] = []
        for i, val in enumerate(DEFAULT_STAKES):
            f = QLineEdit(str(val))
            f.setObjectName("StakeField")
            f.setFixedWidth(58)
            f.setAlignment(Qt.AlignmentFlag.AlignCenter)
            f.mousePressEvent = lambda e, idx=i: self._select_stake(idx)
            f.editingFinished.connect(lambda idx=i: self._on_stake_edited(idx))
            self._stake_fields.append(f)
            h.addWidget(f)
        self._select_stake(0)

        h.addStretch()
        self._cancel_btn = QPushButton("Cancel All")
        self._cancel_btn.setObjectName("Danger")
        self._cancel_btn.clicked.connect(self._cancel_all)
        h.addWidget(self._cancel_btn)
        return bar

    def _build_trade_tools(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("Panel")
        v = QVBoxLayout(bar)
        v.setContentsMargins(12, 8, 12, 8)
        v.setSpacing(8)

        # ── Row 1: converter + back-the-opposite-team place ───────────────────
        self._conv_row = QWidget()
        cr = QHBoxLayout(self._conv_row)
        cr.setContentsMargins(0, 0, 0, 0)
        cr.setSpacing(6)

        lbl = QLabel("CONVERT")
        lbl.setObjectName("SectionLabel")
        cr.addWidget(lbl)

        self._conv_name_a = QLabel("—")
        self._conv_name_a.setStyleSheet("font-weight:700;")
        cr.addWidget(self._conv_name_a)
        cr.addWidget(QLabel("Back"))
        self._conv_a = QLineEdit("2.00")
        self._conv_a.setFixedWidth(64)
        self._conv_a.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._conv_a.textEdited.connect(lambda: self._on_convert_edit("a"))
        cr.addWidget(self._conv_a)

        cr.addWidget(QLabel("↔"))

        self._conv_name_b = QLabel("—")
        self._conv_name_b.setStyleSheet("font-weight:700;")
        cr.addWidget(self._conv_name_b)
        cr.addWidget(QLabel("Back"))
        self._conv_b = QLineEdit("2.00")
        self._conv_b.setFixedWidth(64)
        self._conv_b.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._conv_b.textEdited.connect(lambda: self._on_convert_edit("b"))
        cr.addWidget(self._conv_b)

        cr.addSpacing(14)
        self._conv_total = QLabel("—")
        self._conv_total.setObjectName("Subtle")
        cr.addWidget(self._conv_total)

        cr.addWidget(QLabel("Add+"))
        self._conv_add = QLineEdit("")
        self._conv_add.setFixedWidth(56)
        self._conv_add.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._conv_add.setPlaceholderText("0")
        self._conv_add.textChanged.connect(self._calc_conv)
        cr.addWidget(self._conv_add)

        self._conv_place_btn = QPushButton("Place Bet")
        self._conv_place_btn.setObjectName("Primary")
        self._conv_place_btn.clicked.connect(self._place_conv)
        cr.addWidget(self._conv_place_btn)
        cr.addStretch()
        v.addWidget(self._conv_row)

        # ── Row 2: clear-to-odds sweep ────────────────────────────────────────
        clr = QWidget()
        h = QHBoxLayout(clr)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)

        lbl2 = QLabel("CLEAR")
        lbl2.setObjectName("SectionLabel")
        h.addWidget(lbl2)

        self._clear_sel = QComboBox()
        self._clear_sel.setFixedWidth(150)
        self._clear_sel.currentIndexChanged.connect(self._calc_clear)
        h.addWidget(self._clear_sel)

        self._clear_side = QComboBox()
        self._clear_side.addItems(["BACK", "LAY"])
        self._clear_side.setFixedWidth(70)
        self._clear_side.currentIndexChanged.connect(self._calc_clear)
        h.addWidget(self._clear_side)

        h.addWidget(QLabel("to"))
        self._clear_to = QLineEdit("2.00")
        self._clear_to.setFixedWidth(64)
        self._clear_to.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._clear_to.textChanged.connect(self._calc_clear)
        h.addWidget(self._clear_to)

        h.addWidget(QLabel("Add+"))
        self._clear_add = QLineEdit("")
        self._clear_add.setFixedWidth(64)
        self._clear_add.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._clear_add.setPlaceholderText("0")
        self._clear_add.textChanged.connect(self._calc_clear)
        h.addWidget(self._clear_add)

        self._clear_size = QLabel("—")
        self._clear_size.setObjectName("Subtle")
        h.addWidget(self._clear_size)
        h.addStretch()

        self._clear_btn = QPushButton("Clear-to-Odds")
        self._clear_btn.setObjectName("Primary")
        self._clear_btn.clicked.connect(self._fire_clear)
        h.addWidget(self._clear_btn)

        self._arm_btn = QPushButton("⚡ Instant")
        self._arm_btn.setCheckable(True)
        self._arm_btn.setToolTip(
            "Off (default): ask to confirm before firing.\n"
            "On (red): fire immediately on click."
        )
        self._arm_btn.setStyleSheet(
            "QPushButton { background:#2a2f3a; color:#9aa0ab; border:1px solid #3a4150;"
            "border-radius:6px; padding:5px 12px; font-weight:700; }"
            "QPushButton:checked { background:#d32f2f; color:#ffffff; border:1px solid #b71c1c; }"
        )
        h.addWidget(self._arm_btn)
        v.addWidget(clr)
        return bar

    # ── liquidity (from the live MarketBook) ───────────────────────────────────
    def _back_amounts(self, sid: int) -> dict[float, float]:
        rb = self._book.runners.get(sid) if self._book else None
        return {round(pl.odds, 2): pl.amount for pl in (rb.back if rb else []) if pl.odds > 0}

    def _lay_amounts(self, sid: int) -> dict[float, float]:
        rb = self._book.runners.get(sid) if self._book else None
        return {round(pl.odds, 2): pl.amount for pl in (rb.lay if rb else []) if pl.odds > 0}

    def _snap(self, value: float) -> float:
        return value if self._is_line else snap_odd(value)

    # ── stake selection ────────────────────────────────────────────────────────
    def _select_stake(self, idx: int):
        for i, f in enumerate(self._stake_fields):
            f.setProperty("selected", i == idx)
            f.style().unpolish(f); f.style().polish(f)
        try:
            self._selected_stake = float(self._stake_fields[idx].text())
        except ValueError:
            self._selected_stake = 0.0

    def _on_stake_edited(self, idx: int):
        if self._stake_fields[idx].property("selected"):
            try:
                self._selected_stake = float(self._stake_fields[idx].text())
            except ValueError:
                pass

    # ── converter ──────────────────────────────────────────────────────────────
    def _setup_converter(self, runners: list):
        self._conv_runners = list(runners[:2])
        if len(runners) == 2:
            self._conv_name_a.setText(runners[0].runner_name)
            self._conv_name_b.setText(runners[1].runner_name)
            self._on_convert_edit("a")
            self._conv_row.setVisible(True)
        else:
            self._conv_row.setVisible(False)
            self._calc_conv()

    def _on_convert_edit(self, src: str):
        self._conv_active = src
        src_field = self._conv_a if src == "a" else self._conv_b
        dst_field = self._conv_b if src == "a" else self._conv_a
        try:
            opp = opposite_odds(float(src_field.text()))
        except ValueError:
            opp = None
        if opp is not None:
            dst_field.blockSignals(True)
            dst_field.setText(f"{opp:g}")
            dst_field.blockSignals(False)
        self._sync_clear_from_conv()
        self._calc_conv()

    def _sync_clear_from_conv(self):
        """One-way: the convert field you typed in selects that same team + odd
        in the clear row. Editing the clear row never flows back up."""
        idx = 0 if self._conv_active == "a" else 1
        if idx >= len(self._conv_runners):
            return
        sid = self._conv_runners[idx].selection_id
        field = self._conv_a if idx == 0 else self._conv_b
        i = self._clear_sel.findData(sid)
        if i >= 0:
            self._clear_sel.setCurrentIndex(i)
        self._clear_side.setCurrentText("BACK")
        self._clear_to.setText(field.text())
        self._calc_clear()

    def _calc_conv(self, *_):
        """Size one back bet on the team OPPOSITE to the odd you typed."""
        self._conv_bet = None
        runners = self._conv_runners
        if len(runners) != 2 or self._is_line:
            self._conv_total.setText("—")
            self._conv_place_btn.setEnabled(False)
            return
        if self._conv_active == "a":
            target_runner, target_field = runners[1], self._conv_b
        else:
            target_runner, target_field = runners[0], self._conv_a
        try:
            add = float(self._conv_add.text()) if self._conv_add.text().strip() else 0.0
        except ValueError:
            add = 0.0
        try:
            target = self._snap(float(target_field.text()))
        except ValueError:
            self._conv_total.setText("—")
            self._conv_place_btn.setEnabled(False)
            return
        back = self._back_amounts(target_runner.selection_id)
        sweep = sum(a for od, a in back.items() if od >= target - 1e-9)
        size = sweep + add
        self._conv_total.setText(f"Back {target_runner.runner_name}: {size:,.0f}")
        if size > 0:
            self._conv_bet = BetInstruction(target_runner.selection_id, "BACK", target, size)
            self._conv_place_btn.setEnabled(True)
        else:
            self._conv_place_btn.setEnabled(False)

    def _place_conv(self):
        self._calc_conv()
        bet = self._conv_bet
        if bet is None or bet.size <= 0:
            self.status.emit("Nothing to place — stake is 0")
            return
        names = {r.selection_id: r.runner_name for r in self._conv_runners}
        summary = f"BACK {bet.size:,.0f} @ {bet.price:g} on {names.get(bet.selection_id, bet.selection_id)}"
        if not self._arm_btn.isChecked():
            reply = QMessageBox.question(
                self, "Confirm place bet", f"Place this bet?\n\n{summary}",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        self._emit_bets([bet])
        self.status.emit(f"Placing: {summary}…")

    # ── clear-to-odds ────────────────────────────────────────────────────────
    def _clear_inputs(self):
        sid = self._clear_sel.currentData()
        if sid is None:
            return None
        side = self._clear_side.currentText().upper()
        try:
            target = self._snap(float(self._clear_to.text()))
        except ValueError:
            return None
        try:
            add = float(self._clear_add.text()) if self._clear_add.text().strip() else 0.0
        except ValueError:
            add = 0.0
        return sid, side, target, add

    def _calc_clear(self, *_):
        self._clear_bet = None
        parsed = self._clear_inputs()
        if parsed is None:
            self._clear_size.setText("—")
            return
        sid, side, target, add = parsed
        if side == "BACK":
            sweep = sum(a for od, a in self._back_amounts(sid).items() if od >= target - 1e-9)
        else:
            sweep = sum(a for od, a in self._lay_amounts(sid).items() if od <= target + 1e-9)
        total = sweep + add
        if total <= 0:
            self._clear_size.setText("clears 0")
            return
        if self._is_line:
            self._clear_size.setText(f"sweep {sweep:,.0f} + add {add:,.0f} = {total:,.0f}")
        else:
            liab = total if side == "BACK" else total * (target - 1)
            self._clear_size.setText(
                f"sweep {sweep:,.0f} + add {add:,.0f} = {total:,.0f}  (liab {liab:,.0f})")
        self._clear_bet = BetInstruction(sid, side, target, total)

    def _fire_clear(self):
        self._calc_clear()
        bet = self._clear_bet
        if bet is None or bet.size <= 0:
            self.status.emit("Nothing to clear — size is 0")
            return
        runner = self._clear_sel.currentText()
        summary = f"{bet.side} {bet.size:,.0f} on {runner} @ {bet.price:g}"
        if not self._arm_btn.isChecked():
            reply = QMessageBox.question(
                self, "Confirm clear-to-odds", f"Place this bet?\n\n{summary}",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        self._emit_bets([bet])
        self.status.emit(f"Clearing: {summary}…")

    # ── emit ───────────────────────────────────────────────────────────────────
    def _emit_bets(self, bets: list[BetInstruction]):
        if self._market:
            self.bets_requested.emit(self._market.market_id, bets)

    def _cancel_all(self):
        if self._market:
            self.cancel_requested.emit(self._market.market_id)
            self.status.emit("Cancelling all unmatched bets…")
