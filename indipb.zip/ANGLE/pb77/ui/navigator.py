"""
Left navigation panel — single accordion tree.

Sports → Competitions → Events → Markets, all in one column.
Single click expands/collapses; clicking a market selects it.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThreadPool, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit,
    QTreeWidget, QTreeWidgetItem, QFrame,
)

from pb77.api.client import PB77Client
from pb77.api.models import Sport, Competition, Event, Market, SearchEvent
from pb77.api.sports import DEFAULT_SPORTS
from pb77.api.dummy import dummy_market
from pb77.ui.workers import Worker

ROLE_TYPE   = Qt.ItemDataRole.UserRole
ROLE_ID     = Qt.ItemDataRole.UserRole + 1
ROLE_LOADED = Qt.ItemDataRole.UserRole + 2
ROLE_DATA   = Qt.ItemDataRole.UserRole + 3

T_SPORT       = "sport"
T_COMPETITION = "competition"
T_EVENT       = "event"
T_MARKET      = "market"
T_PLACEHOLDER = "placeholder"
T_SEARCH      = "search"
T_SEEALL      = "seeall"

# Min query length before a server search fires, and the debounce delay (ms).
SEARCH_MIN_CHARS = 2
SEARCH_DEBOUNCE_MS = 350

# Colours
_C_SPORT  = QColor("#e6e8ec")
_C_COMP   = QColor("#9aa0ab")
_C_EVENT  = QColor("#c8ccd4")
_C_MARKET = QColor("#d4af37")
_C_DIM    = QColor("#646b78")

# Fonts
_F_SPORT  = QFont(); _F_SPORT.setBold(True);  _F_SPORT.setPointSize(13)
_F_COMP   = QFont(); _F_COMP.setBold(False);  _F_COMP.setPointSize(12)
_F_EVENT  = QFont(); _F_EVENT.setBold(False); _F_EVENT.setPointSize(12)
_F_MARKET = QFont(); _F_MARKET.setBold(True); _F_MARKET.setPointSize(12)
_F_DIM    = QFont(); _F_DIM.setItalic(True);  _F_DIM.setPointSize(11)


class Navigator(QWidget):
    market_selected = pyqtSignal(object)   # emits Market
    status = pyqtSignal(str)

    def __init__(
        self,
        client: PB77Client,
        pool: QThreadPool,
        sports: list[Sport] | None = None,
        parent=None,
    ):
        super().__init__(parent)
        self._client = client
        self._pool = pool
        self._sports_list = sports if sports is not None else DEFAULT_SPORTS
        self._build()
        self._populate_sports()

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header
        header = QFrame()
        header.setObjectName("Sidebar")
        hl = QVBoxLayout(header)
        hl.setContentsMargins(14, 14, 14, 10)
        hl.setSpacing(8)

        cap = QLabel("SPORTS & MARKETS")
        cap.setObjectName("SectionLabel")
        hl.addWidget(cap)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Search events, teams…")
        self._search.setClearButtonEnabled(True)
        self._search.textChanged.connect(self._on_search_text)
        self._search.returnPressed.connect(self._run_search)
        hl.addWidget(self._search)

        root.addWidget(header)

        # Server-side search: debounce keystrokes, run one query, drop stale results.
        self._search_node: QTreeWidgetItem | None = None
        self._search_seq = 0
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(SEARCH_DEBOUNCE_MS)
        self._search_timer.timeout.connect(self._run_search)

        # Tree
        self._tree = QTreeWidget()
        self._tree.setObjectName("NavTree")
        self._tree.setHeaderHidden(True)
        self._tree.setRootIsDecorated(True)
        self._tree.setIndentation(18)
        self._tree.setAnimated(True)
        self._tree.setVerticalScrollMode(QTreeWidget.ScrollMode.ScrollPerPixel)
        self._tree.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._tree.itemClicked.connect(self._on_clicked)
        self._tree.itemExpanded.connect(self._on_expand)
        root.addWidget(self._tree, stretch=1)

    # ── Populate ──────────────────────────────────────────────────────────────

    def _populate_sports(self):
        self._add_dummy_sport()
        for sport in self._sports_list:
            node = QTreeWidgetItem([f" {sport.icon}  {sport.name}"])
            node.setFont(0, _F_SPORT)
            node.setForeground(0, _C_SPORT)
            node.setData(0, ROLE_TYPE, T_SPORT)
            node.setData(0, ROLE_ID, sport.id)
            node.setData(0, ROLE_LOADED, False)
            node.setData(0, ROLE_DATA, sport)
            node.addChild(self._placeholder())
            self._tree.addTopLevelItem(node)

    def _add_dummy_sport(self):
        """A local test entry at the top: 🧪 Test → Match Odds (TEST), no network.

        Pre-populated (ROLE_LOADED=True) so expanding it never calls the API; the
        market child carries the dummy Market and selects it on click.
        """
        node = QTreeWidgetItem([" 🧪  Test Market"])
        node.setFont(0, _F_SPORT)
        node.setForeground(0, _C_MARKET)
        node.setData(0, ROLE_TYPE, T_SPORT)
        node.setData(0, ROLE_ID, "TEST")
        node.setData(0, ROLE_LOADED, True)        # already populated → no lazy load

        market = dummy_market()
        child = QTreeWidgetItem([f" {market.market_name}"])
        child.setFont(0, _F_MARKET)
        child.setForeground(0, _C_MARKET)
        child.setData(0, ROLE_TYPE, T_MARKET)
        child.setData(0, ROLE_ID, market.market_id)
        child.setData(0, ROLE_DATA, market)
        node.addChild(child)

        self._tree.addTopLevelItem(node)
        node.setExpanded(True)

    # ── Click — single click expands / collapses ──────────────────────────────

    def _on_clicked(self, item: QTreeWidgetItem, _col: int):
        ntype = item.data(0, ROLE_TYPE)
        if ntype == T_MARKET:
            market: Market = item.data(0, ROLE_DATA)
            if market:
                self.market_selected.emit(market)
                self.status.emit(f"{market.event_name}  —  {market.market_name}")
        elif ntype == T_SEEALL:
            self._load_all_markets(item)
        elif ntype != T_PLACEHOLDER:
            item.setExpanded(not item.isExpanded())

    # ── Lazy expand ───────────────────────────────────────────────────────────

    def _on_expand(self, node: QTreeWidgetItem):
        if node.data(0, ROLE_LOADED):
            return
        ntype = node.data(0, ROLE_TYPE)
        node_id = node.data(0, ROLE_ID)
        node.setData(0, ROLE_LOADED, True)
        node.takeChildren()
        node.addChild(self._loading())

        if ntype == T_SPORT:
            w = Worker(self._client.list_competitions, node_id)
            w.signals.result.connect(lambda d, n=node: self._on_competitions(n, d))
        elif ntype == T_COMPETITION:
            w = Worker(self._client.list_events, node_id)
            w.signals.result.connect(lambda d, n=node: self._on_events(n, d))
        elif ntype == T_EVENT:
            w = Worker(self._client.list_markets, node_id)
            w.signals.result.connect(lambda d, n=node: self._on_markets(n, d))
        else:
            return
        w.signals.error.connect(self._on_error)
        self._pool.start(w)

    # ── Data handlers ─────────────────────────────────────────────────────────

    def _on_competitions(self, node: QTreeWidgetItem, comps: list[Competition]):
        node.takeChildren()
        if not comps:
            node.addChild(self._empty("No competitions"))
            return
        for c in comps:
            prefix = "★  " if c.highlighted else ""
            child = QTreeWidgetItem([f" {prefix}{c.name}"])
            child.setFont(0, _F_COMP)
            child.setForeground(0, _C_COMP)
            child.setData(0, ROLE_TYPE, T_COMPETITION)
            child.setData(0, ROLE_ID, c.id)
            child.setData(0, ROLE_LOADED, False)
            child.setData(0, ROLE_DATA, c)
            child.addChild(self._placeholder())
            node.addChild(child)
        self.status.emit(f"{len(comps)} competitions")

    def _on_events(self, node: QTreeWidgetItem, events: list[Event]):
        node.takeChildren()
        if not events:
            node.addChild(self._empty("No open events"))
            return
        for e in events:
            start = e.start_time.strftime("%d %b %H:%M") if e.start_time else ""
            label = f" {e.name}" + (f"  ·  {start}" if start else "")
            child = QTreeWidgetItem([label])
            child.setFont(0, _F_EVENT)
            child.setForeground(0, _C_EVENT)
            child.setData(0, ROLE_TYPE, T_EVENT)
            child.setData(0, ROLE_ID, e.id)
            child.setData(0, ROLE_LOADED, False)
            child.setData(0, ROLE_DATA, e)
            child.addChild(self._placeholder())
            node.addChild(child)

    def _on_markets(self, node: QTreeWidgetItem, markets: list[Market]):
        node.takeChildren()
        if not markets:
            node.addChild(self._empty("No markets"))
            return
        for m in markets:
            node.addChild(self._market_item(m))

    def _market_item(self, m: Market) -> QTreeWidgetItem:
        """A selectable market leaf row."""
        child = QTreeWidgetItem([f" {m.market_name}"])
        child.setFont(0, _F_MARKET)
        child.setForeground(0, _C_MARKET)
        child.setData(0, ROLE_TYPE, T_MARKET)
        child.setData(0, ROLE_ID, m.market_id)
        child.setData(0, ROLE_DATA, m)
        return child

    # ── Search (server-side: /customer/api/event/search) ──────────────────────

    def _on_search_text(self, text: str):
        """Debounce typing; an empty box drops back to the normal sports tree."""
        if text.strip():
            self._search_timer.start()
        else:
            self._search_timer.stop()
            self._clear_search()

    def _run_search(self):
        query = self._search.text().strip()
        if len(query) < SEARCH_MIN_CHARS:
            self._clear_search()
            return
        self._search_seq += 1
        seq = self._search_seq
        self._enter_search_mode()
        self._search_node.takeChildren()
        self._search_node.addChild(self._loading())
        self._search_node.setExpanded(True)

        w = Worker(self._client.search_events, query)
        w.signals.result.connect(lambda res, s=seq: self._on_search_results(s, res))
        w.signals.error.connect(lambda msg, s=seq: self._on_search_error(s, msg))
        self._pool.start(w)

    def _enter_search_mode(self):
        """Hide the normal sport nodes and show a single search-results container."""
        for i in range(self._tree.topLevelItemCount()):
            item = self._tree.topLevelItem(i)
            if item is not self._search_node:
                item.setHidden(True)
        if self._search_node is None:
            node = QTreeWidgetItem([" 🔍  Search results"])
            node.setFont(0, _F_SPORT)
            node.setForeground(0, _C_MARKET)
            node.setData(0, ROLE_TYPE, T_SEARCH)
            node.setData(0, ROLE_LOADED, True)   # children come from the search call
            self._tree.insertTopLevelItem(0, node)
            self._search_node = node
        else:
            self._search_node.setHidden(False)

    def _clear_search(self):
        """Remove the search container and restore the normal sports tree."""
        self._search_timer.stop()
        self._search_seq += 1                    # invalidate any in-flight query
        if self._search_node is not None:
            idx = self._tree.indexOfTopLevelItem(self._search_node)
            if idx >= 0:
                self._tree.takeTopLevelItem(idx)
            self._search_node = None
        for i in range(self._tree.topLevelItemCount()):
            self._tree.topLevelItem(i).setHidden(False)

    def _on_search_results(self, seq: int, events: list[SearchEvent]):
        if seq != self._search_seq or self._search_node is None:
            return                               # superseded by a newer search
        self._search_node.takeChildren()
        if not events:
            self._search_node.addChild(self._empty("No matches"))
            return
        for ev in events:
            self._search_node.addChild(self._make_search_event(ev))
        self._search_node.setExpanded(True)
        self.status.emit(f"{len(events)} result(s) for “{self._search.text().strip()}”")

    def _on_search_error(self, seq: int, msg: str):
        if seq != self._search_seq or self._search_node is None:
            return
        self._search_node.takeChildren()
        self._search_node.addChild(self._empty("Search failed"))
        self.status.emit(f"⚠  {msg}")

    def _make_search_event(self, ev: SearchEvent) -> QTreeWidgetItem:
        """An event row whose markets (from the search response) are pre-loaded."""
        start = ev.start_time.strftime("%d %b %H:%M") if ev.start_time else ""
        live = "🔴 " if ev.in_play else ""
        bits = [b for b in (ev.sport_name, start) if b]
        suffix = ("  ·  " + "  ·  ".join(bits)) if bits else ""
        node = QTreeWidgetItem([f" {live}{ev.name}{suffix}"])
        node.setFont(0, _F_EVENT)
        node.setForeground(0, _C_EVENT)
        node.setData(0, ROLE_TYPE, T_EVENT)
        node.setData(0, ROLE_ID, ev.id)
        node.setData(0, ROLE_LOADED, True)       # markets embedded → no lazy fetch
        node.setData(0, ROLE_DATA, ev)
        if not ev.markets:
            node.addChild(self._empty("No markets"))
            return node
        for m in ev.markets:
            node.addChild(self._market_item(m))
        if ev.see_all_markets:
            node.addChild(self._see_all_item(ev.id))
        return node

    def _see_all_item(self, event_id: str) -> QTreeWidgetItem:
        """A clickable row that swaps the event's top markets for its full set."""
        it = QTreeWidgetItem([" ⋯  See all markets"])
        it.setFont(0, _F_COMP)
        it.setForeground(0, _C_MARKET)
        it.setData(0, ROLE_TYPE, T_SEEALL)
        it.setData(0, ROLE_ID, event_id)
        return it

    def _load_all_markets(self, more_item: QTreeWidgetItem):
        """Replace an event's top markets with its full set (/event/details/{id})."""
        event_node = more_item.parent()
        if event_node is None:
            return
        event_id = more_item.data(0, ROLE_ID)
        event_node.takeChildren()            # drop the top markets + the "See all" row
        event_node.addChild(self._loading())
        event_node.setExpanded(True)
        w = Worker(self._client.list_markets, event_id)
        w.signals.result.connect(lambda mkts, n=event_node: self._on_all_markets(n, mkts))
        w.signals.error.connect(self._on_error)
        self._pool.start(w)

    def _on_all_markets(self, event_node: QTreeWidgetItem, markets: list[Market]):
        event_node.takeChildren()
        if not markets:
            event_node.addChild(self._empty("No markets"))
            return
        for m in markets:
            event_node.addChild(self._market_item(m))
        event_node.setExpanded(True)
        self.status.emit(f"{len(markets)} markets")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _placeholder(self) -> QTreeWidgetItem:
        it = QTreeWidgetItem([""])
        it.setData(0, ROLE_TYPE, T_PLACEHOLDER)
        return it

    def _loading(self) -> QTreeWidgetItem:
        it = QTreeWidgetItem([" Loading…"])
        it.setFont(0, _F_DIM)
        it.setForeground(0, _C_DIM)
        it.setData(0, ROLE_TYPE, T_PLACEHOLDER)
        return it

    def _empty(self, msg: str) -> QTreeWidgetItem:
        it = QTreeWidgetItem([f" {msg}"])
        it.setFont(0, _F_DIM)
        it.setForeground(0, _C_DIM)
        it.setData(0, ROLE_TYPE, T_PLACEHOLDER)
        return it

    def _on_error(self, msg: str):
        self.status.emit(f"⚠  {msg}")
