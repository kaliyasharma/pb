"""Main trading window — opened after successful login."""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThreadPool, QTimer, QObject, pyqtSignal
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QSplitter, QStatusBar, QStackedWidget,
)

from pb77.api.client import PB77Client
from pb77.api.models import (
    Session, Market, BetInstruction, BetResult, CashOutQuote, CashOutResult,
    PlacedOffer,
)
from pb77.api.prices import MarketBook
from pb77.api.stream import PriceStream
from pb77.api.sports import sports_from_ids, DEFAULT_SPORTS
from pb77.api import dummy
from pb77.ui.navigator import Navigator
from pb77.ui.market_grid import MarketGrid
from pb77.ui.ladder_view import LadderView
from pb77.ui.log_window import LogWindow
from pb77.ui.bets_panel import BetsPanel
from pb77.ui.toast import ToastManager
from pb77.ui.workers import Worker

# Minimum stake the exchange accepts (per the site's client-side validation).
# Below this, the bet is rejected locally without a request.
MIN_STAKE = 225.0

# Friendly text for the exchange's raw error codes (shown in toasts/status bar).
_ERROR_MESSAGES = {
    "WALLET_NOT_ENOUGH_MONEY_EXCEPTION": "Not enough money in your wallet",
    "INSUFFICIENT_FUNDS": "Not enough money in your wallet",
    "BET_TAKEN_OR_LAPSED": "Bet no longer available — odds changed",
    "BET_LAPSED_PRICE_IMPROVEMENT": "Bet lapsed — the price moved",
    "MARKET_SUSPENDED": "Market is suspended",
    "MARKET_NOT_OPEN_FOR_BETTING": "Market is closed for betting",
    "INVALID_ODDS": "Those odds aren't valid",
    "INVALID_BET_SIZE": "That stake isn't valid",
    "MIN_BET_SIZE": "Stake is below the minimum allowed",
    "INSUFFICIENT_LIQUIDITY": "Not enough liquidity to match",
    "EXPOSURE_LIMIT_EXCEEDED": "Exposure limit reached",
    "RUNNER_REMOVED": "That selection was removed",
    "BET_ACTION_ERROR": "Couldn't place the bet — please try again",
    "TIME_OUT": "Request timed out — please try again",
    "NO_CSRF": "Session problem — please log in again",
}


def _friendly_error(code: str) -> str:
    """Turn a raw exchange error code into a readable message."""
    if not code:
        return "Bet rejected"
    key = code.strip().upper()
    if key in _ERROR_MESSAGES:
        return _ERROR_MESSAGES[key]
    if " " in code:                 # already a human sentence — leave it
        return code
    pretty = (key.replace("_EXCEPTION", "").replace("_ERROR", "")
                 .replace("_", " ").strip().capitalize())
    return pretty or code


class _StreamBridge(QObject):
    """Marshals stream-thread callbacks onto the Qt main thread (queued signals)."""
    message      = pyqtSignal(dict)
    status       = pyqtSignal(str)
    graph        = pyqtSignal(object)
    balance      = pyqtSignal(float)
    open_bets    = pyqtSignal(int)
    current_bets = pyqtSignal(object)
    cashout      = pyqtSignal(object)
    bet_status   = pyqtSignal(object)


class MainWindow(QMainWindow):
    def __init__(self, client: PB77Client, session: Session):
        super().__init__()
        self._client = client
        self._session = session
        self._pool = QThreadPool.globalInstance()
        self._bridge = _StreamBridge()
        self._bridge.message.connect(self._on_stream_message)
        self._bridge.graph.connect(self._on_graph)
        self._bridge.balance.connect(self._on_balance_update)
        self._bridge.open_bets.connect(self._on_open_bets_update)
        self._bridge.current_bets.connect(self._on_current_bets_update)
        self._bridge.cashout.connect(self._on_cashout_quote)
        self._bridge.bet_status.connect(self._on_bet_status)

        # True once the user manually logs out (or the session expires) — tells
        # app.main() to return to the login screen instead of quitting.
        self.logged_out = False

        self._current_market: Market | None = None
        self._book: MarketBook | None = None
        # Local test-market simulation (no network): jitter timer + fake open bets.
        self._dummy_timer: QTimer | None = None
        self._dummy_bets: list[dict] = []
        # selection_id -> {price: total_traded_volume} (derived, shown on ladder)
        self._traded: dict[int, dict[float, float]] = {}
        # selection_id -> {(price, timestamp): volume} — raw buckets the totals derive from.
        # READY frames rebuild these; UPDATED frames revise individual buckets.
        self._buckets: dict[int, dict[tuple, float]] = {}
        # Latest CURRENT_BETS snapshot — used to classify a placed bet matched/unmatched.
        self._last_current_bets: list[dict] = []
        # offer_id -> (title_html, amount) for active bet toasts.
        self._bet_toasts: dict[int, tuple[str, str]] = {}

        self.setWindowTitle("PB77 Terminal")
        self.setMinimumSize(1220, 780)
        self.resize(1520, 900)

        # Debug log window — streams all logging (WS traffic, bet requests, …).
        self._log_window = LogWindow(self)
        import logging as _logging
        root = _logging.getLogger()
        root.setLevel(_logging.INFO)
        root.addHandler(self._log_window.handler)

        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._bridge.status.connect(lambda s: self._status.showMessage(s, 4000))

        self.setCentralWidget(self._build_page())

        # Bet-placement toast popups (overlay the top of the window).
        self._toasts = ToastManager(self)

        # Start price stream
        self._stream = PriceStream(
            cookie_header=self._client.cookie_header(),
            on_message=self._bridge.message.emit,
            on_status=self._bridge.status.emit,
            on_graph=self._bridge.graph.emit,
            on_balance=self._bridge.balance.emit,
            on_open_bets=self._bridge.open_bets.emit,
            on_current_bets=self._bridge.current_bets.emit,
            on_cashout=self._bridge.cashout.emit,
            on_bet_status=self._bridge.bet_status.emit,
        )
        self._stream.connect()   # open general socket immediately → BALANCE subscribe

        self._status.showMessage(
            f"Connected as {session.nickname}  ({session.currency_code})"
        )

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._check_session)
        self._timer.start(30_000)

    # ── Layout ────────────────────────────────────────────────────────────────

    def _build_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self._build_topbar())

        splitter = QSplitter(Qt.Orientation.Horizontal)

        cfg = self._client.platform_config
        sports = sports_from_ids(cfg.nav_sport_ids) if cfg else DEFAULT_SPORTS
        self._navigator = Navigator(self._client, self._pool, sports=sports)
        self._navigator.market_selected.connect(self._on_market_selected)
        self._navigator.status.connect(self._status.showMessage)
        splitter.addWidget(self._navigator)

        # Center: grid ⇄ ladder, switchable via a view toggle
        center = QFrame()
        center.setObjectName("Panel")
        cl = QVBoxLayout(center)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(0)
        cl.addWidget(self._build_view_toggle())

        self._stack = QStackedWidget()
        self._grid = MarketGrid()
        self._grid.bets_requested.connect(self._place_bets)
        self._grid.cancel_requested.connect(self._cancel_all)
        self._grid.cash_out_requested.connect(self._cash_out)
        self._grid.status.connect(lambda s: self._status.showMessage(s, 4000))
        self._ladder = LadderView()
        self._ladder.bets_requested.connect(self._place_bets)
        self._ladder.cancel_requested.connect(self._cancel_all)
        self._ladder.cash_out_requested.connect(self._cash_out)
        self._ladder.status.connect(lambda s: self._status.showMessage(s, 4000))
        self._stack.addWidget(self._grid)     # index 0
        self._stack.addWidget(self._ladder)   # index 1
        cl.addWidget(self._stack, stretch=1)
        splitter.addWidget(center)

        self._bets_panel = BetsPanel()
        self._bets_panel.setMinimumWidth(0)
        self._bets_panel.cancel_all_requested.connect(self._cancel_all)
        self._bets_panel.cancel_bet_requested.connect(self._cancel_bet)
        self._bets_panel.open_market_requested.connect(self._open_market_from_bet)
        self._bets_panel.close_requested.connect(self._show_bets)
        splitter.addWidget(self._bets_panel)
        self._main_splitter = splitter

        splitter.setSizes([300, 1220, 0])
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 0)
        layout.addWidget(splitter, stretch=1)
        return page

    def _build_view_toggle(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("ViewToggle")
        h = QHBoxLayout(bar)
        h.setContentsMargins(14, 8, 14, 8)
        h.setSpacing(6)

        self._btn_grid = QPushButton("Grid")
        self._btn_grid.setObjectName("Segment")
        self._btn_grid.setCheckable(True)
        self._btn_grid.setChecked(True)
        self._btn_grid.clicked.connect(lambda: self._show_view(0))

        self._btn_ladder = QPushButton("⛏ Ladder")
        self._btn_ladder.setObjectName("Segment")
        self._btn_ladder.setCheckable(True)
        self._btn_ladder.clicked.connect(lambda: self._show_view(1))

        h.addWidget(self._btn_grid)
        h.addWidget(self._btn_ladder)
        h.addStretch()
        return bar

    def _show_view(self, index: int):
        self._stack.setCurrentIndex(index)
        self._btn_grid.setChecked(index == 0)
        self._btn_ladder.setChecked(index == 1)
        if index == 1 and self._current_market:
            # Opening the ladder = the site's "open graph" action → (re)subscribe now,
            # after price data is flowing (the server seems to ignore it at connect-time).
            self._stream.request_graphs()

    def _build_topbar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("TopBar")
        bar.setFixedHeight(58)
        l = QHBoxLayout(bar)
        l.setContentsMargins(20, 0, 20, 0)

        brand = QLabel("PB77")
        brand.setObjectName("Brand")
        l.addWidget(brand)
        tag = QLabel("TERMINAL")
        tag.setObjectName("Badge")
        l.addWidget(tag)
        l.addStretch()

        s = self._session
        self._bal_label = QLabel(f"{s.currency_symbol}{s.balance:,.2f}")
        self._bal_label.setObjectName("BalancePill")
        l.addWidget(self._bal_label)

        self._bets_btn = QPushButton("Bets: —")
        self._bets_btn.setObjectName("BalancePill")
        self._bets_btn.setFlat(True)
        self._bets_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._bets_btn.clicked.connect(self._show_bets)
        l.addWidget(self._bets_btn)

        name = QLabel(f"  {s.nickname}")
        name.setObjectName("AccountName")
        l.addWidget(name)

        log_btn = QPushButton("Log")
        log_btn.setObjectName("Ghost")
        log_btn.clicked.connect(self._show_log)
        l.addWidget(log_btn)

        logout = QPushButton("Logout")
        logout.setObjectName("Ghost")
        logout.clicked.connect(self._logout)
        l.addWidget(logout)
        return bar

    def _on_balance_update(self, balance: float):
        s = self._session
        self._bal_label.setText(f"{s.currency_symbol}{balance:,.2f}")

    def _on_open_bets_update(self, count: int):
        self._bets_btn.setText(f"Bets: {count}")
        self._bets_panel.set_count(count)

    def _on_current_bets_update(self, bets: list):
        self._last_current_bets = bets or []
        self._bets_panel.update_bets(bets)
        # Refine any open bet toasts now that we know matched/unmatched.
        for offer_id in list(self._bet_toasts):
            state = self._classify_offer(offer_id)
            if state:
                self._toasts.update_state(offer_id, state)

    # ── Cash out ──────────────────────────────────────────────────────────────

    def _on_cashout_quote(self, quotes):
        """A CASH_OUT_QUOTE frame (list of per-market quotes) arrived on the stream."""
        if not self._current_market or not isinstance(quotes, list):
            return
        for raw in quotes:
            if not isinstance(raw, dict):
                continue
            if str(raw.get("marketId", "")) != self._current_market.market_id:
                continue
            quote = CashOutQuote.from_json(raw)
            self._grid.apply_cashout_quote(quote)
            self._ladder.apply_cashout_quote(quote)
            break

    def _cash_out(self, market_id: str, profit: float, quote: float):
        """Fire POST /cashout off the UI thread, then poll status to completion."""
        if dummy.is_dummy(market_id):
            self._status.showMessage("🧪 Cash out is disabled on the test market", 4000)
            return
        self._grid.set_cashout_pending()
        self._ladder.set_cashout_pending()
        self._status.showMessage("Cashing out…", 4000)
        w = Worker(self._client.cash_out, market_id, profit, quote)
        w.signals.result.connect(self._on_cashout_result)
        w.signals.error.connect(self._on_cashout_error)
        self._pool.start(w)

    def _on_cashout_result(self, result: CashOutResult):
        msg = (f"✓ Cashed out  (P/L {result.profit:+,.2f})" if result.success
               else f"⚠ Cash out {result.status}: {result.message}".strip())
        self._grid.notify_cashout_result(result.success, msg if result.success else result.status)
        self._ladder.notify_cashout_result(result.success, msg if result.success else result.status)
        self._status.showMessage(msg, 6000)

    def _on_cashout_error(self, err: str):
        self._grid.notify_cashout_result(False, "error")
        self._ladder.notify_cashout_result(False, "error")
        self._status.showMessage(f"⚠ Cash out failed: {err}", 6000)

    def _show_bets(self):
        sizes = self._main_splitter.sizes()  # [nav, center, bets]
        if sizes[2] > 0:
            # collapse: give space back to center
            self._main_splitter.setSizes([sizes[0], sizes[1] + sizes[2], 0])
        else:
            # expand: take 310px from center
            panel_w = 310
            self._main_splitter.setSizes([sizes[0], max(sizes[1] - panel_w, 200), panel_w])

    def _show_log(self):
        self._log_window.show()
        self._log_window.raise_()
        self._log_window.activateWindow()

    # ── Open a bet's market from the bets panel (double-click) ────────────────

    def _open_market_from_bet(self, bet: dict):
        market_id = str(bet.get("marketId", "") or "")
        if not market_id:
            self._status.showMessage("This bet has no market to open", 4000)
            return
        self._status.showMessage(f"Opening {bet.get('eventName') or 'market'}…", 3000)
        w = Worker(self._client.market_for_bet, bet)
        w.signals.result.connect(self._on_bet_market_loaded)
        w.signals.error.connect(
            lambda e: self._status.showMessage(f"⚠ Could not open market: {e}", 6000))
        self._pool.start(w)

    def _on_bet_market_loaded(self, market: Market):
        self._on_market_selected(market)
        self._show_view(0)        # surface the grid so the opened market is visible

    # ── Market selection + live prices ────────────────────────────────────────

    def _on_market_selected(self, market: Market):
        self._current_market = market
        self._book = MarketBook(market_id=market.market_id)
        self._traded = {}
        self._buckets = {}
        self._grid.set_market(market)
        self._ladder.set_market(market)

        if dummy.is_dummy(market.market_id):
            self._stream.set_cashout_market(None)   # no cash out on the test market
            self._start_dummy()
            return
        self._stop_dummy()
        # Ladder is capped at MAX_LADDERS columns — only subscribe graphs for those.
        ladder_sels = [r.selection_id for r in market.runners[:LadderView.MAX_LADDERS]]
        self._stream.set_market(market.market_id, market.event_id, ladder_sels)
        self._stream.set_cashout_market(market.market_id)
        self._status.showMessage(
            f"Streaming {market.event_name} — {market.market_name}…"
        )

    # ── Dummy/test market (local simulation, no network) ──────────────────────
    def _start_dummy(self):
        self._dummy_bets = []
        self._bets_panel.update_bets([])
        self._on_open_bets_update(0)
        if self._dummy_timer is None:
            self._dummy_timer = QTimer(self)
            self._dummy_timer.timeout.connect(self._tick_dummy)
        self._dummy_timer.start(1000)
        self._tick_dummy()
        self._status.showMessage(
            "🧪 DUMMY market — local test mode (bets simulated, nothing sent to pb77)"
        )

    def _stop_dummy(self):
        if self._dummy_timer is not None:
            self._dummy_timer.stop()

    def _tick_dummy(self):
        book = dummy.dummy_book(live=True)
        self._book = book
        self._grid.apply_book(book)
        self._ladder.apply_book(book)

    def _simulate_dummy_bets(self, bets: list[BetInstruction]):
        for b in bets:
            self._dummy_bets.append(dummy.simulated_bet(b))
        self._bets_panel.update_bets(self._dummy_bets)
        self._on_open_bets_update(len(self._dummy_bets))
        msg = ", ".join(f"{b.side} {b.size:g}@{b.price:g}" for b in bets)
        self._status.showMessage(f"🧪 SIM matched: {msg}", 5000)

    def _on_graph(self, payload):
        """
        MARKET_GRAPHS feed → traded volume per (selection, price).

        The feed keys data by (price, timestamp) buckets whose volume the server revises
        (a bucket can grow across frames — see the same price+timestamp arriving twice with
        a larger volume). So we keep raw buckets per selection (last value wins per bucket)
        and derive the per-price total as the sum across timestamps.

          • status READY  → full snapshot: clear that selection's buckets, then load.
          • status UPDATED → delta: revise just the buckets in the frame.
        """
        points, status = payload
        if not self._current_market or not points:
            return
        only = self._current_market.runners[0].selection_id \
            if len(self._current_market.runners) == 1 else None

        # Group this frame's buckets by selection (last write wins per (price, ts)).
        frame: dict[int, dict[tuple, float]] = {}
        for sel, value, volume, ts in points:
            sid = int(sel) if sel is not None else only
            if sid is None:
                continue
            frame.setdefault(sid, {})[(round(value, 2), ts)] = volume

        for sid, buckets in frame.items():
            store = self._buckets.setdefault(sid, {})
            if status == "READY":
                store.clear()                 # full snapshot rebuild
            store.update(buckets)             # revise/insert this frame's buckets
            totals: dict[float, float] = {}
            for (price, _ts), vol in store.items():
                totals[price] = totals.get(price, 0.0) + vol
            self._traded[sid] = totals

        if frame:
            import logging
            cols = {c.selection_id for c in self._ladder._columns}
            logging.getLogger("pb77.ui").info(
                "TRADED applied: %s | ladder cols=%s",
                {sid: len(t) for sid, t in self._traded.items()}, cols)
            self._ladder.apply_traded(self._traded)

    def _on_stream_message(self, msg: dict):
        if not self._current_market or msg.get("id") != self._current_market.market_id:
            return
        if self._book is None:
            self._book = MarketBook(market_id=self._current_market.market_id)
        self._book.apply(msg)
        self._grid.apply_book(self._book)
        self._ladder.apply_book(self._book)
        # Extract traded volume from the price stream (trd field) and push to ladder.
        new_traded: dict[int, dict[float, float]] = {
            sid: dict(runner.traded)
            for sid, runner in self._book.runners.items()
            if runner.traded
        }
        if new_traded:
            self._traded.update(new_traded)
            self._ladder.apply_traded(self._traded)

    # ── Bet placement (off the UI thread) ─────────────────────────────────────

    def _place_bets(self, market_id: str, bets: list[BetInstruction]):
        if dummy.is_dummy(market_id):
            self._simulate_dummy_bets(bets)
            return
        # Client-side guard: the exchange rejects stakes below the minimum, so
        # catch it here (no request) and surface it the way the site does.
        if any(b.size < MIN_STAKE for b in bets):
            msg = f"The stake(s) you have entered are below the minimum allowed: {MIN_STAKE:.2f}"
            self._toasts.error(msg)
            self._status.showMessage(f"⚠ {msg}", 6000)
            return
        w = Worker(self._client.place_bets, market_id, bets)
        w.signals.result.connect(self._on_bet_result)
        w.signals.error.connect(lambda e: self._status.showMessage(f"⚠ Bet failed: {e}", 6000))
        self._pool.start(w)

    def _cancel_all(self, market_id: str):
        if dummy.is_dummy(market_id):
            self._dummy_bets = []
            self._bets_panel.update_bets([])
            self._on_open_bets_update(0)
            self._status.showMessage("🧪 SIM: all bets cleared", 4000)
            return
        w = Worker(self._client.cancel_all_bets, market_id)
        w.signals.result.connect(self._on_bet_result)
        w.signals.error.connect(lambda e: self._status.showMessage(f"⚠ Cancel failed: {e}", 6000))
        self._pool.start(w)

    def _cancel_bet(self, bet: dict):
        offer_id = bet.get("offerId", "?")
        self._status.showMessage(f"Cancelling bet #{offer_id}…", 3000)
        w = Worker(self._client.cancel_bet, bet)
        w.signals.result.connect(self._on_bet_result)
        w.signals.error.connect(lambda e: self._status.showMessage(f"⚠ Cancel failed: {e}", 6000))
        self._pool.start(w)

    def _on_bet_result(self, result: BetResult):
        if not result.success:
            msg = _friendly_error(result.message or result.status)
            self._toasts.error(msg)
            self._status.showMessage(f"⚠ {msg}", 7000)
            return

        # A placeBets success carries the accepted offers — show a live toast per
        # offer and subscribe to BET_STATUSES so it updates Placing → Placed/….
        if result.offers:
            for offer in result.offers:
                title, amount = self._toast_text(offer)
                self._bet_toasts[offer.offer_id] = (title, amount)
                self._toasts.show_bet(offer.offer_id, title, amount, "PENDING")
            self._stream.subscribe_bet_statuses([o.offer_id for o in result.offers])
            self._status.showMessage("Placing bet…", 3000)
        else:
            # No offers (e.g. a cancel) — just acknowledge in the status bar.
            self._status.showMessage(f"✓ {result.status} {result.message}".strip(), 5000)

    def _on_bet_status(self, statuses: dict):
        """BET_STATUSES frame: {"<offerId>": {"state": "PENDING"|"PLACED"|…}}."""
        if not isinstance(statuses, dict):
            return
        for raw_id, info in statuses.items():
            try:
                offer_id = int(raw_id)
            except (TypeError, ValueError):
                continue
            if offer_id not in self._bet_toasts:
                continue
            state = str((info or {}).get("state", "")).upper()
            # On PLACED, refine to matched/unmatched from the current-bets snapshot.
            if state == "PLACED":
                state = self._classify_offer(offer_id) or "PLACED"
            self._toasts.update_state(offer_id, state)
            if state in ("PLACED", "MATCHED", "UNMATCHED", "PARTIAL",
                         "LAPSED", "CANCELLED", "EXPIRED", "FAILED"):
                self._bet_toasts.pop(offer_id, None)
                self._stream.drop_bet_statuses([offer_id])

    def _classify_offer(self, offer_id: int) -> str | None:
        """matched / unmatched / partial for an offer, from the latest CURRENT_BETS."""
        for b in self._last_current_bets:
            if str(b.get("offerId")) != str(offer_id):
                continue
            matched = float(b.get("sizeMatched") or 0)
            remaining = float(b.get("sizeRemaining") or 0)
            if matched > 0 and remaining > 0:
                return "PARTIAL"
            if matched > 0:
                return "MATCHED"
            if remaining > 0:
                return "UNMATCHED"
            return "PLACED"
        return None

    def _toast_text(self, offer: PlacedOffer) -> tuple[str, str]:
        """(title_html, amount) describing a placed offer, like the site's toast."""
        verb = "Bet Against" if offer.side.upper() == "LAY" else "Bet For"
        side = offer.side.title()
        runner = self._runner_name(offer.selection_id)
        market = self._current_market.market_name if self._current_market else ""
        tail = f" – {market}" if market else ""
        title = f"{side} ({verb}): <b>{runner}</b>{tail}"
        return title, f"{offer.size:,.2f} @{offer.price:g}"

    def _runner_name(self, selection_id: int) -> str:
        if self._current_market:
            for r in self._current_market.runners:
                if r.selection_id == selection_id:
                    return r.runner_name
        return str(selection_id)

    # ── Session ───────────────────────────────────────────────────────────────

    def _check_session(self):
        remaining = self._session.seconds_remaining
        if remaining <= 0:
            self._status.showMessage("Session expired — please log in again")
            self._logout()
        elif remaining < 600:
            self._status.showMessage(
                f"Session expires in ~{int(remaining // 60)} min"
            )

    def _logout(self):
        self.logged_out = True
        self._timer.stop()
        if self._stream:
            self._stream.stop()
        self._client.logout()
        self.close()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, "_toasts", None) is not None:
            self._toasts.reposition()

    def closeEvent(self, event):
        self._timer.stop()
        self._stop_dummy()
        if self._stream:
            self._stream.stop()
        import logging as _logging
        _logging.getLogger().removeHandler(self._log_window.handler)
        self._log_window.close()
        self._bets_panel.hide()
        self._client.close()
        event.accept()
