"""
Full price ladder view — one scrollable 1.01→1000 ladder per selection.

Generalises laddercal.py (which was hard-wired to 2 slots) to render a ladder
column for *every* runner in the market. Columns scroll in sync.

Features ported from the prototype:
  • click a back/lay cell → place a bet at that price with the selected stake
  • Multi mode: click cells to queue bets, then "Fire" places them together
  • Cancel All unmatched bets on the market
  • Liquidity calculator: sum available back/lay over a price range per selection

Live amounts come from the same MarketBook the grid uses (catb/catl best levels).
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor, QFont
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFrame, QComboBox, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QSizePolicy, QStyledItemDelegate, QMessageBox,
)

from pb77.api.models import Market, BetInstruction, CashOutQuote
from pb77.api.prices import MarketBook, RunnerBook
from pb77.api.ladder import (
    LADDER_ODDS, fmt_amount, fmt_amount_full, fmt_odds, snap_odd, opposite_odds,
    line_ladder,
)
from pb77.ui.theme import Palette
from pb77.ui.cashout_bar import CashOutBar

DEFAULT_STAKES = [100, 200, 300, 500, 750, 1000, 1500, 2000]
# Stake used for a one-click bet from the grid view (the ladder uses its own selector)
_DEFAULT_STAKE = DEFAULT_STAKES[0]

ROW_H = 22
# Bet Angel layout, left → right:
#   own back bets | available-to-back | ODDS | available-to-lay | traded volume
COL_BACKBET, COL_BACK, COL_ODDS, COL_LAY, COL_VOL = 0, 1, 2, 3, 4

# Bet Angel-style light cells
_BACK_EMPTY  = QColor("#90CAF9")   # blue column (same whether empty or filled)
_BACK_FILLED = QColor("#90CAF9")
_LAY_EMPTY   = QColor("#ffd6e3")   # pink column (same whether empty or filled)
_LAY_FILLED  = QColor("#ffd6e3")
_ODDS_BG     = QColor("#ededed")   # grey rung
_ODDS_BAND   = QColor("#6f9fe0")   # blue active (spread) band
_BET_BG      = QColor("#ffffff")
_VOL_EMPTY   = QColor("#ffffff")
_VOL_HOT     = QColor("#f4b860")   # orange (traded)
_QUEUE_BG    = QColor("#ff9800")

_AMT_FG       = QColor("#10151b")  # near-black on the light cells
_BET_FG       = QColor("#2e7d32")  # green own-bets text
_ODDS_FG      = QColor("#10151b")
_ODDS_BAND_FG = QColor("#ffffff")
_VOL_FG       = QColor("#5a3d10")
_QUEUE_FG     = QColor("#1a1207")


class _CellDelegate(QStyledItemDelegate):
    """Paint cells directly from item data roles, bypassing the global stylesheet.

    Qt's stylesheet-based item renderer ignores QTableWidgetItem.setBackground()
    whenever any ::item CSS rule exists (even without a background property).
    This delegate skips super().paint() and renders background + text manually,
    so our per-cell colour assignments always take effect.
    """
    _WHITE = QColor("#ffffff")
    _DARK  = QColor("#10151b")

    def paint(self, painter, option, index):
        rect = option.rect
        bg = index.data(Qt.ItemDataRole.BackgroundRole)
        if isinstance(bg, QBrush):
            painter.fillRect(rect, bg)
        elif isinstance(bg, QColor):
            painter.fillRect(rect, bg)
        else:
            painter.fillRect(rect, self._WHITE)

        fnt = index.data(Qt.ItemDataRole.FontRole)
        if fnt:
            painter.setFont(fnt)

        fg = index.data(Qt.ItemDataRole.ForegroundRole)
        if isinstance(fg, QBrush):
            painter.setPen(fg.color())
        elif isinstance(fg, QColor):
            painter.setPen(fg)
        else:
            painter.setPen(self._DARK)

        text = index.data(Qt.ItemDataRole.DisplayRole)
        if text:
            align = index.data(Qt.ItemDataRole.TextAlignmentRole)
            flags = int(align) if align is not None else int(
                Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignHCenter)
            painter.drawText(rect.adjusted(2, 0, -2, 0), flags, str(text))


def _lerp(a: QColor, b: QColor, t: float) -> QColor:
    t = 0.0 if t < 0 else 1.0 if t > 1 else t
    return QColor(
        int(a.red()   + (b.red()   - a.red())   * t),
        int(a.green() + (b.green() - a.green()) * t),
        int(a.blue()  + (b.blue()  - a.blue())  * t),
    )


class LadderColumn(QTableWidget):
    """One selection's full ladder, Bet Angel style:
    [own back | available-back | Odds | available-lay | traded volume]."""
    cell_clicked = pyqtSignal(int, str, float)   # selection_id, side, odds

    def __init__(self, selection_id: int, name: str, parent=None,
                 ladder: list[float] | None = None, line: bool = False):
        # Odds markets use the standard 1.01→1000 ladder; LINE markets pass a
        # custom line ladder (e.g. 999.5 … 0.5).
        self._ladder: list[float] = ladder if ladder is not None else LADDER_ODDS
        # Run-line markets flip the convention: Back side = "NO" (pink),
        # Lay side = "YES" (blue). Odds markets keep Back=blue / Lay=pink.
        self._line = line
        self._back_bg = _LAY_EMPTY  if line else _BACK_EMPTY   # NO=pink / Back=blue
        self._lay_bg  = _BACK_EMPTY if line else _LAY_EMPTY    # YES=blue / Lay=pink
        super().__init__(len(self._ladder), 5, parent)
        self.selection_id = selection_id
        self.runner_name = name

        self._row_of: dict[float, int] = {od: i for i, od in enumerate(self._ladder)}
        self._filled_back: set[int] = set()
        self._filled_lay: set[int] = set()
        # raw available amounts (odds -> amount), source of truth for liquidity calc
        self.back_amt: dict[float, float] = {}
        self.lay_amt: dict[float, float] = {}
        # queued bets on this column: (side, odds) -> stake
        self._queued: dict[tuple[str, float], float] = {}
        # odds carrying a traded shade / the blue active band rows
        self._heated: set[float] = set()
        self._band: set[int] = set()

        self._build()

    # ── build ──────────────────────────────────────────────────────────────
    def _build(self):
        self.setObjectName("Ladder")
        self.horizontalHeader().setVisible(False)
        self.verticalHeader().setVisible(False)
        self.setShowGrid(True)
        self.setGridStyle(Qt.PenStyle.SolidLine)
        self.setStyleSheet("QTableWidget { gridline-color: #d4d4d4; }")
        self.setItemDelegate(_CellDelegate(self))
        self.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        # Each ladder scrolls on its own — independent scrollbar per selection.
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        hdr = self.horizontalHeader()
        self.setColumnWidth(COL_BACKBET, 44)
        self.setColumnWidth(COL_ODDS, 50)
        self.setColumnWidth(COL_VOL, 96)
        hdr.setSectionResizeMode(COL_BACKBET, QHeaderView.ResizeMode.Fixed)
        hdr.setSectionResizeMode(COL_BACK, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(COL_ODDS, QHeaderView.ResizeMode.Fixed)
        hdr.setSectionResizeMode(COL_LAY, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(COL_VOL, QHeaderView.ResizeMode.Fixed)

        amt_font = QFont(); amt_font.setPointSize(10); amt_font.setBold(True)
        odd_font = QFont(); odd_font.setPointSize(10); odd_font.setBold(True)

        self.setUpdatesEnabled(False)
        for row, odd in enumerate(self._ladder):
            self.setRowHeight(row, ROW_H)

            backbet = QTableWidgetItem("0.00")
            backbet.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            backbet.setBackground(QBrush(_BET_BG))
            backbet.setForeground(QBrush(_BET_FG))
            backbet.setFont(amt_font)
            self.setItem(row, COL_BACKBET, backbet)

            back = QTableWidgetItem("")
            back.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            back.setBackground(QBrush(self._back_bg))
            back.setForeground(QBrush(_AMT_FG))
            back.setFont(amt_font)
            self.setItem(row, COL_BACK, back)

            odds = QTableWidgetItem(fmt_odds(odd))
            odds.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            odds.setBackground(QBrush(_ODDS_BG))
            odds.setForeground(QBrush(_ODDS_FG))
            odds.setFont(odd_font)
            self.setItem(row, COL_ODDS, odds)

            lay = QTableWidgetItem("")
            lay.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            lay.setBackground(QBrush(self._lay_bg))
            lay.setForeground(QBrush(_AMT_FG))
            lay.setFont(amt_font)
            self.setItem(row, COL_LAY, lay)

            vol = QTableWidgetItem("")
            vol.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            vol.setBackground(QBrush(_VOL_EMPTY))
            vol.setForeground(QBrush(_VOL_FG))
            vol.setFont(amt_font)
            self.setItem(row, COL_VOL, vol)
        self.setUpdatesEnabled(True)

        self.cellClicked.connect(self._on_cell)

    # ── live update ────────────────────────────────────────────────────────
    def apply_runner(self, rb: RunnerBook):
        # Clear previously-filled back cells (unless queued)
        for row in self._filled_back:
            if ("BACK", self._ladder[row]) not in self._queued:
                it = self.item(row, COL_BACK)
                it.setText(""); it.setBackground(QBrush(self._back_bg))
        self.back_amt.clear()
        new_back: set[int] = set()
        for lvl in rb.back:
            row = self._row_of.get(round(lvl.odds, 2))
            if row is None:
                continue
            new_back.add(row)
            self.back_amt[self._ladder[row]] = lvl.amount
            if ("BACK", self._ladder[row]) in self._queued:
                continue
            it = self.item(row, COL_BACK)
            it.setText(fmt_amount_full(lvl.amount)); it.setBackground(QBrush(self._back_bg))
        self._filled_back = new_back

        for row in self._filled_lay:
            if ("LAY", self._ladder[row]) not in self._queued:
                it = self.item(row, COL_LAY)
                it.setText(""); it.setBackground(QBrush(self._lay_bg))
        self.lay_amt.clear()
        new_lay: set[int] = set()
        for lvl in rb.lay:
            row = self._row_of.get(round(lvl.odds, 2))
            if row is None:
                continue
            new_lay.add(row)
            self.lay_amt[self._ladder[row]] = lvl.amount
            if ("LAY", self._ladder[row]) in self._queued:
                continue
            it = self.item(row, COL_LAY)
            it.setText(fmt_amount_full(lvl.amount)); it.setBackground(QBrush(self._lay_bg))
        self._filled_lay = new_lay

        # Band covers only best-back → best-lay spread (not the full catb/catl set).
        # With EX_ALL_OFFERS the lay list runs from best_lay all the way to 1000,
        # so using all lay rows would paint the entire Odds column blue.
        band_rows: set[int] = set()
        if rb.back:
            r = self._row_of.get(round(rb.back[0].odds, 2))
            if r is not None:
                band_rows.add(r)
        if rb.lay:
            r = self._row_of.get(round(rb.lay[0].odds, 2))
            if r is not None:
                band_rows.add(r)
        self._highlight_band(band_rows)

    def _highlight_band(self, filled_rows: set[int]):
        """Tint the odds rungs across the live trading band (best back ↔ best lay) blue."""
        for row in self._band:
            it = self.item(row, COL_ODDS)
            it.setBackground(QBrush(_ODDS_BG)); it.setForeground(QBrush(_ODDS_FG))
        self._band = set()
        if not filled_rows:
            return
        lo, hi = min(filled_rows), max(filled_rows)
        for row in range(lo, hi + 1):
            it = self.item(row, COL_ODDS)
            it.setBackground(QBrush(_ODDS_BAND)); it.setForeground(QBrush(_ODDS_BAND_FG))
            self._band.add(row)

    def apply_traded(self, vol_by_price: dict[float, float]):
        """Show total traded volume per price in the far-right Vol column (orange)."""
        for od in self._heated - {round(o, 2) for o in vol_by_price}:
            row = self._row_of.get(od)
            if row is not None:
                it = self.item(row, COL_VOL)
                it.setText(""); it.setBackground(QBrush(_VOL_EMPTY))
        self._heated = set()
        if not vol_by_price:
            return
        mx = max(vol_by_price.values()) or 1.0
        for od, vol in vol_by_price.items():
            row = self._row_of.get(round(od, 2))
            if row is None:
                continue
            it = self.item(row, COL_VOL)
            frac = (vol / mx) ** 0.5          # sqrt → small volumes stay visible
            it.setText(fmt_amount_full(vol))
            it.setBackground(QBrush(_lerp(_VOL_EMPTY, _VOL_HOT, frac)))
            self._heated.add(round(od, 2))

    def snap(self, value: float) -> float:
        """Snap a value to the nearest rung on this column's own ladder."""
        return min(self._ladder, key=lambda t: abs(t - value))

    def scroll_to_odds(self, odds: float):
        row = self._row_of.get(round(odds, 2))
        if row is not None:
            self.scrollToItem(self.item(row, COL_ODDS),
                              QAbstractItemView.ScrollHint.PositionAtCenter)

    # ── queue ──────────────────────────────────────────────────────────────
    def toggle_queue(self, side: str, odds: float, stake: float) -> bool:
        """Toggle a queued bet on a cell. Returns True if now queued."""
        key = (side, odds)
        col = COL_BACK if side == "BACK" else COL_LAY
        row = self._row_of.get(round(odds, 2))
        if row is None:
            return False
        it = self.item(row, col)
        if key in self._queued:
            del self._queued[key]
            it.setText(""); it.setBackground(QBrush(self._back_bg if side == "BACK" else self._lay_bg))
            it.setForeground(QBrush(_AMT_FG))
            return False
        self._queued[key] = stake
        it.setText(f"{stake:g}")
        it.setBackground(QBrush(_QUEUE_BG)); it.setForeground(QBrush(_QUEUE_FG))
        return True

    def queued_bets(self) -> list[BetInstruction]:
        out = []
        for (side, odds), stake in self._queued.items():
            out.append(BetInstruction(self.selection_id, side, odds, stake))
        return out

    def clear_queue(self):
        for (side, odds) in list(self._queued):
            col = COL_BACK if side == "BACK" else COL_LAY
            row = self._row_of.get(round(odds, 2))
            if row is not None:
                it = self.item(row, col)
                it.setText(""); it.setBackground(QBrush(self._back_bg if side == "BACK" else self._lay_bg))
                it.setForeground(QBrush(_AMT_FG))
        self._queued.clear()

    def _on_cell(self, row: int, col: int):
        if col not in (COL_BACK, COL_LAY):
            return
        side = "BACK" if col == COL_BACK else "LAY"
        self.cell_clicked.emit(self.selection_id, side, self._ladder[row])


class LadderView(QWidget):
    # market_id, list[BetInstruction]
    bets_requested = pyqtSignal(str, object)
    cancel_requested = pyqtSignal(str)
    # market_id, profit, quote
    cash_out_requested = pyqtSignal(str, float, float)
    status = pyqtSignal(str)

    DEFAULT_STAKE = _DEFAULT_STAKE
    MAX_LADDERS = 3          # show at most this many selection ladders

    def __init__(self, parent=None):
        super().__init__(parent)
        self._market: Market | None = None
        self._columns: list[LadderColumn] = []
        self._selected_stake = float(DEFAULT_STAKES[0])
        self._multi = False
        self._is_line = False
        self._centered_ids: set[int] = set()
        self._conv_active = "a"                       # which odd field the user last typed in
        self._conv_bet: BetInstruction | None = None  # the single back bet, ready to fire
        self._build()
        self.show_empty()

    # ── build ──────────────────────────────────────────────────────────────
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 14, 16, 12)
        root.setSpacing(10)

        # Header
        head = QHBoxLayout()
        self._title = QLabel("No market selected")
        self._title.setObjectName("H1")
        head.addWidget(self._title)
        self._live = QLabel("")
        self._live.setObjectName("BadgeLive")
        self._live.hide()
        head.addWidget(self._live)
        head.addStretch()
        self._matched = QLabel("")
        self._matched.setObjectName("Subtle")
        head.addWidget(self._matched)
        root.addLayout(head)

        # Cash Out bar (live quote → one-click cash out)
        self._cashout = CashOutBar()
        self._cashout.cash_out_requested.connect(self.cash_out_requested)
        root.addWidget(self._cashout)

        # Control bar: stakes + multi + fire + cancel
        root.addWidget(self._build_control_bar())

        # Trade tools: 2-runner odds converter + clear-to-odds sweep bet
        root.addWidget(self._build_trade_tools())

        # Ladders host
        self._ladders_host = QWidget()
        self._ladders_row = QHBoxLayout(self._ladders_host)
        self._ladders_row.setContentsMargins(0, 0, 0, 0)
        self._ladders_row.setSpacing(10)
        self._ladders_row.addStretch()
        root.addWidget(self._ladders_host, stretch=1)

        # Liquidity calculator
        root.addWidget(self._build_liquidity_bar())

    def _build_control_bar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("Panel")
        h = QHBoxLayout(bar)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(6)

        lbl = QLabel("STAKE")
        lbl.setObjectName("SectionLabel")
        h.addWidget(lbl)

        self._stake_fields: list[QLineEdit] = []
        for i, val in enumerate(DEFAULT_STAKES):
            f = QLineEdit(str(val))
            f.setObjectName("StakeField")
            f.setFixedWidth(58)
            f.setAlignment(Qt.AlignmentFlag.AlignCenter)
            f.mousePressEvent = lambda e, idx=i: self._select_stake(idx)
            f.editingFinished.connect(lambda idx=i: self._on_stake_edited(idx))
            self._stake_fields.append(f)
            h.addWidget(f)
        self._select_stake(0)

        h.addStretch()

        self._multi_btn = QPushButton("☰ Multi")
        self._multi_btn.setObjectName("Ghost")
        self._multi_btn.setCheckable(True)
        self._multi_btn.toggled.connect(self._on_multi_toggled)
        h.addWidget(self._multi_btn)

        self._fire_btn = QPushButton("Fire (0)")
        self._fire_btn.setObjectName("Primary")
        self._fire_btn.setEnabled(False)
        self._fire_btn.clicked.connect(self._fire_all)
        h.addWidget(self._fire_btn)

        self._cancel_btn = QPushButton("Cancel All")
        self._cancel_btn.setObjectName("Danger")
        self._cancel_btn.clicked.connect(self._cancel_all)
        h.addWidget(self._cancel_btn)
        return bar

    def _build_trade_tools(self) -> QWidget:
        """Odds converter (2-runner) + clear-to-odds sweep, ported from the prototype."""
        bar = QFrame()
        bar.setObjectName("Panel")
        v = QVBoxLayout(bar)
        v.setContentsMargins(12, 8, 12, 8)
        v.setSpacing(8)

        # ── Row 1: 2-runner odds converter (Back A ↔ Back B) ──────────────────
        self._conv_row = QWidget()
        cr = QHBoxLayout(self._conv_row)
        cr.setContentsMargins(0, 0, 0, 0)
        cr.setSpacing(6)

        lbl = QLabel("CONVERT")
        lbl.setObjectName("SectionLabel")
        cr.addWidget(lbl)

        self._conv_name_a = QLabel("—")
        self._conv_name_a.setStyleSheet("font-weight:700;")
        cr.addWidget(self._conv_name_a)
        cr.addWidget(QLabel("Back"))
        self._conv_a = QLineEdit("2.00")
        self._conv_a.setFixedWidth(64)
        self._conv_a.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._conv_a.textEdited.connect(lambda: self._on_convert_edit("a"))
        cr.addWidget(self._conv_a)
        use_a = QPushButton("▸")
        use_a.setObjectName("Ghost")
        use_a.setFixedWidth(26)
        use_a.setToolTip("Load this runner + odd into Clear-to-Odds")
        use_a.clicked.connect(lambda: self._use_in_clear(0))
        cr.addWidget(use_a)

        cr.addWidget(QLabel("↔"))

        self._conv_name_b = QLabel("—")
        self._conv_name_b.setStyleSheet("font-weight:700;")
        cr.addWidget(self._conv_name_b)
        cr.addWidget(QLabel("Back"))
        self._conv_b = QLineEdit("2.00")
        self._conv_b.setFixedWidth(64)
        self._conv_b.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._conv_b.textEdited.connect(lambda: self._on_convert_edit("b"))
        cr.addWidget(self._conv_b)
        use_b = QPushButton("▸")
        use_b.setObjectName("Ghost")
        use_b.setFixedWidth(26)
        use_b.setToolTip("Load this runner + odd into Clear-to-Odds")
        use_b.clicked.connect(lambda: self._use_in_clear(1))
        cr.addWidget(use_b)

        # ── Back the OPPOSITE team: total back stake + Add+ + Place Bet ────────
        # Type A's odd -> bet on B; type B's odd -> bet on A.
        cr.addSpacing(14)
        self._conv_total = QLabel("—")
        self._conv_total.setObjectName("Subtle")
        self._conv_total.setToolTip(
            "Back stake placed if you Place now: clear-to-odds sweep of the target\n"
            "team's available-to-back up to its derived odd, plus Add+ extra.\n"
            "Target = the team OPPOSITE to the odd you typed."
        )
        cr.addWidget(self._conv_total)

        cr.addWidget(QLabel("Add+"))
        self._conv_add = QLineEdit("")
        self._conv_add.setFixedWidth(56)
        self._conv_add.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._conv_add.setPlaceholderText("0")
        self._conv_add.setToolTip("Extra back stake to rest on the target team beyond the clear-to-odds sweep.")
        self._conv_add.textChanged.connect(self._calc_conv)
        cr.addWidget(self._conv_add)

        self._conv_place_btn = QPushButton("Place Bet")
        self._conv_place_btn.setObjectName("Primary")
        self._conv_place_btn.setToolTip(
            "Back the team OPPOSITE to the odd you typed (type A's odd -> backs B).\n"
            "Obeys the ⚡ Instant toggle below (off = confirm first)."
        )
        self._conv_place_btn.clicked.connect(self._place_conv)
        cr.addWidget(self._conv_place_btn)

        cr.addStretch()
        v.addWidget(self._conv_row)

        # ── Row 2: clear-to-odds sweep ────────────────────────────────────────
        clr = QWidget()
        h = QHBoxLayout(clr)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)

        lbl2 = QLabel("CLEAR")
        lbl2.setObjectName("SectionLabel")
        h.addWidget(lbl2)

        self._clear_sel = QComboBox()
        self._clear_sel.setFixedWidth(150)
        self._clear_sel.currentIndexChanged.connect(self._calc_clear)
        h.addWidget(self._clear_sel)

        self._clear_side = QComboBox()
        self._clear_side.addItems(["BACK", "LAY"])
        self._clear_side.setFixedWidth(70)
        self._clear_side.currentIndexChanged.connect(self._calc_clear)
        h.addWidget(self._clear_side)

        h.addWidget(QLabel("to"))
        self._clear_to = QLineEdit("2.00")
        self._clear_to.setFixedWidth(64)
        self._clear_to.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._clear_to.textChanged.connect(self._calc_clear)
        h.addWidget(self._clear_to)

        h.addWidget(QLabel("Add+"))
        self._clear_add = QLineEdit("")
        self._clear_add.setFixedWidth(64)
        self._clear_add.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._clear_add.setPlaceholderText("0")
        self._clear_add.textChanged.connect(self._calc_clear)
        h.addWidget(self._clear_add)

        self._clear_size = QLabel("—")
        self._clear_size.setObjectName("Subtle")
        h.addWidget(self._clear_size)
        h.addStretch()

        self._clear_btn = QPushButton("Clear-to-Odds")
        self._clear_btn.setObjectName("Primary")
        self._clear_btn.clicked.connect(self._fire_clear)
        h.addWidget(self._clear_btn)

        # Arm toggle — red when checked: fires instantly, no confirm.
        self._arm_btn = QPushButton("⚡ Instant")
        self._arm_btn.setCheckable(True)
        self._arm_btn.setToolTip(
            "Off (default): ask to confirm before firing.\n"
            "On (red): fire the sweep immediately on click."
        )
        self._arm_btn.setStyleSheet(
            "QPushButton { background:#2a2f3a; color:#9aa0ab; border:1px solid #3a4150;"
            "border-radius:6px; padding:5px 12px; font-weight:700; }"
            "QPushButton:checked { background:#d32f2f; color:#ffffff; border:1px solid #b71c1c; }"
        )
        h.addWidget(self._arm_btn)
        self._clear_bet: BetInstruction | None = None

        v.addWidget(clr)
        return bar

    def _build_liquidity_bar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("Panel")
        h = QHBoxLayout(bar)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(8)

        lbl = QLabel("LIQUIDITY")
        lbl.setObjectName("SectionLabel")
        h.addWidget(lbl)

        self._liq_sel = QComboBox()
        self._liq_sel.setFixedWidth(160)
        self._liq_sel.currentIndexChanged.connect(self._calc_liquidity)
        h.addWidget(self._liq_sel)

        h.addWidget(QLabel("From"))
        self._liq_from = QLineEdit("1.01")
        self._liq_from.setFixedWidth(64)
        self._liq_from.textChanged.connect(self._calc_liquidity)
        h.addWidget(self._liq_from)

        h.addWidget(QLabel("To"))
        self._liq_to = QLineEdit("1000")
        self._liq_to.setFixedWidth(64)
        self._liq_to.textChanged.connect(self._calc_liquidity)
        h.addWidget(self._liq_to)

        self._liq_back = QLabel("Back: —")
        self._liq_back.setObjectName("LiqBack")
        h.addWidget(self._liq_back)
        self._liq_lay = QLabel("Lay: —")
        self._liq_lay.setObjectName("LiqLay")
        h.addWidget(self._liq_lay)
        h.addStretch()
        return bar

    # ── public API ───────────────────────────────────────────────────────────
    def show_empty(self):
        self._title.setText("No market selected")
        self._matched.setText("")
        self._live.hide()
        self._cashout.hide()
        self._clear_columns()
        self._clear_sel.clear()
        self._conv_row.setVisible(False)
        self._clear_bet = None
        self._conv_bet = None
        self._conv_total.setText("—")
        self._is_line = False
        self._clear_size.setText("—")

    def set_market(self, market: Market):
        self._market = market
        self._centered_ids = set()
        self._is_line = market.is_line
        runners = market.runners[:self.MAX_LADDERS]
        extra = len(market.runners) - len(runners)
        title = market.market_name + (f"  (+{extra} more)" if extra > 0 else "")
        self._title.setText(f"⛏ {title}")
        self._matched.setText("Matched: —")
        self._live.hide()
        self._cashout.show()
        self._cashout.set_market(market)
        self._clear_columns()

        # LINE markets ladder on a line value (e.g. runs 0.5…999.5), not odds.
        ladder = None
        if market.is_line:
            lr = market.line_range or {}
            ladder = line_ladder(
                float(lr.get("minUnitValue", 0.5)),
                float(lr.get("maxUnitValue", 999.5)),
                float(lr.get("interval", 1.0)),
            )

        self._liq_sel.blockSignals(True)
        self._clear_sel.blockSignals(True)
        self._liq_sel.clear()
        self._clear_sel.clear()
        for r in runners:
            col = LadderColumn(r.selection_id, r.runner_name,
                               ladder=ladder, line=market.is_line)
            col.cell_clicked.connect(self._on_cell_clicked)
            self._columns.append(col)
            self._ladders_row.insertWidget(self._ladders_row.count() - 1,
                                           self._wrap_column(col, r.runner_name))
            self._liq_sel.addItem(r.runner_name, r.selection_id)
            self._clear_sel.addItem(r.runner_name, r.selection_id)
        self._liq_sel.blockSignals(False)
        self._clear_sel.blockSignals(False)

        # Default the clear/liquidity range fields to the ladder's own span.
        if ladder:
            lo, hi = min(ladder), max(ladder)
            self._liq_from.setText(f"{lo:g}"); self._liq_to.setText(f"{hi:g}")
            self._clear_to.setText(f"{lo:g}")
        else:
            self._liq_from.setText("1.01"); self._liq_to.setText("1000")
            self._clear_to.setText("2.00")

        # Odds converter is only valid for true 2-outcome ODDS markets.
        self._setup_converter([] if market.is_line else market.runners)

        self._calc_liquidity()
        self._calc_clear()

    def apply_book(self, book: MarketBook):
        if not self._market:
            return
        self._matched.setText(f"Matched: {book.total_matched:,.0f}")
        if book.in_play:
            self._live.setText(f"● LIVE  (delay {book.bet_delay}s)")
            self._live.show()
        else:
            self._live.hide()

        for col in self._columns:
            rb = book.runners.get(col.selection_id)
            if rb:
                col.apply_runner(rb)
                # Center each ladder on its own live price once, on first data
                if col.selection_id not in self._centered_ids and rb.best_back():
                    col.scroll_to_odds(rb.best_back().odds)
                    self._centered_ids.add(col.selection_id)
        self._calc_liquidity(book)
        self._calc_clear()
        self._calc_conv()

    def apply_traded(self, traded_by_sel: dict[int, dict[float, float]]):
        """Render MARKET_GRAPHS traded volume in each ladder's far-right Vol column."""
        if not self._market:
            return
        for col in self._columns:
            col.apply_traded(traded_by_sel.get(col.selection_id, {}))

    # ── cash out ─────────────────────────────────────────────────────────────
    def apply_cashout_quote(self, quote: CashOutQuote):
        self._cashout.apply_quote(quote)

    def set_cashout_pending(self):
        self._cashout.set_pending()

    def notify_cashout_result(self, success: bool, message: str = ""):
        self._cashout.notify_result(success, message)

    # ── column plumbing ────────────────────────────────────────────────────
    def _wrap_column(self, col: LadderColumn, name: str) -> QWidget:
        box = QFrame()
        box.setObjectName("LadderBox")
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        title = QLabel(name)
        title.setObjectName("LadderTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setWordWrap(True)
        v.addWidget(title)

        hdr = QWidget()
        hh = QHBoxLayout(hdr)
        hh.setContentsMargins(0, 0, 0, 0)
        # Run-line markets flip the back/lay headers: Back→NO (pink), Lay→YES (blue).
        if self._is_line:
            back_lbl, back_col = "NO", Palette.LAY
            lay_lbl,  lay_col  = "YES", Palette.BACK
        else:
            back_lbl, back_col = "Back", Palette.BACK
            lay_lbl,  lay_col  = "Lay", Palette.LAY
        # (label, colour, fixed_width|None) — fixed widths match the table columns
        for text, color, width in (
            ("Bets", "#2e7d32", 44),
            (back_lbl, back_col, None),
            ("Odds", Palette.TEXT_DIM, 50),
            (lay_lbl, lay_col, None),
            ("Vol", "#b8791f", 96),
        ):
            l = QLabel(text)
            l.setAlignment(Qt.AlignmentFlag.AlignCenter)
            l.setStyleSheet(f"color:{color}; font-weight:700; font-size:11px;")
            if width:
                l.setFixedWidth(width)
                hh.addWidget(l)
            else:
                hh.addWidget(l, stretch=1)
        v.addWidget(hdr)

        col.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        v.addWidget(col, stretch=1)
        box.setMinimumWidth(330)
        return box

    def _clear_columns(self):
        # Remove every wrapper box (each holds a LadderColumn); keep the trailing stretch.
        for i in reversed(range(self._ladders_row.count())):
            w = self._ladders_row.itemAt(i).widget()
            if w is not None:
                self._ladders_row.takeAt(i)
                w.setParent(None)
                w.deleteLater()
        self._columns.clear()

    # ── stake selection ────────────────────────────────────────────────────
    def _select_stake(self, idx: int):
        for i, f in enumerate(self._stake_fields):
            f.setProperty("selected", i == idx)
            f.style().unpolish(f); f.style().polish(f)
        try:
            self._selected_stake = float(self._stake_fields[idx].text())
        except ValueError:
            self._selected_stake = 0.0

    def _on_stake_edited(self, idx: int):
        if self._stake_fields[idx].property("selected"):
            try:
                self._selected_stake = float(self._stake_fields[idx].text())
            except ValueError:
                pass

    # ── multi / fire / cancel ────────────────────────────────────────────────
    def _on_multi_toggled(self, on: bool):
        self._multi = on
        self._multi_btn.setText("☰ Multi ●" if on else "☰ Multi")
        if not on:
            for col in self._columns:
                col.clear_queue()
            self._refresh_fire()

    def _on_cell_clicked(self, selection_id: int, side: str, odds: float):
        if self._selected_stake <= 0:
            self.status.emit("Set a stake first")
            return
        col = next((c for c in self._columns if c.selection_id == selection_id), None)
        if not col:
            return
        if self._multi:
            col.toggle_queue(side, odds, self._selected_stake)
            self._refresh_fire()
        else:
            bet = BetInstruction(selection_id, side, odds, self._selected_stake)
            self._emit_bets([bet])
            self.status.emit(f"Placing {side} {self._selected_stake:g} @ {odds:g}…")

    def _refresh_fire(self):
        n = sum(len(c.queued_bets()) for c in self._columns)
        self._fire_btn.setText(f"Fire ({n})")
        self._fire_btn.setEnabled(n > 0)

    def _fire_all(self):
        bets: list[BetInstruction] = []
        for col in self._columns:
            bets.extend(col.queued_bets())
            col.clear_queue()
        self._refresh_fire()
        if bets:
            self._emit_bets(bets)
            self.status.emit(f"Firing {len(bets)} bets…")

    def _emit_bets(self, bets: list[BetInstruction]):
        if self._market:
            self.bets_requested.emit(self._market.market_id, bets)

    def _cancel_all(self):
        if self._market:
            self.cancel_requested.emit(self._market.market_id)
            self.status.emit("Cancelling all unmatched bets…")

    # ── liquidity ──────────────────────────────────────────────────────────
    def _calc_liquidity(self, book: MarketBook | None = None):
        if not self._columns:
            self._liq_back.setText("Back: —"); self._liq_lay.setText("Lay: —")
            return
        sid = self._liq_sel.currentData()
        col = next((c for c in self._columns if c.selection_id == sid), None)
        if col is None:
            return
        try:
            lo = float(self._liq_from.text()); hi = float(self._liq_to.text())
        except ValueError:
            self._liq_back.setText("Back: ERR"); self._liq_lay.setText("Lay: ERR")
            return
        lo, hi = min(lo, hi), max(lo, hi)
        back_total = sum(a for od, a in col.back_amt.items() if lo <= od <= hi)
        lay_total = sum(a for od, a in col.lay_amt.items() if lo <= od <= hi)
        self._liq_back.setText(f"Back: {back_total:,.0f}")
        self._liq_lay.setText(f"Lay: {lay_total:,.0f}")

    # ── converter (2-runner) ────────────────────────────────────────────────
    def _setup_converter(self, runners: list) -> None:
        """Enable the Back↔Back converter only for true 2-outcome markets."""
        self._conv_runners = list(runners[:2])
        if len(runners) == 2:
            self._conv_name_a.setText(runners[0].runner_name)
            self._conv_name_b.setText(runners[1].runner_name)
            self._on_convert_edit("a")     # sync field B from A (also recomputes dutch)
            self._conv_row.setVisible(True)
        else:
            self._conv_row.setVisible(False)
            self._calc_conv()

    def _on_convert_edit(self, src: str):
        """Mirror one runner's back odd to the other via o/(o-1), and push the
        edited team + odd down into the clear-to-odds row (one-way: top → bottom).

        The field you type in (src) also decides the Place Bet target: typing A's
        odd backs B, typing B's odd backs A.
        """
        self._conv_active = src
        src_field = self._conv_a if src == "a" else self._conv_b
        dst_field = self._conv_b if src == "a" else self._conv_a
        try:
            opp = opposite_odds(float(src_field.text()))
        except ValueError:
            opp = None
        if opp is not None:
            dst_field.blockSignals(True)
            dst_field.setText(f"{opp:g}")
            dst_field.blockSignals(False)
        self._sync_clear_from_conv()
        self._calc_conv()

    def _sync_clear_from_conv(self):
        """One-way sync: the convert field you typed in selects that same team and
        odd in the clear-to-odds row below. Editing the clear row never flows back
        up to the converter."""
        self._use_in_clear(0 if self._conv_active == "a" else 1)

    def _use_in_clear(self, idx: int):
        """Load a converter runner + its odd into the clear-to-odds form."""
        if idx >= len(getattr(self, "_conv_runners", [])):
            return
        sid = self._conv_runners[idx].selection_id
        field = self._conv_a if idx == 0 else self._conv_b
        i = self._clear_sel.findData(sid)
        if i >= 0:
            self._clear_sel.setCurrentIndex(i)
        self._clear_side.setCurrentText("BACK")
        self._clear_to.setText(field.text())
        self._calc_clear()

    # ── back the opposite team (type A's odd → back B, and vice versa) ────────
    def _calc_conv(self, *_):
        """Size one back bet on the team OPPOSITE to the odd you typed.

        Type A's odd → target B; type B's odd → target A. Stake = clear-to-odds
        sweep of the target team's available-to-back up to its (derived) odd,
        plus Add+ extra. Only valid for a true 2-runner odds market.
        """
        self._conv_bet = None
        runners = getattr(self, "_conv_runners", [])
        if len(runners) != 2 or self._is_line:
            self._conv_total.setText("—")
            self._conv_place_btn.setEnabled(False)
            return

        # Target = the runner opposite to the field last edited.
        if self._conv_active == "a":
            target_runner, target_field = runners[1], self._conv_b
        else:
            target_runner, target_field = runners[0], self._conv_a

        try:
            add = float(self._conv_add.text()) if self._conv_add.text().strip() else 0.0
        except ValueError:
            add = 0.0

        col = next((c for c in self._columns if c.selection_id == target_runner.selection_id), None)
        try:
            target = col.snap(float(target_field.text())) if col else None
        except ValueError:
            target = None
        if col is None or target is None:
            self._conv_total.setText("—")
            self._conv_place_btn.setEnabled(False)
            return

        # Backing sweeps available-to-back at odds >= target (best is highest).
        sweep = sum(a for od, a in col.back_amt.items() if od >= target - 1e-9)
        size = sweep + add
        self._conv_total.setText(f"Back {target_runner.runner_name}: {size:,.0f}")
        if size > 0:
            self._conv_bet = BetInstruction(col.selection_id, "BACK", target, size)
            self._conv_place_btn.setEnabled(True)
        else:
            self._conv_place_btn.setEnabled(False)

    def _place_conv(self):
        self._calc_conv()
        bet = self._conv_bet
        if bet is None or bet.size <= 0:
            self.status.emit("Nothing to place — stake is 0")
            return
        names = {r.selection_id: r.runner_name for r in getattr(self, "_conv_runners", [])}
        name = names.get(bet.selection_id, bet.selection_id)
        summary = f"BACK {bet.size:,.0f} @ {bet.price:g} on {name}"
        if not self._arm_btn.isChecked():
            reply = QMessageBox.question(
                self, "Confirm place bet",
                f"Place this bet?\n\n{summary}",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        self._emit_bets([bet])
        self.status.emit(f"Placing: {summary}…")

    # ── clear-to-odds ────────────────────────────────────────────────────────
    def _clear_inputs(self):
        """Resolve the current clear-to-odds form into (column, side, target, add)."""
        if not self._columns:
            return None
        sid = self._clear_sel.currentData()
        col = next((c for c in self._columns if c.selection_id == sid), None)
        if col is None:
            return None
        side = self._clear_side.currentText().upper()
        try:
            target = col.snap(float(self._clear_to.text()))   # snap to this ladder
        except ValueError:
            return None
        add_txt = self._clear_add.text().strip()
        try:
            add = float(add_txt) if add_txt else 0.0
        except ValueError:
            add = 0.0
        return col, side, target, add

    def _calc_clear(self, *_):
        self._clear_bet = None
        parsed = self._clear_inputs()
        if parsed is None:
            self._clear_size.setText("—")
            return
        col, side, target, add = parsed
        if side == "BACK":
            # Backing sweeps available-to-back at odds ≥ target (best is highest).
            sweep = sum(a for od, a in col.back_amt.items() if od >= target - 1e-9)
        else:
            # Laying sweeps available-to-lay at odds ≤ target (best is lowest).
            sweep = sum(a for od, a in col.lay_amt.items() if od <= target + 1e-9)
        total = sweep + add
        if total <= 0:
            self._clear_size.setText("clears 0")
            return
        if getattr(self, "_is_line", False):
            # Line markets aren't odds — liability isn't a back/lay exposure.
            self._clear_size.setText(f"sweep {sweep:,.0f} + add {add:,.0f} = {total:,.0f}")
        else:
            liab = total if side == "BACK" else total * (target - 1)
            self._clear_size.setText(
                f"sweep {sweep:,.0f} + add {add:,.0f} = {total:,.0f}  (liab {liab:,.0f})"
            )
        self._clear_bet = BetInstruction(col.selection_id, side, target, total)

    def _fire_clear(self):
        self._calc_clear()
        bet = self._clear_bet
        if bet is None or bet.size <= 0:
            self.status.emit("Nothing to clear — size is 0")
            return
        runner = self._clear_sel.currentText()
        summary = (f"{bet.side} {bet.size:,.0f} on {runner} @ {bet.price:g}")
        if not self._arm_btn.isChecked():
            reply = QMessageBox.question(
                self, "Confirm clear-to-odds",
                f"Place this bet?\n\n{summary}",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        self._emit_bets([bet])
        self.status.emit(f"Clearing: {summary}…")
