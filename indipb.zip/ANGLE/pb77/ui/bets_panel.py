"""Collapsible in-app Open Bets panel — Matched / Unmatched tabs."""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QScrollArea, QFrame, QStackedWidget,
)

_BACK_BG    = "rgba(30,80,140,0.85)"
_LAY_BG     = "rgba(140,30,60,0.85)"
_BACK_STRIP = "rgba(255,255,255,0.05)"
_LAY_STRIP  = "rgba(255,255,255,0.05)"
_BACK_BADGE = "#90CAF9"
_LAY_BADGE  = "#faa9ba"
_PANEL_W    = 320


def _f(b: dict, key: str) -> float:
    try:
        return float(b.get(key, 0) or 0)
    except (TypeError, ValueError):
        return 0.0


class _ClickableLabel(QLabel):
    """A QLabel that emits `double_clicked` — used for the team name."""
    double_clicked = pyqtSignal()

    def mouseDoubleClickEvent(self, event):
        self.double_clicked.emit()
        super().mouseDoubleClickEvent(event)


# ── Card ───────────────────────────────────────────────────────────────────────

class _BetCard(QFrame):
    cancel_requested = pyqtSignal(dict)
    open_requested = pyqtSignal(dict)        # double-click → open this market in the grid

    def __init__(self, bet: dict, matched: bool, parent=None):
        super().__init__(parent)
        self._bet  = bet
        side       = bet.get("side", "")
        is_back    = side == "BACK"
        card_bg    = _BACK_BG    if is_back else _LAY_BG
        strip_bg   = _BACK_STRIP if is_back else _LAY_STRIP
        badge_col  = _BACK_BADGE if is_back else _LAY_BADGE
        badge_text = "#0a1a2e"   if is_back else "#2e0a18"

        self.setStyleSheet(f"""
            _BetCard, QFrame#BetCard {{
                background: {card_bg};
                border-radius: 10px;
                border: none;
            }}
        """)
        self.setObjectName("BetCard")

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── top section ─────────────────────────────────────────────────────────
        top = QWidget()
        top.setStyleSheet("background: transparent; border: none;")
        tv = QVBoxLayout(top)
        tv.setContentsMargins(12, 10, 12, 8)
        tv.setSpacing(3)

        # Row 1: badge + selection
        r1 = QHBoxLayout(); r1.setSpacing(8)
        badge = QLabel(side)
        badge.setStyleSheet(
            f"background:{badge_col}; color:{badge_text};"
            "border-radius:4px; padding:2px 8px;"
            "font-size:10px; font-weight:900; border:none; letter-spacing:0.5px;"
        )
        badge.setFixedHeight(20)
        r1.addWidget(badge)

        sel = _ClickableLabel(bet.get("selectionName", "—"))
        sel.setStyleSheet(
            "color:#f0f2f5; font-weight:700; font-size:13px; border:none; background:transparent;"
        )
        sel.setWordWrap(True)
        sel.setCursor(Qt.CursorShape.PointingHandCursor)
        sel.setToolTip("Double-click to open this market in the grid")
        sel.double_clicked.connect(lambda: self.open_requested.emit(self._bet))
        r1.addWidget(sel, stretch=1)
        tv.addLayout(r1)

        # Row 2: event · market
        event_txt = f"{bet.get('eventName','')}  ·  {bet.get('marketName','')}"
        evt = QLabel(event_txt)
        evt.setStyleSheet("color:#8892a0; font-size:10px; border:none; background:transparent;")
        evt.setWordWrap(True)
        tv.addWidget(evt)
        root.addWidget(top)

        # ── divider ─────────────────────────────────────────────────────────────
        div = QFrame()
        div.setFixedHeight(1)
        div.setStyleSheet("background:rgba(255,255,255,0.08); border:none;")
        root.addWidget(div)

        # ── stats strip ─────────────────────────────────────────────────────────
        strip = QWidget()
        strip.setStyleSheet(f"background:{strip_bg}; border:none; border-radius:0px;")
        sv = QHBoxLayout(strip)
        sv.setContentsMargins(12, 8, 12, 8)
        sv.setSpacing(0)

        price = _f(bet, "price")
        if matched:
            # potentialProfit is meaningful for open (unsettled) bets;
            # profit is only non-zero after settlement.
            pnl     = _f(bet, "potentialProfit") or _f(bet, "profit")
            pnl_str = f"{'+' if pnl >= 0 else ''}{pnl:,.2f}"
            stats   = [("ODDS", f"{price:g}"), ("MATCHED", f"{_f(bet,'sizeMatched'):,.2f}"), ("POTENTIAL P&L", pnl_str)]
        else:
            # Server sends liability=0 for unmatched bets (nothing committed yet).
            # Compute the real exposure: BACK = stake, LAY = remaining × (price-1).
            side      = bet.get("side", "")
            remaining = _f(bet, "sizeRemaining")
            liab      = remaining if side == "BACK" else remaining * (price - 1)
            stats = [
                ("ODDS",      f"{price:g}"),
                ("STAKE",     f"{_f(bet,'sizePlaced'):,.2f}"),
                ("REMAINING", f"{remaining:,.2f}"),
                ("LIABILITY", f"{liab:,.2f}"),
            ]

        for i, (lbl_txt, val_txt) in enumerate(stats):
            if i > 0:
                sep = QFrame()
                sep.setFrameShape(QFrame.Shape.VLine)
                sep.setStyleSheet("color:rgba(255,255,255,0.12); background:rgba(255,255,255,0.12); border:none; max-width:1px;")
                sv.addWidget(sep)
                sv.addSpacing(8)
            col = QWidget()
            col.setStyleSheet("background:transparent; border:none;")
            cv = QVBoxLayout(col)
            cv.setContentsMargins(0, 0, 8, 0)
            cv.setSpacing(1)
            lbl = QLabel(lbl_txt)
            lbl.setStyleSheet(
                "color:rgba(200,210,220,0.5); font-size:8px; font-weight:800;"
                "letter-spacing:0.8px; border:none; background:transparent;"
            )
            val = QLabel(val_txt)
            val.setStyleSheet(
                "color:#f0f2f5; font-size:12px; font-weight:700; border:none; background:transparent;"
            )
            cv.addWidget(lbl)
            cv.addWidget(val)
            sv.addWidget(col)

        sv.addStretch()
        root.addWidget(strip)

        # ── footer ──────────────────────────────────────────────────────────────
        footer = QWidget()
        footer.setStyleSheet("background:transparent; border:none;")
        fh = QHBoxLayout(footer)
        fh.setContentsMargins(12, 6, 12, 8)
        fh.setSpacing(8)

        state = bet.get("offerState", "")
        state_lbl = QLabel(state)
        state_lbl.setStyleSheet(
            "color:rgba(200,210,220,0.4); font-size:9px; font-weight:700;"
            "letter-spacing:0.5px; border:none; background:transparent;"
        )
        fh.addWidget(state_lbl)

        if bet.get("inPlay") or bet.get("eventInPlay"):
            ip = QLabel("● LIVE")
            ip.setStyleSheet(
                "color:#3fb950; font-size:9px; font-weight:800;"
                "letter-spacing:0.5px; border:none; background:transparent;"
            )
            fh.addWidget(ip)

        fh.addStretch()

        if not matched:
            cancel_btn = QPushButton("Cancel")
            cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            cancel_btn.setStyleSheet("""
                QPushButton {
                    background: rgba(248,81,73,0.15);
                    color: #f85149;
                    border: 1px solid rgba(248,81,73,0.35);
                    border-radius: 5px;
                    font-size: 10px;
                    font-weight: 700;
                    padding: 3px 12px;
                }
                QPushButton:hover {
                    background: rgba(248,81,73,0.28);
                    border-color: rgba(248,81,73,0.6);
                }
                QPushButton:pressed {
                    background: rgba(248,81,73,0.4);
                }
            """)
            cancel_btn.setFixedHeight(24)
            cancel_btn.clicked.connect(lambda: self.cancel_requested.emit(self._bet))
            fh.addWidget(cancel_btn)

        root.addWidget(footer)


# ── Scroll container ────────────────────────────────────────────────────────────

class _ScrollList(QScrollArea):
    cancel_requested = pyqtSignal(dict)
    open_requested = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        self._container = QWidget()
        self._container.setStyleSheet("background: transparent;")
        self._layout = QVBoxLayout(self._container)
        self._layout.setContentsMargins(10, 10, 10, 10)
        self._layout.setSpacing(8)
        self._layout.addStretch()
        self.setWidget(self._container)

    def set_bets(self, bets: list[dict], matched: bool):
        while self._layout.count() > 1:
            item = self._layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for bet in bets:
            card = _BetCard(bet, matched, self._container)
            card.cancel_requested.connect(self.cancel_requested)
            card.open_requested.connect(self.open_requested)
            self._layout.insertWidget(self._layout.count() - 1, card)


# ── Main panel ─────────────────────────────────────────────────────────────────

class BetsPanel(QWidget):
    """Collapsible right-side panel embedded in the main window."""
    cancel_all_requested = pyqtSignal()
    cancel_bet_requested = pyqtSignal(dict)
    open_market_requested = pyqtSignal(dict)
    close_requested      = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            BetsPanel {
                background-color: #13161e;
                border-left: 1px solid #252932;
            }
        """)
        self._build()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── header ──────────────────────────────────────────────────────────────
        header = QFrame()
        header.setStyleSheet(
            "background: qlineargradient(x1:0,y1:0,x2:0,y2:1,"
            "stop:0 #1e2433, stop:1 #181c28);"
            "border-bottom: 1px solid #252932;"
        )
        header.setFixedHeight(50)
        hh = QHBoxLayout(header)
        hh.setContentsMargins(16, 0, 12, 0)

        title = QLabel("Open Bets")
        title.setStyleSheet(
            "font-size:14px; font-weight:800; color:#e8eaf0;"
            "background:transparent; border:none; letter-spacing:0.3px;"
        )
        hh.addWidget(title)

        self._badge = QLabel("0")
        self._badge.setStyleSheet(
            "background:#c8a020; color:#1a1100; border-radius:10px;"
            "padding:2px 8px; font-size:10px; font-weight:900; border:none;"
        )
        self._badge.setFixedHeight(20)
        hh.addWidget(self._badge)
        hh.addStretch()

        close_btn = QPushButton("✕")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setStyleSheet(
            "QPushButton { background:transparent; border:none; color:#5a6070;"
            "font-size:15px; padding:4px 6px; }"
            "QPushButton:hover { color:#e8eaf0; }"
        )
        close_btn.clicked.connect(self.close_requested)
        hh.addWidget(close_btn)
        root.addWidget(header)

        # ── tab bar ─────────────────────────────────────────────────────────────
        tab_bar = QFrame()
        tab_bar.setStyleSheet("background:#13161e; border-bottom:1px solid #252932;")
        tab_bar.setFixedHeight(42)
        th = QHBoxLayout(tab_bar)
        th.setContentsMargins(12, 5, 12, 5)
        th.setSpacing(6)

        self._tab_unmatched = QPushButton("Unmatched")
        self._tab_matched   = QPushButton("Matched")
        _TAB_SS = """
            QPushButton {
                background: transparent; border: none;
                color: #5a6070; font-size: 12px; font-weight: 700;
                padding: 5px 14px; border-radius: 7px;
            }
            QPushButton:checked {
                background: #252932; color: #e8eaf0;
            }
            QPushButton:hover:!checked {
                color: #9aa4b4;
            }
        """
        for btn in (self._tab_unmatched, self._tab_matched):
            btn.setCheckable(True)
            btn.setStyleSheet(_TAB_SS)
        self._tab_unmatched.setChecked(True)
        self._tab_unmatched.clicked.connect(lambda: self._switch(0))
        self._tab_matched.clicked.connect(lambda: self._switch(1))
        th.addWidget(self._tab_unmatched)
        th.addWidget(self._tab_matched)
        th.addStretch()
        root.addWidget(tab_bar)

        # ── cancel-all bar ───────────────────────────────────────────────────────
        self._cancel_bar = QFrame()
        self._cancel_bar.setStyleSheet("background:#13161e; border-bottom:1px solid #252932;")
        self._cancel_bar.setFixedHeight(36)
        cb = QHBoxLayout(self._cancel_bar)
        cb.setContentsMargins(16, 0, 16, 0)
        cancel_all_btn = QPushButton("Cancel All Unmatched")
        cancel_all_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        cancel_all_btn.setStyleSheet(
            "QPushButton { background:transparent; border:none; color:#f85149;"
            "font-size:11px; font-weight:700; text-decoration:underline; }"
            "QPushButton:hover { color:#ff7b73; }"
        )
        cancel_all_btn.clicked.connect(self.cancel_all_requested)
        cb.addWidget(cancel_all_btn)
        cb.addStretch()
        root.addWidget(self._cancel_bar)

        # ── lists ────────────────────────────────────────────────────────────────
        self._stack = QStackedWidget()
        self._stack.setStyleSheet("background:transparent;")
        self._unmatched_list = _ScrollList()
        self._matched_list   = _ScrollList()
        self._unmatched_list.cancel_requested.connect(self.cancel_bet_requested)
        self._unmatched_list.open_requested.connect(self.open_market_requested)
        self._matched_list.open_requested.connect(self.open_market_requested)
        self._stack.addWidget(self._unmatched_list)
        self._stack.addWidget(self._matched_list)
        root.addWidget(self._stack, stretch=1)

    # ── public ─────────────────────────────────────────────────────────────────

    def set_count(self, count: int):
        self._badge.setText(str(count))

    def update_bets(self, bets: list[dict]):
        unmatched = [b for b in bets if _f(b, "sizeRemaining") > 0]
        matched   = [b for b in bets if _f(b, "sizeMatched")   > 0]

        self._tab_unmatched.setText(f"Unmatched  {len(unmatched)}" if unmatched else "Unmatched")
        self._tab_matched.setText(  f"Matched  {len(matched)}"     if matched   else "Matched")

        self._unmatched_list.set_bets(unmatched, matched=False)
        self._matched_list.set_bets(matched,     matched=True)
        self._cancel_bar.setVisible(bool(unmatched) and self._stack.currentIndex() == 0)

    # ── internal ───────────────────────────────────────────────────────────────

    def _switch(self, idx: int):
        self._stack.setCurrentIndex(idx)
        self._tab_unmatched.setChecked(idx == 0)
        self._tab_matched.setChecked(idx == 1)
        self._cancel_bar.setVisible(idx == 0 and self._unmatched_list._layout.count() > 1)
