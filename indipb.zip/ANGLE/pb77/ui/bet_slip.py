"""
Bet slip — the bottom betting panel opened when a grid back/lay cell is clicked.

Mirrors the site's slip: a colour-coded header (Back = blue "Bet For", Lay = pink
"Bet Against"), odds + stake steppers, a live payout/profit readout (plus a linked
liability stepper for lays), and a Place Bet button.

Payout/profit maths:
    BACK:  payout = stake · odds      profit    = stake · (odds − 1)
    LAY:   payout = stake · odds      liability = stake · (odds − 1)   profit = stake
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QFrame,
)

from pb77.api.models import Market, BetInstruction
from pb77.api.ladder import LADDER_ODDS_ASC, snap_odd

_BACK_BG = "#1d3c52"      # blue header (Bet For)
_LAY_BG  = "#5a2438"      # pink header (Bet Against)
_GOLD    = "#d4af37"
_GREEN   = "#3fb950"
_RED     = "#f85149"

STAKE_STEP = 5.0          # ± step for the stake / liability fields


class BetSlip(QWidget):
    place_requested = pyqtSignal(str, object)   # market_id, [BetInstruction]
    status = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._market: Market | None = None
        self._sid: int = 0
        self._side = "BACK"
        self._build()
        self.hide()

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build(self):
        self.setObjectName("BetSlip")
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Header: "<Side> (Bet For/Against): <runner> — <market>"  + close
        self._header = QFrame()
        self._header.setObjectName("SlipHeader")
        hh = QHBoxLayout(self._header)
        hh.setContentsMargins(14, 8, 10, 8)
        self._title = QLabel("")
        self._title.setStyleSheet("font-weight:800; font-size:13px; color:#ffffff; background:transparent;")
        hh.addWidget(self._title)
        hh.addStretch()
        close = QPushButton("✕")
        close.setObjectName("SlipClose")
        close.setFixedSize(26, 26)
        close.setCursor(Qt.CursorShape.PointingHandCursor)
        close.setStyleSheet(
            "QPushButton#SlipClose { background:transparent; color:#ffffff; border:none;"
            " font-size:15px; font-weight:800; }"
        )
        close.clicked.connect(self.close_slip)
        hh.addWidget(close)
        root.addWidget(self._header)

        # Body
        body = QFrame()
        body.setObjectName("SlipBody")
        bl = QVBoxLayout(body)
        bl.setContentsMargins(14, 12, 14, 12)
        bl.setSpacing(10)

        # Odds + Stake (+ Liability for lay) steppers, side by side
        fields = QHBoxLayout()
        fields.setSpacing(12)
        self._odds_field, odds_box = self._stepper("Odds", self._step_odds)
        self._stake_field, stake_box = self._stepper("Stake", self._step_stake)
        self._liab_field, self._liab_box = self._stepper("Liability", self._step_liability)
        fields.addWidget(odds_box, stretch=1)
        fields.addWidget(stake_box, stretch=1)
        fields.addWidget(self._liab_box, stretch=1)
        bl.addLayout(fields)

        self._odds_field.textEdited.connect(self._recalc)
        self._stake_field.textEdited.connect(self._recalc)
        self._liab_field.textEdited.connect(self._on_liability_edited)

        # Payout / profit readout
        readout = QHBoxLayout()
        self._payout_lbl = QLabel("Payout: —")
        self._payout_lbl.setStyleSheet("font-weight:700; color:#e6e8ec;")
        self._profit_lbl = QLabel("Profit: —")
        self._profit_lbl.setStyleSheet("font-weight:700;")
        readout.addWidget(self._payout_lbl)
        readout.addStretch()
        readout.addWidget(self._profit_lbl)
        bl.addLayout(readout)

        # Place Bet
        self._place_btn = QPushButton("Place Bet")
        self._place_btn.setObjectName("SlipPlace")
        self._place_btn.setMinimumHeight(40)
        self._place_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._place_btn.setStyleSheet(
            f"QPushButton#SlipPlace {{ background:{_GOLD}; color:#1a1207; border:none;"
            f" border-radius:8px; font-weight:800; font-size:14px; }}"
            f"QPushButton#SlipPlace:hover {{ background:#e1c14e; }}"
        )
        self._place_btn.clicked.connect(self._on_place)
        bl.addWidget(self._place_btn)

        root.addWidget(body)

    def _stepper(self, label: str, on_step) -> tuple[QLineEdit, QWidget]:
        """A labelled [−][value][+] stepper. Returns (field, container)."""
        box = QFrame()
        box.setObjectName("SlipField")
        box.setStyleSheet(
            "QFrame#SlipField { background:#11151b; border:1px solid #2a2f3a; border-radius:8px; }"
        )
        v = QVBoxLayout(box)
        v.setContentsMargins(8, 4, 8, 6)
        v.setSpacing(0)
        cap = QLabel(label)
        cap.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cap.setStyleSheet("color:#9aa0ab; font-size:10px; font-weight:700; background:transparent;")
        v.addWidget(cap)

        row = QHBoxLayout()
        row.setSpacing(6)
        minus = QPushButton("−")
        plus = QPushButton("+")
        for b in (minus, plus):
            b.setFixedSize(28, 28)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setStyleSheet(
                "QPushButton { background:#222834; color:#e6e8ec; border:none;"
                " border-radius:6px; font-size:16px; font-weight:800; }"
                "QPushButton:hover { background:#2c3340; }"
            )
        minus.clicked.connect(lambda: on_step(-1))
        plus.clicked.connect(lambda: on_step(+1))
        field = QLineEdit("")
        field.setAlignment(Qt.AlignmentFlag.AlignCenter)
        field.setStyleSheet(
            "QLineEdit { background:transparent; border:none; color:#ffffff;"
            " font-size:16px; font-weight:800; }"
        )
        row.addWidget(minus)
        row.addWidget(field, stretch=1)
        row.addWidget(plus)
        v.addLayout(row)
        return field, box

    # ── Public API ────────────────────────────────────────────────────────────

    def set_market(self, market: Market):
        self._market = market
        self.close_slip()

    def open_for(self, selection_id: int, runner_name: str, side: str,
                 odds: float, stake: float):
        """Populate + reveal the slip for a clicked back/lay cell."""
        if self._market is None:
            return
        self._sid = selection_id
        self._side = side.upper()
        is_lay = self._side == "LAY"

        verb = "Bet Against" if is_lay else "Bet For"
        self._title.setText(f"{self._side.title()} ({verb}):  {runner_name} — {self._market.market_name}")
        self._header.setStyleSheet(
            f"QFrame#SlipHeader {{ background:{_LAY_BG if is_lay else _BACK_BG}; }}"
        )
        self._odds_field.setText(f"{odds:g}")
        self._stake_field.setText(f"{stake:g}" if stake > 0 else "")
        self._liab_box.setVisible(is_lay)
        self._recalc()
        self.show()

    def close_slip(self):
        self.hide()

    # ── Steppers ──────────────────────────────────────────────────────────────

    def _step_odds(self, direction: int):
        cur = self._read(self._odds_field)
        if cur is None:
            return
        if self._market and self._market.is_line:
            interval = float((self._market.line_range or {}).get("interval", 1.0)) or 1.0
            new = max(0.0, cur + direction * interval)
        else:
            i = min(range(len(LADDER_ODDS_ASC)), key=lambda k: abs(LADDER_ODDS_ASC[k] - cur))
            i = max(0, min(len(LADDER_ODDS_ASC) - 1, i + direction))
            new = LADDER_ODDS_ASC[i]
        self._odds_field.setText(f"{new:g}")
        self._recalc()

    def _step_stake(self, direction: int):
        cur = self._read(self._stake_field) or 0.0
        new = max(0.0, cur + direction * STAKE_STEP)
        self._stake_field.setText(f"{new:g}")
        self._recalc()

    def _step_liability(self, direction: int):
        cur = self._read(self._liab_field) or 0.0
        new = max(0.0, cur + direction * STAKE_STEP)
        self._liab_field.setText(f"{new:g}")
        self._on_liability_edited()

    def _on_liability_edited(self, *_):
        """Editing liability back-computes the stake (lay: stake = liability / (odds−1))."""
        odds = self._read(self._odds_field)
        liab = self._read(self._liab_field)
        if odds and liab is not None and odds > 1:
            stake = liab / (odds - 1)
            self._stake_field.blockSignals(True)
            self._stake_field.setText(f"{stake:g}")
            self._stake_field.blockSignals(False)
        self._recalc(skip_liability=True)

    # ── Calc + place ──────────────────────────────────────────────────────────

    def _recalc(self, *_, skip_liability: bool = False):
        odds = self._read(self._odds_field)
        stake = self._read(self._stake_field)
        if not odds or stake is None or stake <= 0 or odds <= 1:
            self._payout_lbl.setText("Payout: —")
            self._profit_lbl.setText("Profit: —")
            self._place_btn.setEnabled(bool(odds and stake and stake > 0))
            return
        payout = stake * odds
        exposure = stake * (odds - 1)
        self._payout_lbl.setText(f"Payout: {payout:,.2f}")
        if self._side == "LAY":
            self._profit_lbl.setText(f"Profit: {stake:,.2f}")
            self._profit_lbl.setStyleSheet(f"font-weight:700; color:{_GREEN};")
            if not skip_liability:
                self._liab_field.blockSignals(True)
                self._liab_field.setText(f"{exposure:g}")
                self._liab_field.blockSignals(False)
        else:
            self._profit_lbl.setText(f"Profit: {exposure:,.2f}")
            self._profit_lbl.setStyleSheet(f"font-weight:700; color:{_GREEN};")
        self._place_btn.setEnabled(True)

    def _on_place(self):
        odds = self._read(self._odds_field)
        stake = self._read(self._stake_field)
        if self._market is None or not odds or not stake or stake <= 0:
            self.status.emit("Enter odds and stake first")
            return
        bet = BetInstruction(self._sid, self._side, odds, stake)
        self.place_requested.emit(self._market.market_id, [bet])
        self.status.emit(f"Placing {self._side} {stake:g} @ {odds:g}…")
        self.close_slip()

    @staticmethod
    def _read(field: QLineEdit) -> float | None:
        try:
            return float(field.text())
        except ValueError:
            return None
