
"""PB77 Terminal — application entry point."""
import logging
import os
import sys

if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt6.QtCore import Qt, QThreadPool
from PyQt6.QtWidgets import QApplication

from pb77.api.endpoints import set_domain
from pb77.api.client import PB77Client
from pb77.ui.login_view import LoginDialog
from pb77.ui.main_window import MainWindow
from pb77.ui.theme import stylesheet

# ── Site domain ────────────────────────────────────────────────────────────────
# The ONLY place to change the site. Auth + exchange hosts are worked out from it:
#   pb77    →  DOMAIN = "pb77.co"        (auth www.pb77.co,   exchange ex.pb77.co)
#   indibet →  DOMAIN = "in.indibet.in"  (auth in.indibet.in, exchange ex.in.indibet.in)
# A bare apex (pb77.co) gets "www." for auth; a full host (in.indibet.in) is used
# as-is. Everything (REST/WS URLs, Origin/Referer, cookie domain) follows this line.
# (The PB77_DOMAIN environment variable, if set, overrides it.)
DOMAIN = "in.indibet.in"


def main():
    set_domain(os.environ.get("PB77_DOMAIN", DOMAIN))

    log_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "pb77.log")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler(), logging.FileHandler(log_path, mode="w")],
    )
    logging.getLogger(__name__).info("Logging to %s", log_path)

    app = QApplication(sys.argv)
    app.setApplicationName("PB77 Terminal")
    app.setStyleSheet(stylesheet())
    try:
        app.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps)
    except Exception:
        pass

    pool = QThreadPool.globalInstance()
    assert pool is not None
    log = logging.getLogger(__name__)

    while True:
        client = PB77Client()

        # Resume a previously saved session if one is still valid — this skips
        # the login flow entirely across app restarts / reboots. Otherwise show
        # the login popup (blocks until accepted or dismissed).
        if client.restore_session() and client.session is not None:
            session = client.session
            log.info("Resuming saved session for %s", session.nickname)
        else:
            dialog = LoginDialog(client, pool)
            if dialog.exec() != LoginDialog.DialogCode.Accepted or dialog.session is None:
                sys.exit(0)
            session = dialog.session

        # Open full trading window
        window = MainWindow(client, session)
        window.show()
        app.exec()

        # Window closed. If the user explicitly logged out (or the session
        # expired), loop back to the login screen; otherwise quit the app.
        if not window.logged_out:
            break

    sys.exit(0)


if __name__ == "__main__":
    main()
