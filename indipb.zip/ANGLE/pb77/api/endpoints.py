"""
Single source of truth for the site host.

Set DOMAIN in app.py to the site's domain. The two hosts (auth + exchange) are
worked out from it automatically, because different sites are laid out differently:

  • bare apex  (one dot,  e.g. "pb77.co")        → auth www.pb77.co     exchange ex.pb77.co
  • full host  (sub.domain, e.g. "in.indibet.in") → auth in.indibet.in  exchange ex.in.indibet.in
  • "www.…" given explicitly  ("www.pb77.co")     → auth www.pb77.co     exchange ex.pb77.co

So you can type "pb77.co" OR "www.pb77.co" for pb77, and "in.indibet.in" for
indibet — all resolve correctly. Everything (REST/WS URLs, Origin/Referer, cookie
domain) follows, because client.py / stream.py read these at call time.
"""
from __future__ import annotations

import os

DEFAULT_DOMAIN = "pb77.co"


def _normalize(domain: str) -> str:
    """Reduce a pasted value to a bare host (e.g. 'https://in.indibet.in/' → 'in.indibet.in')."""
    d = (domain or "").strip()
    for scheme in ("https://", "http://", "wss://", "ws://"):
        d = d.replace(scheme, "")
    d = d.strip("/").split("/")[0].lstrip(".")
    return d or DEFAULT_DOMAIN


def _derive_hosts(domain: str) -> tuple[str, str]:
    """(auth_host, exchange_host) for a given DOMAIN.

    A bare apex (single dot, e.g. pb77.co) is a registrable domain whose site
    lives at www.<apex>; anything with a subdomain (in.indibet.in) is already the
    host you visit. The exchange host is the apex/host with an "ex." prefix.
    """
    d = _normalize(domain)
    if d.startswith("www."):
        base = d[len("www."):]
        return d, f"ex.{base}"
    if d.count(".") <= 1:               # bare apex like "pb77.co"
        return f"www.{d}", f"ex.{d}"
    return d, f"ex.{d}"                  # full host like "in.indibet.in"


class _Endpoints:
    def __init__(self, domain: str):
        self.set_domain(domain)

    def set_domain(self, domain: str) -> None:
        self._www_host, self._ex_host = _derive_hosts(domain)

    # Auth / account host
    @property
    def www_base(self) -> str:
        return f"https://{self._www_host}"

    # Exchange host (also the cookie domain)
    @property
    def ex_host(self) -> str:
        return self._ex_host

    @property
    def ex_base(self) -> str:
        return f"https://{self._ex_host}"

    # WebSocket bases (SockJS) — on the exchange host
    @property
    def ws_multi(self) -> str:
        return f"wss://{self._ex_host}/customer/ws/multiple-market-prices"

    @property
    def ws_general(self) -> str:
        return f"wss://{self._ex_host}/customer/ws/general"


# Initialised from PB77_DOMAIN if set, else the default; app.py overrides via set_domain().
ENDPOINTS = _Endpoints(os.environ.get("PB77_DOMAIN", DEFAULT_DOMAIN))


def set_domain(domain: str) -> None:
    """Point the whole app at a different site (e.g. 'pb77.co' or 'in.indibet.in')."""
    ENDPOINTS.set_domain(domain)
