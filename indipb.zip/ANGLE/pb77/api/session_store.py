"""
Persist the authenticated session to disk so login survives app restarts.

Stored as plaintext JSON in the per-user app-data dir. The file contains the
BIAB_CUSTOMER JWT, the www `Token`, and the exchange cookie jar — i.e. bearer
credentials to the account. Anyone with read access to this file can act as the
logged-in user. The file is removed on manual logout and whenever a stored
session is found to be expired.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)

APP_DIR_NAME = "PB77Terminal"
SESSION_FILE = "session.json"


def _session_path() -> Path:
    """Per-user location for the session file (Windows %APPDATA%, else ~)."""
    base = os.environ.get("APPDATA") or os.environ.get("XDG_CONFIG_HOME")
    root = Path(base) if base else Path.home()
    return root / APP_DIR_NAME / SESSION_FILE


def save(data: dict) -> None:
    path = _session_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        logger.info("Session saved to %s", path)
    except OSError as e:
        logger.warning("Could not save session: %s", e)


def load() -> dict | None:
    path = _session_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        logger.warning("Could not read session file: %s", e)
        return None


def clear() -> None:
    path = _session_path()
    try:
        path.unlink(missing_ok=True)
        logger.info("Session file cleared")
    except OSError as e:
        logger.warning("Could not clear session file: %s", e)
