"""
Local dummy market for testing the trading tools without a live pb77 stream.

Provides a fixed 2-runner market ("Team Alpha" v "Team Beta") with deep back/lay
liquidity around 2.00, a randomised live book (so prices jitter), and helpers to
simulate bet placement locally — nothing here ever hits the network. The market
id is prefixed "TEST" so the rest of the app can route it to simulation.
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta

from pb77.api.models import Market, Runner
from pb77.api.prices import MarketBook

TEST_SPORT_ID = "TEST"
TEST_MARKET_ID = "TEST.1"
A_ID, B_ID = 90001, 90002
A_NAME, B_NAME = "Team Alpha", "Team Beta"
EVENT_NAME = "Alpha v Beta"

# Base available sizes per (odds) — randomised ±40% each tick for a live feel.
_A_BACK = [(1.95, 300), (1.96, 250), (1.97, 400), (1.98, 600), (1.99, 800), (2.0, 1000)]
_A_LAY = [(2.02, 900), (2.04, 700), (2.06, 500), (2.08, 300)]
_B_BACK = [(1.95, 350), (1.96, 280), (1.97, 420), (1.98, 650), (1.99, 750), (2.0, 1100)]
_B_LAY = [(2.02, 950), (2.04, 720), (2.06, 480), (2.08, 260)]


def dummy_market() -> Market:
    return Market(
        market_id=TEST_MARKET_ID,
        market_name="Match Odds (TEST)",
        market_type="MATCH_ODDS",
        market_start_time=datetime.now() + timedelta(hours=1),
        total_matched=125_000.0,
        commission=2.0,
        in_play=False,
        runners=[Runner(A_ID, A_NAME, sort_priority=1),
                 Runner(B_ID, B_NAME, sort_priority=2)],
        event_id="TESTEV",
        event_name=EVENT_NAME,
        competition_name="Test League",
        betting_type="ODDS",
    )


def dummy_book(live: bool = True) -> MarketBook:
    """A full-image MarketBook with liquidity. live=True randomises the sizes."""
    book = MarketBook(market_id=TEST_MARKET_ID)
    book.apply(_image(live))
    return book


def _jit(size: float, live: bool) -> float:
    return round(size * random.uniform(0.6, 1.4), 2) if live else float(size)


def _image(live: bool) -> dict:
    def catb(levels):  # ascending by odds (parser reverses to best-first)
        return [[od, _jit(sz, live)] for od, sz in sorted(levels)]

    def catl(levels):  # ascending by odds (best lay already first)
        return [[od, _jit(sz, live)] for od, sz in sorted(levels)]

    return {
        "id": TEST_MARKET_ID,
        "img": True,
        "tv": _jit(125_000, live),
        "rc": [
            {"id": A_ID, "tv": _jit(60_000, live),
             "catb": catb(_A_BACK), "catl": catl(_A_LAY)},
            {"id": B_ID, "tv": _jit(65_000, live),
             "catb": catb(_B_BACK), "catl": catl(_B_LAY)},
        ],
    }


def is_dummy(market_id: str) -> bool:
    return str(market_id).startswith("TEST")


def simulated_bet(bet) -> dict:
    """Build an Open-Bets-panel record for a locally simulated (instantly matched) bet."""
    name = {A_ID: A_NAME, B_ID: B_NAME}.get(bet.selection_id, str(bet.selection_id))
    profit = bet.size * (bet.price - 1) if bet.side == "BACK" else -bet.size * (bet.price - 1)
    return {
        "side": bet.side,
        "selectionName": name,
        "selectionId": bet.selection_id,
        "eventName": EVENT_NAME,
        "marketName": "Match Odds (TEST)",
        "marketId": TEST_MARKET_ID,
        "price": bet.price,
        "sizeMatched": bet.size,
        "sizePlaced": bet.size,
        "sizeRemaining": 0.0,
        "potentialProfit": round(profit, 2),
        "offerState": "MATCHED",
    }
