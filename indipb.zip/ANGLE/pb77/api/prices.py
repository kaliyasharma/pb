"""
Live price models + parser for pb77 WebSocket market-change messages.

A market-change frame (inside SockJS `a[...]`) carries Betfair-style runner
changes: `bdatb` (best back levels), `bdatl` (best lay levels), `tv` (matched).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PriceLevel:
    odds: float
    amount: float


@dataclass
class RunnerBook:
    selection_id: int
    total_matched: float = 0.0
    back: list[PriceLevel] = field(default_factory=list)   # index 0 = best back
    lay: list[PriceLevel] = field(default_factory=list)    # index 0 = best lay
    traded: dict[float, float] = field(default_factory=dict)  # price → traded volume
    locked: bool = False

    def best_back(self) -> Optional[PriceLevel]:
        return self.back[0] if self.back else None

    def best_lay(self) -> Optional[PriceLevel]:
        return self.lay[0] if self.lay else None


@dataclass
class MarketBook:
    market_id: str
    status: str = ""
    in_play: bool = False
    bet_delay: int = 0
    total_matched: float = 0.0
    overround: float = 0.0
    underround: float = 0.0
    betting_enabled: bool = True
    runners: dict[int, RunnerBook] = field(default_factory=dict)

    def apply(self, msg: dict) -> None:
        """Apply a market-change message (full image or delta) in place."""
        mdef = msg.get("marketDefinition") or {}
        if mdef:
            self.status = mdef.get("status", self.status)
            self.in_play = mdef.get("inPlay", self.in_play)
            self.bet_delay = mdef.get("betDelay", self.bet_delay)

        if msg.get("tv") is not None:
            try:
                self.total_matched = float(msg["tv"])
            except (TypeError, ValueError):
                pass
        self.overround = msg.get("overround", self.overround)
        self.underround = msg.get("underround", self.underround)
        self.betting_enabled = msg.get("bettingEnabled", self.betting_enabled)

        # Full image replaces runner books entirely
        if msg.get("img"):
            self.runners.clear()

        for rc in msg.get("rc", []):
            sid = int(rc["id"])
            book = self.runners.get(sid) or RunnerBook(selection_id=sid)
            if rc.get("tv") is not None:
                book.total_matched = float(rc["tv"])

            # bdatb/bdatl — indexed object format (general ws endpoint)
            if "bdatb" in rc:
                book.back = _levels(rc["bdatb"])
            if "bdatl" in rc:
                book.lay = _levels(rc["bdatl"])

            # catb/catl — array format [[odds, amount], …] (multiple-market-prices endpoint)
            # catb is ascending by odds, so reverse to get best-back (highest odds) first
            if "catb" in rc:
                book.back = _levels_cat(rc["catb"], reverse=True)
            if "catl" in rc:
                book.lay = _levels_cat(rc["catl"], reverse=False)

            # trd — traded volume per price [[odds, volume], …]
            # Full image replaces; delta revises individual price levels.
            if "trd" in rc:
                if msg.get("img"):
                    book.traded = {}
                for item in rc["trd"]:
                    if item and len(item) >= 2:
                        book.traded[float(item[0])] = float(item[1])

            book.locked = rc.get("locked", book.locked)
            self.runners[sid] = book


def _levels(raw: list[dict]) -> list[PriceLevel]:
    """Parse indexed object format {index, odds, amount}, ordered best-first.

    Levels with no size are dropped — the feed pads the book with empty rungs
    (odds set, amount 0) that aren't real liquidity and would otherwise show as
    phantom prices in the grid.
    """
    ordered = sorted(raw, key=lambda x: x.get("index", 0))
    out: list[PriceLevel] = []
    for lvl in ordered:
        odds = lvl.get("odds", 0.0) or 0.0
        amount = lvl.get("amount", 0.0) or 0.0
        if odds > 0 and amount > 0:
            out.append(PriceLevel(odds=odds, amount=amount))
    return out


def _levels_cat(raw: list[list], reverse: bool = False) -> list[PriceLevel]:
    """Parse catb/catl array format [[odds, amount], …], ordered best-first.

    catb is ascending (lowest odds first) → reverse=True → best back (highest) at index 0.
    catl is ascending (lowest odds first) → reverse=False → best lay (lowest) already at index 0.

    Zero-size rungs are skipped: the combined feed includes empty price points
    (e.g. 1.89 @ 0) that, once reversed, would masquerade as the best back.
    """
    out = [
        PriceLevel(odds=float(item[0]), amount=float(item[1]))
        for item in raw
        if item and float(item[0]) > 0 and float(item[1]) > 0
    ]
    if reverse:
        out.reverse()
    return out


def parse_market_change(msg: dict) -> MarketBook:
    """Build a fresh MarketBook from a single message (used for testing)."""
    book = MarketBook(market_id=str(msg.get("id", "")))
    book.apply(msg)
    return book
