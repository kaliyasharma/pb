"""
PB77 API client — synchronous (driven from Qt background workers).

A single httpx.Client carries the cookie jar so the BIAB_CUSTOMER cookie
(set during the exchange handshake, domain=.pb77.co) is sent to both
www.pb77.co and ex.pb77.co automatically.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta
from urllib.parse import quote

import httpx

import random
import string
import time
import uuid

from pb77.api import session_store
from pb77.api.endpoints import ENDPOINTS
from pb77.api.models import (
    Session, Competition, Event, Market, PlatformConfig,
    BetInstruction, BetResult, SearchEvent, CashOutResult, PlacedOffer,
)
from pb77.api.sports import DEFAULT_SPORT_IDS

logger = logging.getLogger(__name__)

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/146.0.0.0 Safari/537.36"
)


def _www_headers() -> dict:
    """Headers for the www.<domain> (account / auth) host."""
    return {
        "Language": "en-US",
        "Clienttype": "2",
        "User-Agent": USER_AGENT,
        "Origin": ENDPOINTS.www_base,
        "Referer": f"{ENDPOINTS.www_base}/",
        "Accept": "*/*",
    }


def _ex_headers() -> dict:
    """Headers for the ex.<domain> (exchange) host."""
    return {
        "X-Device": "DESKTOP",
        "User-Agent": USER_AGENT,
        "Origin": ENDPOINTS.ex_base,
        "Referer": f"{ENDPOINTS.ex_base}/",
        "Accept": "application/json, text/plain, */*",
    }


class PB77Error(Exception):
    pass


class PB77Client:
    def __init__(self):
        self._http = httpx.Client(follow_redirects=True, timeout=20.0)
        self.session: Session | None = None
        self.platform_config: PlatformConfig | None = None
        self._pending_login: dict | None = None

    # ── Auth: 3-step OTP login ────────────────────────────────────────────────

    def request_otp(self, email: str) -> None:
        """Step 1 — trigger the OTP email."""
        resp = self._http.post(
            f"{ENDPOINTS.www_base}/api/v2/otp/email",
            params={"used": "true", "email": email},
            headers=_www_headers(),
        )
        body = self._unwrap(resp)
        logger.info("OTP requested for %s", email)
        return body

    def verify_otp(self, email: str, otp: str) -> dict:
        """Step 2 — verify the OTP, capture token + nickname."""
        resp = self._http.post(
            f"{ENDPOINTS.www_base}/api/v2/login/email",
            content=f"email={quote(email)}&otp={otp}",
            headers={
                **_www_headers(),
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
            },
        )
        body = self._unwrap(resp)
        self._pending_login = body["data"]
        logger.info("OTP verified, token acquired")
        return self._pending_login

    def exchange_handshake(self) -> Session:
        """Step 3 — exchange token for the BIAB session, build Session."""
        if not self._pending_login:
            raise PB77Error("Call verify_otp() before exchange_handshake().")

        d = self._pending_login
        token = d["token"]
        nickname = d["nickname"]

        resp = self._http.post(
            f"{ENDPOINTS.www_base}/api/exchange2",
            params={"token": token, "name": nickname},
            headers={**_www_headers(), "Token": token},
        )
        body = self._unwrap(resp)
        ex = body["data"]

        timeout = (d.get("logoutSetting") or {}).get("tokenTimeout", 36000)
        self.session = Session(
            token=token,
            member_id=int(d.get("memberId", 0)),
            email=d.get("email", ""),
            nickname=nickname,
            currency_code=d.get("currencyCode", ""),
            currency_symbol=d.get("currencySymbol", ""),
            balance=float(d.get("currencyBalance", 0.0)),
            biab_jwt=ex.get("BIAB_CUSTOMER", ""),
            exchange_url=ex.get("biabUrl", ENDPOINTS.ex_base),
            expires_at=datetime.utcnow() + timedelta(seconds=timeout),
        )
        # Token header is needed on subsequent www calls
        self._http.headers["Token"] = token
        self._pending_login = None
        self._ensure_biab_cookies()
        logger.info("Exchange handshake complete for %s", nickname)
        try:
            self.platform_config = self.get_page_properties()
        except Exception as e:
            logger.warning("Could not fetch platform config: %s", e)
            self.platform_config = PlatformConfig(nav_sport_ids=DEFAULT_SPORT_IDS)
        self.save_session()
        return self.session

    def login(self, email: str, otp: str) -> Session:
        """Convenience: run steps 2 + 3 (OTP already sent)."""
        self.verify_otp(email, otp)
        return self.exchange_handshake()

    def logout(self) -> None:
        self.session = None
        self.platform_config = None
        self._pending_login = None
        self._http.cookies.clear()
        self._http.headers.pop("Token", None)
        session_store.clear()

    def is_logged_in(self) -> bool:
        return self.session is not None and self.session.seconds_remaining > 300

    # ── Session persistence ───────────────────────────────────────────────────

    def save_session(self) -> None:
        """Write the current session + cookie jar to disk (plaintext JSON)."""
        if self.session is None:
            return
        session_store.save(self._serialize_session())

    def restore_session(self) -> bool:
        """Reload a previously saved session, if one exists and is still valid.

        Rebuilds the Session, repopulates the cookie jar + Token header, and
        restores the platform config — so the app can skip the login flow. A
        missing, malformed, or expired session returns False (and the stale
        file is removed), sending the user back to the login screen.
        """
        data = session_store.load()
        if not data:
            return False
        try:
            sd = data["session"]
            session = Session(
                token=sd["token"],
                member_id=int(sd.get("member_id", 0)),
                email=sd.get("email", ""),
                nickname=sd.get("nickname", ""),
                currency_code=sd.get("currency_code", ""),
                currency_symbol=sd.get("currency_symbol", ""),
                balance=float(sd.get("balance", 0.0)),
                biab_jwt=sd.get("biab_jwt", ""),
                exchange_url=sd.get("exchange_url", ENDPOINTS.ex_base),
                expires_at=datetime.fromisoformat(sd["expires_at"]),
            )
        except (KeyError, ValueError, TypeError) as e:
            logger.warning("Stored session is malformed (%s) — discarding", e)
            session_store.clear()
            return False

        if session.seconds_remaining <= 300:
            logger.info("Stored session has expired — discarding")
            session_store.clear()
            return False

        for c in data.get("cookies", []):
            try:
                self._http.cookies.set(
                    c["name"], c["value"],
                    domain=c.get("domain") or "", path=c.get("path") or "/",
                )
            except Exception:
                continue
        self._http.headers["Token"] = session.token
        self.session = session

        cfg = data.get("platform_config")
        if cfg:
            self.platform_config = PlatformConfig(
                nav_sport_ids=cfg.get("nav_sport_ids", DEFAULT_SPORT_IDS),
                reconnect_attempts=int(cfg.get("reconnect_attempts", 100)),
                reconnect_timeout_ms=int(cfg.get("reconnect_timeout_ms", 15000)),
            )
        else:
            self.platform_config = PlatformConfig(nav_sport_ids=DEFAULT_SPORT_IDS)

        logger.info("Restored session for %s (~%d min remaining)",
                    session.nickname, int(session.seconds_remaining // 60))
        return True

    def _serialize_session(self) -> dict:
        s = self.session
        cfg = self.platform_config
        return {
            "session": {
                "token": s.token,
                "member_id": s.member_id,
                "email": s.email,
                "nickname": s.nickname,
                "currency_code": s.currency_code,
                "currency_symbol": s.currency_symbol,
                "balance": s.balance,
                "biab_jwt": s.biab_jwt,
                "exchange_url": s.exchange_url,
                "expires_at": s.expires_at.isoformat(),
            },
            "cookies": [
                {"name": c.name, "value": c.value, "domain": c.domain, "path": c.path}
                for c in self._http.cookies.jar
            ],
            "platform_config": {
                "nav_sport_ids": cfg.nav_sport_ids,
                "reconnect_attempts": cfg.reconnect_attempts,
                "reconnect_timeout_ms": cfg.reconnect_timeout_ms,
            } if cfg else None,
        }

    # ── Exchange: navigation ──────────────────────────────────────────────────

    def list_competitions(self, sport_id: str) -> list[Competition]:
        resp = self._http.get(
            f"{ENDPOINTS.ex_base}/customer/api/competition/sport/{sport_id}",
            headers=_ex_headers(),
        )
        data = resp.json()
        comps: list[Competition] = []
        for c in data.get("topCompetitions", []):
            if c.get("type") == "COMPETITION":
                comps.append(Competition.from_json(c, highlighted=True))
        for c in data.get("moreCompetitions", []):
            if c.get("type") == "COMPETITION":
                comps.append(Competition.from_json(c, highlighted=False))
        return comps

    def list_events(self, competition_id: str) -> list[Event]:
        resp = self._http.get(
            f"{ENDPOINTS.ex_base}/customer/api/competition/{competition_id}",
            headers=_ex_headers(),
        )
        children = resp.json().get("children", [])
        return [Event.from_json(c) for c in children if c.get("type") == "EVENT"]

    def list_markets(self, event_id: str) -> list[Market]:
        resp = self._http.get(
            f"{ENDPOINTS.ex_base}/customer/api/event/details/{event_id}",
            headers=_ex_headers(),
        )
        cats = resp.json().get("marketCatalogues", [])
        return [Market.from_json(m) for m in cats]

    def get_market(self, market_id: str) -> Market:
        resp = self._http.get(
            f"{ENDPOINTS.ex_base}/customer/api/market/{market_id}",
            headers=_ex_headers(),
        )
        return Market.from_json(resp.json())

    def market_for_bet(self, bet: dict) -> Market:
        """Resolve a fully-populated Market from an open-bet dict.

        Tries /market/{id} first; if that omits the runner list, falls back to
        the event-details catalogue (when the bet carries an eventId). Display
        names are backfilled from the bet so the grid header is never blank.
        """
        market_id = str(bet.get("marketId", "") or "")
        if not market_id:
            raise PB77Error("This bet has no market to open")

        market = self.get_market(market_id)
        if not market.runners:
            event_id = str(bet.get("eventId", "") or "")
            if event_id:
                for m in self.list_markets(event_id):
                    if m.market_id == market_id:
                        market = m
                        break

        if not market.event_name:
            market.event_name = bet.get("eventName", "") or ""
        if not market.market_name:
            market.market_name = bet.get("marketName", "") or ""
        return market

    def search_events(
        self, query: str, offset: int = 0, size: int = 20,
        group_by_sports: bool = True,
    ) -> list[SearchEvent]:
        """GET /customer/api/event/search — free-text search across events.

        Returns matching events with their top markets embedded, so results can
        be shown (and their markets selected) without a follow-up details call.
        """
        resp = self._http.get(
            f"{ENDPOINTS.ex_base}/customer/api/event/search",
            params={
                "query": query,
                "offset": offset,
                "size": size,
                "groupBySports": "true" if group_by_sports else "false",
            },
            headers=_ex_headers(),
        )
        content = resp.json().get("content", [])
        return [SearchEvent.from_json(e) for e in content]

    def get_page_properties(self) -> PlatformConfig:
        """Fetch runtime platform settings from /customer/api/page/properties."""
        resp = self._http.get(
            f"{ENDPOINTS.ex_base}/customer/api/page/properties",
            headers=_ex_headers(),
        )
        data = resp.json()
        return PlatformConfig(
            nav_sport_ids=data.get("minNavSportIds", DEFAULT_SPORT_IDS),
            reconnect_attempts=int(data.get("reconnectAttempts", 100)),
            reconnect_timeout_ms=int(data.get("reconnectTimeout", 15000)),
        )

    # ── Exchange: order placement ─────────────────────────────────────────────

    def place_bets(self, market_id: str, bets: list[BetInstruction]) -> BetResult:
        """
        POST /customer/api/placeBets — place one or more bets on a single market.

        Payload shape confirmed from a live pb77 capture:
            { "<marketId>": [ {selectionId, handicap, price, size, side, betUuid,
                               betType, persistenceType, applicationType, …flags}, … ] }
        """
        if not bets:
            return BetResult(success=False, status="EMPTY", message="No bets to place")
        self._ensure_biab_cookies()
        if not self.csrf_token():
            return BetResult(
                success=False, status="NO_CSRF",
                message="Could not establish a CSRF token — are you logged in?",
            )

        base_ts = int(time.time() * 1000)
        entries = [self._bet_entry(market_id, b, base_ts + i) for i, b in enumerate(bets)]
        payload = {market_id: entries}

        url = f"{ENDPOINTS.ex_base}/customer/api/placeBets"
        headers = self._ex_write_headers()
        logger.info("PLACEBETS → POST %s", url)
        logger.info("PLACEBETS headers: %s", self._loggable_headers(headers))
        logger.info("PLACEBETS body: %s", json.dumps(payload))
        resp = self._http.post(url, json=payload, headers=headers)
        logger.info("PLACEBETS ← HTTP %s  body: %s", resp.status_code, resp.text[:1000])
        return self._parse_bet_result(resp, market_id=market_id, bets=bets, entries=entries)

    def cancel_all_bets(self, market_id: str | None = None) -> BetResult:
        """POST /customer/api/cancelBets/all — cancel all unmatched exchange bets."""
        self._ensure_biab_cookies()
        body: dict = {"betTypes": ["EXCHANGE"]}
        if market_id:
            body["marketId"] = market_id
        url = f"{ENDPOINTS.ex_base}/customer/api/cancelBets/all"
        headers = self._ex_write_headers()
        logger.info("CANCELALL → POST %s  body: %s", url, json.dumps(body))
        logger.info("CANCELALL headers: %s", self._loggable_headers(headers))
        resp = self._http.post(url, json=body, headers=headers)
        logger.info("CANCELALL ← HTTP %s  body: %s", resp.status_code, resp.text[:600])
        return self._parse_bet_result(resp, market_id=market_id)

    def cancel_bet(self, bet: dict) -> BetResult:
        """POST /customer/api/cancelBets — cancel one specific unmatched bet."""
        self._ensure_biab_cookies()
        market_id = str(bet["marketId"])
        payload = {market_id: [bet]}
        url = f"{ENDPOINTS.ex_base}/customer/api/cancelBets"
        headers = self._ex_write_headers()
        logger.info("CANCELBET → POST %s  offerId: %s", url, bet.get("offerId"))
        resp = self._http.post(url, json=payload, headers=headers)
        logger.info("CANCELBET ← HTTP %s  body: %s", resp.status_code, resp.text[:400])
        return self._parse_bet_result(resp, market_id=market_id)

    # ── Exchange: cash out ────────────────────────────────────────────────────

    def request_cashout(self, market_id: str, profit: float, quote: float) -> dict:
        """POST /customer/api/cashout — request a full cash out at the latest quote.

        Returns the raw envelope, e.g. {"id": 29387235, "status": "PENDING",
        "offers": [223164934]}. `quote` is the live quote value, `profit` its P/L.
        """
        self._ensure_biab_cookies()
        payload = {
            "marketId": market_id,
            "profit": profit,
            "quote": quote,
            "statistics": {"mobile": False, "applicationType": "WEB", "page": "market"},
        }
        url = f"{ENDPOINTS.ex_base}/customer/api/cashout"
        headers = self._ex_write_headers()
        logger.info("CASHOUT → POST %s  body: %s", url, json.dumps(payload))
        resp = self._http.post(url, json=payload, headers=headers)
        logger.info("CASHOUT ← HTTP %s  body: %s", resp.status_code, resp.text[:400])
        resp.raise_for_status()
        return resp.json()

    def cashout_status(self, cashout_id: int) -> dict:
        """GET /customer/api/cashout/status/{id} — poll a cash-out's progress."""
        resp = self._http.get(
            f"{ENDPOINTS.ex_base}/customer/api/cashout/status/{cashout_id}",
            headers=_ex_headers(),
        )
        resp.raise_for_status()
        return resp.json()

    def cash_out(
        self, market_id: str, profit: float, quote: float,
        poll_timeout: float = 15.0, poll_interval: float = 1.0,
    ) -> CashOutResult:
        """Full cash-out flow: submit the request, then poll status until it settles.

        Runs on a background worker (it sleeps between polls), so never call it on
        the Qt thread. Returns success=True once status reaches SUCCESS; terminal
        non-success states (ERROR/FAILED/REJECTED) or the timeout end the poll.
        """
        try:
            submit = self.request_cashout(market_id, profit, quote)
        except Exception as e:
            return CashOutResult(success=False, status="ERROR", message=str(e))

        cashout_id = int(submit.get("id", 0) or 0)
        status = str(submit.get("status", "")).upper()
        if not cashout_id:
            return CashOutResult(success=False, status=status or "ERROR",
                                 message="No cash-out id returned", raw=submit)

        last = submit
        deadline = time.time() + poll_timeout
        while status in ("", "PENDING") and time.time() < deadline:
            time.sleep(poll_interval)
            try:
                last = self.cashout_status(cashout_id)
            except Exception as e:
                return CashOutResult(success=False, status="ERROR",
                                     cashout_id=cashout_id, message=str(e))
            status = str(last.get("status", "")).upper()

        success = status == "SUCCESS"
        profit_val = last.get("profit")
        if profit_val is None:
            profit_val = last.get("actualProfit", 0.0)
        return CashOutResult(
            success=success,
            status=status or "PENDING",
            cashout_id=cashout_id,
            profit=float(profit_val or 0.0),
            message="" if success else f"Cash out {status or 'timed out'}",
            raw=last,
        )

    @staticmethod
    def _bet_entry(market_id: str, b: BetInstruction, ts: int) -> dict:
        """One bet object, matching the confirmed live placeBets payload exactly."""
        hcap = int(b.handicap) if float(b.handicap).is_integer() else b.handicap
        rand = "".join(random.choices(string.ascii_lowercase + string.digits, k=5))
        return {
            "selectionId": b.selection_id,
            "handicap": hcap,                 # int when whole (0), matches capture
            "price": b.price,                 # numeric, not string
            "size": b.size,
            "side": b.side,
            # betUuid: {marketId}_{selectionId}_{handicap}__{epoch_ms}-{rand}_INLINE
            "betUuid": f"{market_id}_{b.selection_id}_{hcap}__{ts}-{rand}_INLINE",
            "betType": "EXCHANGE",
            "netPLBetslipEnabled": False,
            "netPLMarketPageEnabled": False,
            "quickStakesEnabled": True,
            "confirmBetsEnabled": False,
            "applicationType": "WEB",
            "showLayOddsEnabled": False,
            "mobile": False,                  # desktop client (X-Device: DESKTOP)
            "isEachWay": False,
            "eachWayData": {},
            "openBetsEnabled": False,
            "page": "market",
            "persistenceType": "LAPSE",
            "placedUsingEnterKey": False,
        }

    def _ex_write_headers(self) -> dict:
        """Exchange headers for state-changing POSTs — adds the CSRF token."""
        headers = _ex_headers()
        headers["Content-Type"] = "application/json"
        token = self.csrf_token()
        if token:
            headers["X-Csrf-Token"] = token
        return headers

    @staticmethod
    def _loggable_headers(headers: dict) -> str:
        """Compact header dump for the debug log (cookies are added by httpx, not here)."""
        return json.dumps({k: v for k, v in headers.items()})

    def csrf_token(self) -> str:
        """The CSRF-TOKEN cookie value, echoed back in the X-Csrf-Token header."""
        for c in self._http.cookies.jar:
            if c.name == "CSRF-TOKEN":
                return c.value or ""
        return ""

    def _cookie_value(self, name: str) -> str:
        for c in self._http.cookies.jar:
            if c.name == name:
                return c.value or ""
        return ""

    def _ensure_biab_cookies(self) -> None:
        """
        Mint the frontend-generated BIAB cookies the browser creates client-side.

        CSRF-TOKEN uses the double-submit pattern: the SPA generates a UUID, stores it
        as a cookie AND sends it back in the X-Csrf-Token header — the server only checks
        the two match. BIAB_AN is an anonymous id, BIAB_LANGUAGE / BIAB_TZ are prefs.
        We only set a cookie if the server hasn't already issued one (prefer server value).
        """
        have = {c.name for c in self._http.cookies.jar}
        defaults = {
            "CSRF-TOKEN": str(uuid.uuid4()),
            "BIAB_AN": str(uuid.uuid4()),
            "BIAB_LANGUAGE": "en",
            "BIAB_TZ": self._tz_offset(),
        }
        for name, value in defaults.items():
            if name not in have:
                self._http.cookies.set(name, value, domain=ENDPOINTS.ex_host, path="/")

    @staticmethod
    def _tz_offset() -> str:
        """JS getTimezoneOffset() equivalent in minutes (IST → '-330')."""
        is_dst = time.daylight and time.localtime().tm_isdst > 0
        secs = time.altzone if is_dst else time.timezone
        return str(secs // 60)

    @staticmethod
    def _parse_bet_result(
        resp: httpx.Response, market_id: str | None = None,
        bets: list[BetInstruction] | None = None, entries: list[dict] | None = None,
    ) -> BetResult:
        """Parse a placeBets/cancelBets response.

        The success shape is keyed by marketId:
            {"<marketId>": {"status": "OK", "betDelay": 5,
                            "offerIds": {"<betUuid>": <offerId>, …}}}
        A non-OK per-market status, an HTTP error, or a top-level error envelope
        ({"message"/"exceptionMessage"/"errorCode": …}) is a failure.
        """
        try:
            body = resp.json()
        except Exception:
            body = {}
        if resp.status_code >= 400:
            msg = (PB77Client._envelope_error(body)
                   or f"HTTP {resp.status_code}: {resp.text[:160]}")
            return BetResult(success=False, status=str(resp.status_code), message=msg, raw=body)

        mres = PB77Client._market_result(body, market_id)
        if mres is not None:
            status = str(mres.get("status") or "")
            success = status.upper() in {"OK", "SUCCESS"}
            bet_delay = int(mres.get("betDelay") or 0)
            offers = PB77Client._build_offers(mres.get("offerIds") or {}, bets, entries)
            msg = "" if success else (
                mres.get("errorCode") or mres.get("error") or mres.get("message") or status)
            return BetResult(success=success, status=status or ("OK" if success else "ERROR"),
                             message=str(msg), bet_delay=bet_delay, offers=offers, raw=body)

        # No per-market block → treat as a top-level envelope (validation / error).
        err = PB77Client._envelope_error(body)
        if err:
            return BetResult(success=False, status="ERROR", message=err, raw=body)
        status = body.get("status") or body.get("result") or "OK"
        failed = str(status).upper() in {"FAILURE", "ERROR"} or bool(body.get("error"))
        return BetResult(success=not failed, status=str(status),
                         message=body.get("message") or "", raw=body)

    @staticmethod
    def _market_result(body: dict, market_id: str | None) -> dict | None:
        """The per-market result block from a placeBets/cancelBets response, if present."""
        if not isinstance(body, dict):
            return None
        if market_id and isinstance(body.get(market_id), dict):
            return body[market_id]
        for v in body.values():            # fall back to the first market-shaped value
            if isinstance(v, dict) and "status" in v:
                return v
        return None

    @staticmethod
    def _envelope_error(body: dict) -> str:
        """Pull an error message from a top-level error envelope, else ''."""
        if not isinstance(body, dict):
            return ""
        return (body.get("message") or body.get("exceptionMessage")
                or body.get("errorMessage") or body.get("errorCode") or "")

    @staticmethod
    def _build_offers(
        offer_ids: dict, bets: list[BetInstruction] | None, entries: list[dict] | None,
    ) -> list[PlacedOffer]:
        """Map returned offerIds (keyed by betUuid) back to their instructions."""
        if not offer_ids or not bets or not entries:
            return []
        by_uuid = {e.get("betUuid"): b for e, b in zip(entries, bets)}
        offers: list[PlacedOffer] = []
        for uuid_key, oid in offer_ids.items():
            b = by_uuid.get(uuid_key)
            if b is None:
                continue
            try:
                offer_id = int(oid)
            except (TypeError, ValueError):
                continue
            offers.append(PlacedOffer(
                offer_id=offer_id, selection_id=b.selection_id, side=b.side,
                price=b.price, size=b.size, bet_uuid=uuid_key,
            ))
        return offers

    # ── Helpers ───────────────────────────────────────────────────────────────

    def cookie_header(self) -> str:
        """Cookie string for the exchange domain — needed by the WebSocket."""
        return "; ".join(f"{c.name}={c.value}" for c in self._http.cookies.jar)

    @staticmethod
    def _unwrap(resp: httpx.Response) -> dict:
        """Validate the standard pb77 response envelope."""
        try:
            body = resp.json()
        except Exception as e:
            raise PB77Error(f"Non-JSON response ({resp.status_code}): {resp.text[:200]}") from e
        if body.get("status") != 200:
            msg = body.get("message") or body.get("exceptionMessage") or "Unknown error"
            raise PB77Error(f"API error {body.get('status')}: {msg}")
        return body

    def close(self) -> None:
        self._http.close()
