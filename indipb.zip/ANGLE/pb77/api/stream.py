"""
SockJS price stream client for ex.pb77.co.

Connects to wss://ex.pb77.co/customer/ws/multiple-market-prices/{server}/{session}/websocket,
parses SockJS frames, and emits decoded market-change messages via callbacks.

Auto-reconnects with exponential backoff on any disconnect (including ping/pong timeout).
The background thread loops: connect → run_forever → wait → connect …
On each reconnect, _handshake() re-subscribes to the current market automatically.
"""
from __future__ import annotations

import json
import logging
import random
import ssl
import threading
import uuid
from typing import Callable, Optional

import websocket  # websocket-client

from pb77.api.endpoints import ENDPOINTS

websocket.enableTrace(False)
logger = logging.getLogger(__name__)
ws_logger = logging.getLogger("pb77.ws")     # raw frame traffic (debug log window)

# Base URLs are derived from the central domain config (pb77.api.endpoints):
#   ENDPOINTS.ws_multi   → multiple-market-prices (live prices)
#   ENDPOINTS.ws_general → general (graphs / balance / bets / cash-out)
# served on a SEPARATE SockJS connection — NOT on multiple-market-prices.

# Exponential backoff delays (seconds): attempt 0→1s, 1→2s, 2→4s, 3→8s, 4+→30s
_BACKOFF = [1, 2, 4, 8, 30]


class PriceStream:
    def __init__(
        self,
        cookie_header: str,
        on_message: Callable[[dict], None],
        on_status: Optional[Callable[[str], None]] = None,
        on_graph: Optional[Callable[[list], None]] = None,
        on_balance: Optional[Callable[[float], None]] = None,
        on_open_bets: Optional[Callable[[int], None]] = None,
        on_current_bets: Optional[Callable[[list], None]] = None,
        on_cashout: Optional[Callable[[list], None]] = None,
        on_bet_status: Optional[Callable[[dict], None]] = None,
    ):
        self._cookie = cookie_header
        self._on_message = on_message
        self._on_status = on_status or (lambda _s: None)
        self._on_graph = on_graph or (lambda _pts: None)
        self._on_balance = on_balance or (lambda _b: None)
        self._on_open_bets = on_open_bets or (lambda _n: None)
        self._on_current_bets = on_current_bets or (lambda _l: None)
        self._on_cashout = on_cashout or (lambda _q: None)
        self._on_bet_status = on_bet_status or (lambda _s: None)

        self._ws: Optional[websocket.WebSocketApp] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_evt = threading.Event()

        # Second connection — the "general" endpoint that carries MARKET_GRAPHS.
        self._gws: Optional[websocket.WebSocketApp] = None
        self._gthread: Optional[threading.Thread] = None
        self._gopen = False

        self._market: Optional[tuple[str, str]] = None   # (market_id, event_id)
        self._selections: list[int] = []                 # for MARKET_GRAPHS subscribe
        self._cashout_market: Optional[str] = None        # market_id for CASH_OUT_QUOTE
        self._bet_status_ids: set[int] = set()            # offerIds tracked via BET_STATUSES
        self._open = False
        self._running = False

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._stop_evt.clear()
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def set_market(
        self, market_id: str, event_id: str, selection_ids: Optional[list[int]] = None
    ) -> None:
        """Focus on a market. Starts the stream on first call; re-subscribes if already open."""
        self._market = (market_id, event_id)
        self._selections = list(selection_ids or [])
        if not self._running:
            self.start()
        elif self._open:
            self._send_market(market_id, event_id)
        # Graphs ride a separate connection — make sure it's up and (re)subscribe.
        self._start_graph()
        if self._gopen:
            self._send_graph_subscribe()

    def connect(self) -> None:
        """Start both sockets immediately (call this on app open, before any market)."""
        self._running = True
        self._stop_evt.clear()
        if not (self._thread and self._thread.is_alive()):
            self._thread = threading.Thread(target=self._run_loop, daemon=True)
            self._thread.start()
        self._start_graph()

    def request_graphs(self) -> None:
        """(Re)send the MARKET_GRAPHS handshake now — e.g. when the user opens the ladder,
        which is when the website itself sends it (after price data is already flowing)."""
        self._start_graph()
        if self._gopen:
            self._send_graph_subscribe()

    def set_cashout_market(self, market_id: Optional[str]) -> None:
        """Subscribe to live cash-out quotes (CASH_OUT_QUOTE) for a market.

        Pass None to stop tracking (e.g. on the dummy/test market). Quotes ride the
        general socket; the subscribe is re-sent automatically on reconnect.
        """
        self._cashout_market = market_id
        if not market_id:
            return
        self._start_graph()
        if self._gopen:
            self._send_cashout_subscribe()

    def subscribe_bet_statuses(self, bet_ids: list[int]) -> None:
        """Track a freshly-placed bet's progress (PENDING → PLACED/…) via BET_STATUSES."""
        new = {int(b) for b in bet_ids if b is not None}
        if not new:
            return
        self._bet_status_ids |= new
        self._start_graph()
        if self._gopen:
            self._send_bet_status_subscribe(sorted(new))

    def drop_bet_statuses(self, bet_ids: list[int]) -> None:
        """Stop tracking bets that have reached a terminal state."""
        self._bet_status_ids -= {int(b) for b in bet_ids if b is not None}

    def stop(self) -> None:
        self._running = False
        self._stop_evt.set()          # wake any sleeping reconnect immediately
        for ws in (self._ws, self._gws):
            if ws:
                try:
                    ws.close()
                except Exception:
                    pass
        self._ws = None
        self._gws = None
        self._open = False
        self._gopen = False

    # ── Auto-reconnect loop (daemon thread) ───────────────────────────────────

    def _run_loop(self) -> None:
        attempt = 0
        while self._running:
            url = self._ws_url()
            logger.info("Connecting price stream (attempt %d): %s", attempt + 1, url)
            self._open = False

            self._ws = websocket.WebSocketApp(
                url,
                header=[f"Cookie: {self._cookie}"] if self._cookie else None,
                on_open=self._on_open,
                on_message=self._on_raw,
                on_error=self._on_error,
                on_close=self._on_close,
            )
            self._ws.run_forever(
                ping_interval=25,
                ping_timeout=10,
                sslopt={"cert_reqs": ssl.CERT_NONE},
            )

            if not self._running:
                break

            delay = _BACKOFF[min(attempt, len(_BACKOFF) - 1)]
            attempt += 1
            self._on_status(f"Disconnected — reconnecting in {delay}s…")
            logger.info("Stream dropped, reconnecting in %ds (attempt %d)", delay, attempt)

            # Interruptible sleep: returns immediately if stop() is called
            if self._stop_evt.wait(timeout=float(delay)):
                break

        logger.info("Price stream loop exited")

    # ── Graph connection (general endpoint) ───────────────────────────────────

    def _start_graph(self) -> None:
        if self._gthread and self._gthread.is_alive():
            return
        if not self._running:        # piggy-backs on the same run flag
            self._running = True
            self._stop_evt.clear()
        self._gthread = threading.Thread(target=self._graph_run_loop, daemon=True)
        self._gthread.start()

    def _graph_run_loop(self) -> None:
        attempt = 0
        while self._running:
            url = self._graph_ws_url()
            logger.info("Connecting GRAPH stream (attempt %d): %s", attempt + 1, url)
            self._gopen = False
            self._gws = websocket.WebSocketApp(
                url,
                header=[f"Cookie: {self._cookie}"] if self._cookie else None,
                on_open=lambda _ws: None,        # SockJS 'o' frame drives the handshake
                on_message=self._on_graph_raw,
                on_error=lambda _ws, e: logger.warning("GRAPH stream error: %s", e),
                on_close=lambda _ws, *_a: setattr(self, "_gopen", False),
            )
            self._gws.run_forever(
                ping_interval=25, ping_timeout=10,
                sslopt={"cert_reqs": ssl.CERT_NONE},
            )
            if not self._running:
                break
            delay = _BACKOFF[min(attempt, len(_BACKOFF) - 1)]
            attempt += 1
            logger.info("Graph stream dropped, reconnecting in %ds", delay)
            if self._stop_evt.wait(timeout=float(delay)):
                break
        logger.info("Graph stream loop exited")

    def _on_graph_raw(self, _ws, raw: str):
        if not raw:
            return
        if raw[0] != "h":            # skip heartbeats; log every other frame
            ws_logger.info("GRAPH◄ %s", raw[:300])
        self._gframe_count = getattr(self, "_gframe_count", 0) + 1
        if "GRAPH" in raw:
            logger.info("RAW GRAPH BYTES on general (frame #%d, len=%d): %s",
                        self._gframe_count, len(raw), raw[:400])
        if self._gframe_count % 25 == 1:
            logger.info("GRAPH conn frames so far: %d (char0=%r len=%d)",
                        self._gframe_count, raw[0], len(raw))
        frame = raw[0]
        if frame == "o":            # SockJS open → init + graph subscribe
            self._gopen = True
            self._on_status("Graph stream connected")
            self._graph_handshake()
        elif frame == "h":
            return
        elif frame == "a":
            self._dispatch_array(raw[1:], graph_only=True)
        elif frame == "m":
            try:
                self._emit_graph(json.loads(raw[1:]))
            except Exception as e:
                logger.warning("bad graph m-frame: %s", e)
        elif frame == "c":
            self._gopen = False
        else:
            logger.warning("UNKNOWN graph frame start=%r len=%d head=%r",
                           frame, len(raw), raw[:60])

    def _graph_handshake(self):
        """After the general socket opens: init, subscribe live feeds, then MARKET_GRAPHS."""
        self._send_raw([{"applicationType": "WEB"}], ws=self._gws)
        self._send_raw({"BALANCE": {"subscribe": True, "applicationType": "WEB"}}, ws=self._gws)
        self._send_raw({"OPEN_BETS_COUNTER": {"subscribe": True, "applicationType": "WEB"}}, ws=self._gws)
        self._send_raw({"CURRENT_BETS": {"subscribe": True, "applicationType": "WEB"}}, ws=self._gws)
        self._send_graph_subscribe()
        self._send_cashout_subscribe()
        if self._bet_status_ids:
            self._send_bet_status_subscribe(sorted(self._bet_status_ids))

    # ── SockJS framing ────────────────────────────────────────────────────────

    @staticmethod
    def _ws_url() -> str:
        server = f"{random.randint(0, 999):03d}"
        session = str(uuid.uuid4())
        return f"{ENDPOINTS.ws_multi}/{server}/{session}/websocket"

    @staticmethod
    def _graph_ws_url() -> str:
        server = f"{random.randint(0, 999):03d}"
        session = str(uuid.uuid4())
        return f"{ENDPOINTS.ws_general}/{server}/{session}/websocket"

    def _on_open(self, _ws):
        logger.info("Price stream connected")
        self._open = True
        self._on_status("Stream connected")
        self._handshake()

    def _on_raw(self, _ws, raw: str):
        if not raw:
            return
        if raw[0] != "h":            # skip heartbeats; log every other frame
            ws_logger.info("PRICE◄ %s", raw[:300])
        # RAW MONITOR: surface any graph bytes exactly as they arrive, pre-parse.
        self._frame_count = getattr(self, "_frame_count", 0) + 1
        if "GRAPH" in raw:
            logger.info("RAW GRAPH BYTES (frame #%d, len=%d): %s",
                        self._frame_count, len(raw), raw[:400])
        if self._frame_count % 25 == 1:
            logger.info("RAW frames received so far: %d (last char0=%r len=%d)",
                        self._frame_count, raw[0], len(raw))
        frame = raw[0]
        if frame == "o":            # SockJS open
            self._open = True
            self._on_status("Stream connected")
            self._handshake()
        elif frame == "h":          # heartbeat
            return
        elif frame == "a":          # array of messages
            self._dispatch_array(raw[1:])
        elif frame == "m":          # single message
            try:
                self._emit(json.loads(raw[1:]))
            except Exception as e:
                logger.warning("bad m-frame (len=%d): %s", len(raw), e)
        elif frame == "c":          # server-initiated close
            self._open = False
            self._on_status("Stream closed by server")
        else:
            # Not a SockJS frame char (o/h/a/m/c) — likely a split/continuation of a
            # large frame. Log it so a dropped MARKET_GRAPHS snapshot is visible.
            logger.warning("UNKNOWN ws frame start=%r len=%d head=%r",
                           frame, len(raw), raw[:60])

    def _dispatch_array(self, payload: str, graph_only: bool = False):
        try:
            messages = json.loads(payload)
        except Exception as e:
            logger.warning("bad a-frame (len=%d, dropped): %s :: head=%r",
                           len(payload), e, payload[:80])
            return
        for item in messages:
            try:
                data = json.loads(item) if isinstance(item, str) else item
            except Exception as e:
                logger.warning("bad item in a-frame (dropped): %s", e)
                continue
            if graph_only:
                self._emit_graph(data)
            else:
                self._emit(data)

    def _emit_graph(self, data: dict):
        """Frames from the general (graph) socket → BALANCE updates + traded-volume points."""
        if not isinstance(data, dict):
            return

        # BALANCE update
        bal_data = data.get("BALANCE")
        if isinstance(bal_data, dict) and "balance" in bal_data:
            try:
                self._on_balance(float(bal_data["balance"]))
            except (TypeError, ValueError):
                pass
            return

        # OPEN_BETS_COUNTER update
        obc = data.get("OPEN_BETS_COUNTER")
        if isinstance(obc, dict):
            wallet = obc.get("betCountPerWallet", {})
            count = sum(int(v) for v in wallet.values()) if wallet else 0
            self._on_open_bets(count)
            return

        # CURRENT_BETS update (full snapshot list)
        if "CURRENT_BETS" in data:
            bets = data["CURRENT_BETS"]
            if isinstance(bets, list):
                self._on_current_bets(bets)
            return

        # CASH_OUT_QUOTE update (list of per-market quotes)
        if "CASH_OUT_QUOTE" in data:
            quotes = data["CASH_OUT_QUOTE"]
            if isinstance(quotes, list):
                self._on_cashout(quotes)
            return

        # BET_STATUSES update: {"<offerId>": {"state": "PENDING"|"PLACED"|…}, …}
        if "BET_STATUSES" in data:
            statuses = data["BET_STATUSES"]
            if isinstance(statuses, dict):
                self._on_bet_status(statuses)
            return

        points = extract_graph_points(data)
        status = graph_status(data)
        keys = list(data.keys())
        if "MARKET_GRAPHS" in data or points:
            tagged = {p[0] for p in points}
            logger.info("GRAPH FRAME status=%s keys=%s points=%d selections=%s",
                        status, keys, len(points), tagged)
            self._on_status(f"📊 Graph {status or ''}: {len(points)} pts {tagged or ''}")
        else:
            logger.info("graph-conn frame keys=%s :: %s", keys, json.dumps(data)[:160])
        if points:
            self._on_graph((points, status))

    def _emit(self, data: dict):
        if not isinstance(data, dict):
            return
        if "id" in data and ("rc" in data or "marketDefinition" in data):
            self._on_message(data)
            return
        # Non-price frame: log exactly what arrived so graph reception is verifiable.
        points = extract_graph_points(data)
        keys = list(data.keys())
        if "MARKET_GRAPHS" in data or points:
            tagged = {p[0] for p in points}
            logger.info("GRAPH FRAME (price conn) keys=%s points=%d selections=%s",
                        keys, len(points), tagged)
        else:
            logger.info("non-price frame keys=%s :: %s", keys, json.dumps(data)[:160])
        if points:
            self._on_graph((points, graph_status(data)))

    def _on_error(self, _ws, err):
        logger.warning("Price stream error: %s", err)
        # run_forever() exits after this; _run_loop handles the reconnect

    def _on_close(self, _ws, *_args):
        self._open = False
        # run_forever() is about to return; _run_loop handles the reconnect

    # ── Subscribe ─────────────────────────────────────────────────────────────

    def _handshake(self):
        """Sent immediately after every (re)connect — init then market subscribe.
        (Graphs are handled on the separate general connection, not here.)"""
        self._send_raw([{"applicationType": "WEB"}])
        if self._market:
            self._send_market(*self._market)

    def _send_market(self, market_id: str, event_id: str):
        # One subscribe for the whole market with all selections listed.
        # Sending separate per-selection messages caused the server to treat
        # each as a replacement, leaving only the first active.
        fields = ["EX_COMBINED_PRICES", "EX_ALL_OFFERS", "EX_TRADED", "EX_LTP"]
        payload: dict = {
            "marketId": market_id,
            "marketDataFields": fields,
            "applicationType": "WEB",
        }
        if self._selections:
            payload["selections"] = [{"id": sel_id, "handicap": 0}
                                      for sel_id in self._selections]
        self._send_raw([payload])
        logger.info("Subscribed to market %s — %d selections", market_id, len(self._selections))

    def _send_graph_subscribe(self):
        """Activate the traded-volume feed on the GENERAL socket — mirrors the browser's
        "open graphs" handshake (object-in-string form ["{\"MARKET_GRAPHS\":{…}}"]).

        Sequence (per capture): turn off EVENT_UPDATES + OPEN_BETS_COUNTER, subscribe
        MARKET_GRAPHS for every selection, then subscribe MARKET_DEFINITIONS.
        """
        if not self._market or not self._selections:
            return
        if not self._gopen:
            return                     # general socket not ready; its on-open will retry
        g = self._gws
        market_id = self._market[0]
        self._send_raw({"EVENT_UPDATES": {"subscribe": False, "applicationType": "WEB"}}, ws=g)
        for sel in self._selections:
            self._send_raw({"MARKET_GRAPHS": {
                "subscribe": True,
                "marketId": market_id,
                "selectionId": str(sel),
                "handicap": 0,
                "applicationType": "WEB",
            }}, ws=g)
        self._send_raw({"MARKET_DEFINITIONS": {
            "subscribe": True,
            "marketIds": [market_id],
            "applicationType": "WEB",
        }}, ws=g)
        logger.info("MARKET_GRAPHS subscribed on general socket for %d selections",
                    len(self._selections))

    def _send_cashout_subscribe(self):
        """Activate the CASH_OUT_QUOTE feed for the current market on the general socket."""
        if not self._cashout_market or not self._gopen:
            return                     # general socket not ready; on-open will retry
        self._send_raw({"CASH_OUT_QUOTE": {
            "subscribe": True,
            "marketIds": [self._cashout_market],
            "applicationType": "WEB",
        }}, ws=self._gws)
        logger.info("CASH_OUT_QUOTE subscribed for %s", self._cashout_market)

    def _send_bet_status_subscribe(self, bet_ids: list[int]):
        """Subscribe to BET_STATUSES for placed bets on the general socket."""
        if not bet_ids or not self._gopen:
            return
        self._send_raw({"BET_STATUSES": {
            "subscribe": True,
            "betIds": bet_ids,
            "applicationType": "WEB",
        }}, ws=self._gws)
        logger.info("BET_STATUSES subscribed for %s", bet_ids)

    def _send_raw(self, inner, ws=None) -> None:
        target = ws or self._ws
        if target is None:
            return
        try:
            inner_str = json.dumps(inner, separators=(",", ":"))
            out = json.dumps([inner_str], separators=(",", ":"))
            tag = "GRAPH►" if (ws is not None and ws is self._gws) else "PRICE►"
            ws_logger.info("%s %s", tag, out[:300])
            target.send(out)
        except Exception as e:
            logger.warning("ws send failed: %s", e)


def graph_status(data) -> Optional[str]:
    """READY (full snapshot) or UPDATED (delta) for a MARKET_GRAPHS frame, else None."""
    mg = data.get("MARKET_GRAPHS") if isinstance(data, dict) else None
    if isinstance(mg, dict):
        return mg.get("status")
    return None


def extract_graph_points(data) -> list[tuple]:
    """
    Pull MARKET_GRAPHS traded-volume points out of a frame, regardless of envelope.

    Returns a list of (selection_id|None, value, volume, timestamp) tuples. A "point" is
    any dict carrying both 'value' and 'volume'. The nearest enclosing selectionId /
    numeric key / 'id' field is used as the selection context. Price ('rc') and definition
    frames carry no value/volume pairs, so they yield [] — safe to call on anything.
    """
    out: list[tuple] = []

    def walk(node, sel):
        if isinstance(node, dict):
            if "selectionId" in node:
                sel = node["selectionId"]
            elif "id" in node and "value" not in node:
                sel = node["id"]
            if "value" in node and "volume" in node:
                try:
                    out.append((sel, float(node["value"]), float(node["volume"]),
                                int(node.get("timestamp", 0))))
                except (TypeError, ValueError):
                    pass
                return
            for k, v in node.items():
                ctx = sel
                if isinstance(k, str) and k.isdigit() and int(k) > 1000:
                    ctx = int(k)      # data keyed by selectionId
                walk(v, ctx)
        elif isinstance(node, list):
            for item in node:
                walk(item, sel)

    walk(data, None)
    return out
